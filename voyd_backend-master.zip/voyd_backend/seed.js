const app = require('./app')
const db = require('./models')
const bcrypt = require('bcryptjs')
async function executeSeeds() {
  await db.sequelize.sync({ force: true })

  //load seed files and run the function to insert
  await db.setting.insert({
    key: 'site_name',
    type: 0,
    value: 'Manaknight Inc',
  })
  await db.setting.insert({
    key: 'site_logo',
    type: 0,
    value: 'https://manaknightdigital.com/assets/img/logo.png',
  })
  await db.setting.insert({ key: 'maintenance', type: 1, value: '0' })
  await db.setting.insert({ key: 'version', type: 0, value: '1.0.0' })
  await db.setting.insert({
    key: 'copyright',
    type: 0,
    value: 'Copyright © 2019 Manaknightdigital Inc. All rights reserved.',
  })
  await db.setting.insert({
    key: 'license_key',
    type: 4,
    value:
      '4097fbd4f340955de76ca555c201b185cf9d6921d977301b05cdddeae4af54f924f0508cd0f7ca66',
  })
  await db.role.insert({ name: 'admin' })
  await db.role.insert({ name: 'member' })
  await db.credential.insert({
    email: 'admin@manaknight.com',
    password: '$2a$04$u162h6DBhEJGXQt6naMHauFlgihlrcEOu9GRFip7g.p.6BWCh2PjK',
    type: 'n',
    verify: 1,
    role_id: 1,
    user_id: 1,
    status: 1,
  })
  await db.credential.insert({
    email: 'member@manaknight.com',
    password: '$2a$04$ZOWNYcW89wpP/rEkELjpuOBhN7eXvR4xgibXx4uRJxhtjRQnDiKIS',
    type: 'n',
    verify: 1,
    role_id: 2,
    user_id: 2,
    status: 1,
  })
  await db.user.insert({
    first_name: 'Admin',
    last_name: 'Admin',
    phone: '12345678',
    image: 'https://i.imgur.com/AzJ7DRw.png',
    image_id: 1,
    refer: 'admin',
    role_id: 1,
    status: 1,
  })
  await db.user.insert({
    first_name: 'Member',
    last_name: 'Member',
    phone: '12345678',
    image: 'https://i.imgur.com/AzJ7DRw.png',
    image_id: 1,
    refer: 'member',
    role_id: 2,
    status: 1,
  })
  await db.code.insert({ code: 'rF9UDNRQ', is_used: 1, user_id: 2, status: 1 })
  await db.email.insert({
    slug: 'reset-password',
    subject: 'Reset your password',
    tag: 'reset_token,link',
    html: 'You have requested to reset your password. Please click the link below to reset it.<br/><a href="{{{link}}}/{{{reset_token}}}">Link</a>. <br/>Thanks,<br/> Admin',
  })
  await db.email.insert({
    slug: 'reset-password-mobile',
    subject: 'Reset your password',
    tag: 'code',
    html: "You have requested to reset your password. Here is your confirmation code <span style='font-size:25px'><strong>{{{code}}}</strong></span>.<br/>Thanks,<br/> Admin",
  })
  await db.email.insert({
    slug: 'register',
    subject: 'Welcome to VOYD',
    tag: 'first_name',
    html: 'Hi {{{first_name}}}, Thanks for registering on VOYD.<br/>',
  })
  await db.email.insert({
    slug: 'verify-account',
    subject: 'Confirm your account',
    tag: 'link',
    html: 'Please click the <a href="{{{link}}}">link</a> to confirm your account.<br/>Thanks<br/> Admin',
  })
  await db.sms.insert({
    slug: 'verify',
    tag: 'code',
    content: 'Your verification # is {{{code}}}',
  })
  await db.image.insert({
    url: 'https://i.imgur.com/AzJ7DRw.png',
    caption: '',
    user_id: 1,
    width: 581,
    height: 581,
    type: 1,
  })
}

executeSeeds()
