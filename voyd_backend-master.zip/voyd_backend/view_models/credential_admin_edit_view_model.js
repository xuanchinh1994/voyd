'use strict'
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * User_credentials Add View Model
 *
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 */
 const db = require('../models');

module.exports = function (entity, pageName='', success, error, base_url = "") {

  this._entity = entity
  this.session  = null

  this.success = success || null
  this.error = error || null

  this._base_url = base_url

  this.endpoint = "/admin/credentials"

  this.get_page_name = () => pageName


  this.heading = "Edit credential"

  this.action = "/admin/credentials-edit"
  
  
  

  this.form_fields = {"status":"","email":"","verify":"","id":""}

  
	this.verify_mapping = function () {
		return this._entity.verify_mapping();

	}

	this.status_mapping = function () {
		return this._entity.status_mapping();

	}

	this.role_id_mapping = function () {
		return this._entity.role_id_mapping();

	}

	this.two_factor_authentication_mapping = function () {
		return this._entity.two_factor_authentication_mapping();

	}



  return this
}
