'use strict'
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * User_code Add View Model
 *
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 */

const db = require('../models');


module.exports = function (entity, success, error ) {

  this._entity = entity
  this.session = null
  
  this.success = success || null
  this.error = error || null

  return this
}
