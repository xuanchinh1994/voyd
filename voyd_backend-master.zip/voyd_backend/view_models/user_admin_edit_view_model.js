'use strict'
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * User Add View Model
 *
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 */
 const db = require('../models');

module.exports = function (entity, pageName='', success, error, base_url = "") {

  this._entity = entity
  this.session  = null

  this.success = success || null
  this.error = error || null

  this._base_url = base_url

  this.endpoint = "/admin/users"

  this.get_page_name = () => pageName


  this.heading = "Edit user"

  this.action = "/admin/users-edit"
  
  
  

  this.form_fields = {"email":"","first_name":"","last_name":"","role_id":"","phone":"","status":"","id":""}

  
	this.status_mapping = function () {
		return this._entity.status_mapping();

	}

	this.time_format_mapping = function () {
		return this._entity.time_format_mapping();

	}

	this.clock_format_mapping = function () {
		return this._entity.clock_format_mapping();

	}

	this.date_format_mapping = function () {
		return this._entity.date_format_mapping();

	}



  return this
}
