'use strict';
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * Calendar List View Model
 *
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 */

module.exports = function (entity, pageName, success, error) {
  this.success = success || null
  this.error = error || null

  this._list= []
  
    this._column = ['ID','user_id','title','date','time','status','Action'];
    this._readable_column = ["ID","User","title","date","time","status"];
    this._readable_field_column = ["id","user_id","title","date","time","status"]

    this._entity = entity;
    this._heading = 'Calendar';
    
    this.endpoint = "/admin/calendar"

    this.get_page_name = () => pageName;


    this.get_heading = function () {
      return pageName;
    };

    this.get_column = function () {
      return ['ID','User',"Email",'title','date','time','status','Action'];
    };

    this.get_readable_column = function () {
      return this._readable_column;
    };

    this.set_list = function(list) {
      this._list =  list
    } 
    
    this.get_list = function() {
      return this._list
    }

    this.get_all_resource = function (where) {
     return this._entity.getAll(where)
    };

    this.get_readable_field_column = function () {
      return this._readable_field_column;
    };


    this.image_or_file = function (file) {
      const images = ['.jpg','.png', '.gif', '.jpeg', '.bmp'];
      let is_image = false;
      const exist = images.filter(function (value) {
        return value.indexOf(file) > -1;
      });

      if (exist.length > 0){
        return `<div class='mkd-image-container'><img class='img-fluid' src='${file}' onerror=\"if (this.src != '/images/uploads/placeholder.jpg') this.src = '/images/uploads/placeholder.jpg';\"/></div>`;
      }

      return `<a href='${file}' target='__blank'>${file}</a>`;
    };

    this.timeago = function(date) {
      const newDate = new Date(date);
      const today = new Date();
      const currentTime = today.getTime();
      const timestamp = newDate.getTime();

      const strTime = array('second', 'minute', 'hour', 'day', 'month', 'year');
      const duration = array(60, 60, 24, 30, 12, 10);

      if (currentTime >= timestamp) {
        diff  = currentTime - timestamp;

        for(let i = 0; diff >= duration[i] && i < duration.length - 1; i++) {
          diff = diff / duration[i];
        }

        diff = Math.round(diff, 0);
        return diff + ' ' + strTime[i] + '(s) ago ';
      }
    };

    this.time_default_mapping = function () {
      let results = [];
      for (let i = 0; i < 24; i++) {
        for (let j = 0; j < 60; j++) {
          let hour = (i < 10) ? '0' + i : i;
          let min = (j < 10) ? '0' + j : j;
          results[(i * 60) + j] = `${hour}:${min}`;
        }
      }
      return results;
    }

    this.convertToString = function (input) {
      if (input) {
        if (typeof input === "string") {
          return input;
        }

        return String(input);
      }
      return "";
    };

    // convert string to words
    this.toWords = function (input) {
      input = this.convertToString(input);

      var regex = /[A-Z\xC0-\xD6\xD8-\xDE]?[a-z\xDF-\xF6\xF8-\xFF]+|[A-Z\xC0-\xD6\xD8-\xDE]+(?![a-z\xDF-\xF6\xF8-\xFF])|\d+/g;

      return input.match(regex);
    };

    // convert the input array to camel case
    this.toCamelCase = function (inputArray) {
      let result = "";

      for (let i = 0, len = inputArray.length; i < len; i++) {
        let currentStr = inputArray[i];

        let tempStr = currentStr.toLowerCase();

        if (i != 0) {
          // convert first letter to upper case (the word is in lowercase)
          tempStr = tempStr.substr(0, 1).toUpperCase() + tempStr.substr(1);
        }

        result += tempStr;
      }

      return result;
    };

    this.toCamelCaseString = function (input) {
      let words = this.toWords(input);

      return this.toCamelCase(words);
    };

    this.ucFirst = function (string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    };

    this.number_format = function (field, n) {
      return field.toFixed(n);
    };
    this.date = function (d) {
      return ("0" + (d.getMonth() + 1)).slice( -2) + " " +  ("0" + d.getDate()).slice(-2)  + " " + d.getFullYear();
    };

    this.datetime = function (d) {
      return ("0" + (d.getMonth() + 1)).slice( -2) + " " +  ("0" + d.getDate()).slice(-2)  + " " + d.getFullYear() + " " + ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2);
    };



	this.status_mapping = function () {
		return this._entity.status_mapping();

	}

	this.to_json = function ()	{
		let list = this.get_list();

		let clean_list = [];

		for (let key in list) {
			let value = list[key];
			list[key].status = this.status_mapping()[value.status];
			let clean_list_entry = {};
			clean_list_entry["i"] = list[key]['i'];
			clean_list_entry["u"] = list[key]['u'];
			clean_list_entry["t"] = list[key]['t'];
			clean_list_entry["d"] = list[key]['d'];
			clean_list_entry["t"] = list[key]['t'];
			clean_list_entry["s"] = list[key]['s'];
			clean_list.push(clean_list_entry);
		}

		return {
			"page" : 1,
			"num_page" : 1,
			"num_item" : clean_list.length,
			"item" : clean_list
		};
	};

    return this;
};