'use strict'
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * User_image Add View Model
 *
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 */
 const db = require('../models');

module.exports = function (entity, pageName='', success, error, base_url = "") {

  this._entity = entity
  this.session  = null

  this.success = success || null
  this.error = error || null

  this._base_url = base_url

  this.endpoint = "/admin/image"

  this.get_page_name = () => pageName


  this.heading = "Edit image"

  this.action = "/admin/image-edit"
  
  
  

  this.form_fields = {"id":"","url":"","caption":"","width":"","height":"","type":"","status":"","user_id":""}

  
	this.type_mapping = function () {
		return this._entity.type_mapping();

	}

	this.status_mapping = function () {
		return this._entity.status_mapping();

	}



  return this
}
