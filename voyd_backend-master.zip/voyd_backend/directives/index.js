const VerifyUser = require('./VerifyUser');

module.exports = {
  verifyUser: VerifyUser,
};
