$(document).ready(function () {
if ($('.credential-email_status-autocomplete').length > 0) {
  $('.credential-email_status-autocomplete').select2({
    ajax: {
      url: "https://vyod.manaknightdigital.com/admin/credential/email_status-autocomplete",
      dataType: 'json',
      type: 'POST',
      data: function ({ term }) {
        return { term };
      },
      processResults: function (data) {
        return {
          results: $.map(data, function (item) {
            return {
              text: item.email+item.status,
              id: item.id,
            };
          }),
        };
      },
    },
    minimumInputLength: 3,
    width: '100%',
    templateResult: formatState,
  });

  function formatState(text) {
    str = '';
    str += "<p style='padding-left: 12px;'>" + text.text + '</p>';
    const $state = $(str);
    return $state;
  }
}

})