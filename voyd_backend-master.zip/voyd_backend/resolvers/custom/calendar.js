'use strict';
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * Calendar Events Resolvers
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 *
 */

const { validateInputForGraphql } = require('../../services/ValidationService');
const { formatError } = require('../../utils/formatError');
const { errorCodes } = require('../../core/strings');

const inputValidations = {
  Mutation: {
    syncCalendar: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          input: 'required|array',
          'input.*.event_id': 'required',
          'input.*.title': 'required',
          'input.*.start_date': 'required|dateiso',
          'input.*.end_date': 'required|dateiso',
        },
        {
          'input.required': 'Input field is required.',
          'input.array': 'Input field should be an array.',
          'event_id.required': 'Event Id field is required.',
          'title.required': 'Title field is required.',
          'start_date.required': 'Start Date field is required.',
          'start_date.dateiso': 'Invalid start date time. Supply date in ISO format.',
          'end_date.required': 'End Date field is required.',
          'end_date.dateiso': 'Invalid end date time. Supply date in ISO format.',
        },
      );
    },
    updateCalendarEvent: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
          title: 'required',
          date: 'required|dateiso',
        },
        {
          'id.required': 'Calendar Event ID is required.',
          'id.integer': 'Calendar Event ID should be an integer.',
          'title.required': 'Title field is required.',
          'date.required': 'Date field is required.',
          'date.dateiso': 'Invalid date time. Supply date in ISO format.',
        },
      );
    },
    deleteCalendarEvent: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
        },
        {
          'id.required': 'Calendar Event ID is required.',
          'id.integer': 'Calendar Event ID should be an integer.',
        },
      );
    },
  },
};

module.exports = {
  Query: {
    getAllCalendarEvents: async (_, __, { db, user }) => {
      try {
        const getAllEvents = await db.calendar.getAll({
          status: 1,
          user_id: user.id,
        });
        return {
          success: true,
          data: getAllEvents,
        };
      } catch (error) {
        return formatError(error);
      }
    },
  },
  Mutation: {
    syncCalendar: inputValidations.Mutation.syncCalendar(async (_, { input }, { db, user }) => {
      try {
        // Delete all previous events for the user
        const allUserEvents = await db.calendar.getAll({
          user_id: user.id,
          status: 1,
        });
        if (allUserEvents) {
          await db.calendar.realDelete(allUserEvents.map((event) => event.id));
        }

        const createIfNotExists = async (data) => {
          const fields = {
            user_id: user.id,
            event_id: data?.event_id,
            title: data?.title,
            start_date: data?.start_date,
            end_date: data?.end_date,
          };

          const eventExists = await db.calendar.getByFields({
            user_id: fields.user_id,
            event_id: fields.event_id,
          });

          if (!eventExists) {
            await db.calendar.insert(fields);
          } else {
            await db.calendar.edit(fields, eventExists.id);
          }
        };

        const tasks = input.map((task) => createIfNotExists(task));
        await Promise.all(tasks);
        return {
          success: true,
          message: 'Calendar synced successfully',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    updateCalendarEvent: inputValidations.Mutation.updateCalendarEvent(async (_, { id, title, start_date, end_date }, { db, user }) => {
      try {
        const getCalendarEvent = await db.calendar.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getCalendarEvent) {
          return {
            success: false,
            message: 'No such calendar event.',
            code: errorCodes.calendar.CALENDAR_EVENT_DOES_NOT_EXISTS,
          };
        }
        await db.calendar.edit(
          {
            title,
            start_date,
            end_date,
          },
          id,
        );
        return {
          success: true,
          message: 'Calender event updated successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    deleteCalendarEvent: inputValidations.Mutation.deleteCalendarEvent(async (_, { id }, { db, user }) => {
      try {
        const getCalendarEvent = await db.calendar.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getCalendarEvent) {
          return {
            success: false,
            message: 'No such calendar event.',
            code: errorCodes.calendar.CALENDAR_EVENT_DOES_NOT_EXISTS,
          };
        }
        await db.calendar.delete(id);
        return {
          success: true,
          message: 'Calender event deleted successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
  },
  Type: {
    Calendar: {
      user: (calendar, _, { db }) => {
        try {
          return db.user.getByFields({
            status: 1,
            id: calendar.user_id,
          });
        } catch (error) {
          return null;
        }
      },
    },
  },
};
