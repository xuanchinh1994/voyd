'use strict';
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * Custom Image Resolvers
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 *
 */

const fs = require('fs');
const path = require('path');

const { validateInputForGraphql } = require('../../services/ValidationService');
const { formatError } = require('../../utils/formatError');
const { errorCodes } = require('../../core/strings');

const UPLOADS_PATH = path.join(__dirname, '..', '..', 'uploads');

const inputValidations = {
  Mutation: {
    createCustomImage: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          url: 'required|string',
        },
        {
          'url.required': 'URL field is required.',
          'url.string': 'URL field should be string.',
        },
      );
    },
    updateCustomImage: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
          url: 'required|string',
        },
        {
          'id.required': 'Custom Image ID field is required.',
          'id.integer': 'Custom Image ID field should be an integer.',
          'url.required': 'URL field is required.',
          'url.string': 'URL field should be string.',
        },
      );
    },
    deleteCustomImage: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
        },
        {
          'id.required': 'Custom Image ID is required.',
          'id.integer': 'Custom Image ID should be an integer.',
        },
      );
    },
  },
};

module.exports = {
  Query: {
    getCustomImage: async (_, __, { db, user }) => {
      try {
        const getCustomImage = await db.image.getByFields({
          status: 1,
          user_id: user.id,
          type: 6,
        });
        return {
          success: true,
          data: getCustomImage,
        };
      } catch (error) {
        return formatError(error);
      }
    },
  },
  Mutation: {
    createCustomImage: inputValidations.Mutation.createCustomImage(async (_, { url }, { db, user }) => {
      try {
        const getCustomImage = await db.image.getByFields({
          status: 1,
          user_id: user.id,
          type: 6,
        });
        if (getCustomImage) {
          return {
            success: false,
            message: 'Custom Image/Video already exists.',
            code: errorCodes.extra.CUSTOM_IMAGE_OR_VIDEO_ALREADY_EXISTS,
          };
        }
        await db.image.insert({
          url,
          user_id: user.id,
          type: 6,
        });
        return {
          success: true,
          message: 'Custom Image/Video created successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    updateCustomImage: inputValidations.Mutation.updateCustomImage(async (_, { id, url }, { db, user }) => {
      try {
        const getCustomImage = await db.image.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getCustomImage) {
          return {
            success: false,
            message: 'No such custom image.',
            code: errorCodes.extra.CUSTOM_IMAGE_OR_VIDEO_DOES_NOT_EXISTS,
          };
        }
        try {
          fs.unlinkSync(path.join(UPLOADS_PATH, getCustomImage.url));
        } catch (error) {
          // Fail silently
        }

        await db.image.edit(
          {
            url,
          },
          id,
        );
        return {
          success: true,
          message: 'Custom Image/Video updated successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    deleteCustomImage: inputValidations.Mutation.deleteCustomImage(async (_, { id }, { db, user }) => {
      try {
        const getCustomImage = await db.image.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getCustomImage) {
          return {
            success: false,
            message: 'No such custom image.',
            code: errorCodes.extra.CUSTOM_IMAGE_OR_VIDEO_DOES_NOT_EXISTS,
          };
        }
        try {
          fs.unlinkSync(path.join(UPLOADS_PATH, getCustomImage.url));
        } catch (error) {
          // Fail silently
        }
        await db.image.realDelete(id);
        return {
          success: true,
          message: 'Custom Image/Video deleted successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
  },
};
