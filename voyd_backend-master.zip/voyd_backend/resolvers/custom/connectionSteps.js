'use strict';

const IMAGES_BASE_PATH = '/images/steps';
const NUMBER_OF_STEPS = 3;

module.exports = {
  Query: {
    getStepsImages: async () => {
      return {
        success: true,
        data: new Array(NUMBER_OF_STEPS).fill(0).map((_, index) => `${IMAGES_BASE_PATH}/${index+1}.jpg`),
      };
    },
  },
  Mutation: {},
};
