const { createWriteStream, mkdirSync } = require('fs');
const { nanoid } = require('nanoid');
const path = require('path');

const { formatError } = require('../../utils/formatError');

const FOLDER_NAME = 'userUploads';

module.exports = async (_, { file }) => {
  try {
    const fileResponse = await file;
    const { createReadStream, filename, mimetype } = fileResponse;

    const stream = createReadStream();
    const id = nanoid();

    const actualFileName = id + '_' + filename;

    const filePath = path.join(__dirname, '..', '..', 'uploads', FOLDER_NAME, actualFileName);

    const uploadPath = path.join(__dirname, '..', '..', 'uploads', FOLDER_NAME);

    mkdirSync(uploadPath, { recursive: true });

    await stream.pipe(createWriteStream(filePath));

    return {
      success: true,
      data: { id, filename, mimetype, path: `/${FOLDER_NAME}/` + actualFileName },
    };
  } catch (error) {
    console.log(JSON.stringify({ error }, null, 2));
    return formatError(error);
  }
};
