'use strict';
/*Powered By: Manaknightdigital Inc. https://manaknightdigital.com/ Year: 2021*/
/**
 * Calendar Events Resolvers
 * @copyright 2021 Manaknightdigital Inc.
 * @link https://manaknightdigital.com
 * @license Proprietary Software licensing
 * @author Ryan Wong
 *
 */

const { validateInputForGraphql } = require('../../services/ValidationService');
const { formatError } = require('../../utils/formatError');
const { errorCodes } = require('../../core/strings');

const inputValidations = {
  Mutation: {
    createNote: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          message: 'required|string',
        },
        {
          'message.required': 'Message field is required.',
          'message.string': 'Message field should be a string.',
        },
      );
    },
    updateNote: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
          message: 'required|string',
        },
        {
          'id.required': 'Note ID is required.',
          'id.integer': 'Note ID should be an integer.',
          'message.required': 'Message field is required.',
          'message.string': 'Message field should be a string.',
        },
      );
    },
    deleteNote: (resolver = () => null) => {
      return validateInputForGraphql(
        resolver,
        {
          id: 'required|integer',
        },
        {
          'id.required': 'Note ID is required.',
          'id.integer': 'Note ID should be an integer.',
        },
      );
    },
  },
};
module.exports = {
  Query: {
    getAllNotes: async (_, __, { db, user }) => {
      try {
        const getAllNotes = await db.note.getAll({
          status: 1,
          user_id: user.id,
        });
        return {
          success: true,
          data: getAllNotes,
        };
      } catch (error) {
        return formatError(error);
      }
    },
  },
  Mutation: {
    createNote: inputValidations.Mutation.createNote(async (_, { message }, { db, user }) => {
      try {
        await db.note.insert({
          message,
          user_id: user.id,
        });

        return {
          success: true,
          message: 'Note added successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    updateNote: inputValidations.Mutation.updateNote(async (_, { id, message }, { db, user }) => {
      try {
        const getNote = await db.note.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getNote) {
          return {
            success: false,
            message: 'No such note exists.',
            code: errorCodes.note.NOTE_DOES_NOT_EXISTS,
          };
        }
        await db.note.edit(
          {
            message,
          },
          id,
        );
        return {
          success: true,
          message: 'Note updated successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
    deleteNote: inputValidations.Mutation.deleteNote(async (_, { id }, { db, user }) => {
      try {
        const getNote = await db.note.getByFields({
          id: id,
          user_id: user.id,
          status: 1,
        });
        if (!getNote) {
          return {
            success: false,
            message: 'No such note exists.',
            code: errorCodes.note.NOTE_DOES_NOT_EXISTS,
          };
        }
        await db.note.realDelete(id);
        return {
          success: true,
          message: 'Note deleted successfully.',
        };
      } catch (error) {
        return formatError(error);
      }
    }),
  },
  Type: {
    Note: {
      user: (note, _, { db }) => {
        try {
          console.log('note', JSON.stringify(note, null, 2));
          return db.user.getByFields({
            status: 1,
            id: note.user_id,
          });
        } catch (error) {
          return null;
        }
      },
    },
  },
};
