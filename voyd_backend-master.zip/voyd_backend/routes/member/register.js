'use strict'

const ValidationService = require('../../services/ValidationService')
const AuthService = require('../../services/AuthService')
const JWTService = require('../../services/JwtService')
const SessionService = require('../../services/SessionService')
const MailService = require('../../services/MailService')

const db = require('../../models')
const { errors } = require('../../core/strings')
const Utilities = require('../../utils')

module.exports = {
  initializeApp: function (app) {
    const role_id = 2

    // app.get(
    //   '/member/register',
    //   SessionService.preventAuthRoutes(role_id, 'member'),
    //   async function (req, res, next) {
    //     const AuthViewModel = require('../../view_models/member_auth_view_model')

    //     const viewModel = new AuthViewModel(db.user, 'Register')

    //     return res.render('member/Register', viewModel)
    //   }
    // )

    // app.post(
    //   '/member/register',

    //   ValidationService.validateInput(
    //     {
    //       email: 'required|email',
    //       code: 'required',
    //       first_name: 'required',
    //       last_name: 'required',
    //       password: 'required|minLength:6',
    //       confirm_password: 'required|minLength:6',
    //     },
    //     {
    //       'email.required': 'Email is required',
    //       'code.required': 'Code is required',
    //       'first_name.required': 'First name is required',
    //       'last_name.required': 'Last name is required',
    //       'email.email': 'Invalid email',
    //       'password.required': 'Password is required.',
    //       'confirm_password.required': 'Password is required.',
    //       'password.minLength':
    //         'Password should be at least 6 characters long.',
    //       'confirm_password.minLength':
    //         'Password should be at least 6 characters long.',
    //     }
    //   ),

    //   async function (req, res, next) {
    //     const role_id = 2
    //     const {
    //       email,
    //       code,
    //       first_name,
    //       last_name,
    //       password,
    //       confirm_password,
    //     } = req.body

    //     const AuthViewModel = require('../../view_models/member_auth_view_model')

    //     const viewModel = new AuthViewModel(db.user, 'Register')

    //     ValidationService.handleValidationErrorForViews(
    //       req,
    //       res,
    //       viewModel,
    //       'member/Register',
    //       'register_fields',
    //       { email, first_name, last_name }
    //     )

    //     let newCredential = null
    //     let newUser = null

    //     try {
    //       if (password !== confirm_password) {
    //         viewModel.error = 'Passwords do not match'
    //         viewModel.register_fields.email = email
    //         viewModel.register_fields.first_name = first_name
    //         viewModel.register_fields.last_name = last_name
    //         return res.render('member/Register', viewModel)
    //       }

    //       const { user } = await AuthService.register(
    //         email,
    //         password,
    //         role_id,
    //         code,
    //         {
    //           first_name,
    //           last_name,
    //         }
    //       )

    //       if (user) {
    //         // create new session
    //         const session = req.session
    //         session.role = role_id
    //         session.user = newUser

    //         return session.save((error) => {
    //           if (error) {
    //             throw new Error(error)
    //           }
    //           return res.redirect('/member/dashboard')
    //         })
    //       }

    //       throw new Error()
    //     } catch (error) {
    //       console.error(error)
    //       if (newCredential) {
    //         await viewModel.destroy_credential(newCredential)
    //       }
    //       if (newUser) {
    //         await viewModel.destroy_user(newUser)
    //       }
    //       viewModel.error = error.message || 'Something went wrong'
    //       viewModel.register_fields.email = email
    //       viewModel.register_fields.first_name = first_name
    //       viewModel.register_fields.last_name = last_name
    //       return res.render('member/Register', viewModel)
    //     }
    //   }
    // )

    app.post(
      '/member/api/register',
      ValidationService.validateInput(
        {
          email: 'required|email',
          first_name: 'required|string',
          last_name: 'required|string',
          password: 'required|minLength:6',
          code: 'required',
        },
        {
          'email.required': 'Email is required',
          'first_name.required': 'First name is required',
          'first_name.string': 'First name should be a string.',
          'last_name.required': 'Last name is required',
          'last_name.string': 'Last name should be a string',
          'email.email': 'Invalid email',
          'password.required': 'Password is required.',
          'password.minLength':
            'Password should be at least 6 characters long.',
          'code.required': 'Code is required',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      async function (req, res) {
        const role_id = 2

        const { email, password, first_name, last_name, code } = req.body

        let Credential
        let User

        try {
          const payload = await AuthService.register(
            email,
            password,
            role_id,
            code,
            {
              first_name: Utilities.capitalizeFirstLetter(first_name),
              last_name: Utilities.capitalizeFirstLetter(last_name),
            }
          )

          const { credential, user } = payload

          if (!credential) {
            throw new Error('EMAIL_ADDRESS_NOT_FOUND')
          }
          User = user
          Credential = credential

          MailService.initialize({
            hostname: process.env.EMAIL_SMTP_SMTP_HOST,
            port: process.env.EMAIL_SMTP_SMTP_PORT,
            username: process.env.EMAIL_SMTP_SMTP_USER,
            password: process.env.EMAIL_SMTP_SMTP_PASS,
            from: process.env.MAIL_FROM,
            to: email,
          })

          const registerMailTemplate = await MailService.template('register')

          const registerMailFinalTemplate = MailService.inject(
            {
              body: registerMailTemplate.html,
              subject: registerMailTemplate.subject,
            },
            {
              first_name: Utilities.capitalizeFirstLetter(first_name),
            }
          )

          await MailService.send(registerMailFinalTemplate)

          await AuthService.verifyAccount({ email, roleId: role_id })

          const tokenPayload = {
            credential_id: credential,
            user: { id: user.id },
            role_id,
          }

          const response = {
            access_token: JWTService.createAccessToken(tokenPayload),
            refresh_token: JWTService.createRefreshToken(tokenPayload),
            user_id: user.id,
            email,
            image: user.image,
            first_name: user.first_name,
            last_name: user.last_name,
          }

          return res.status(201).json({ success: true, data: response })
        } catch (error) {
          try {
            if (Credential) {
              await db.credential.realDelete(Credential)
            }
            if (User) {
              await db.user.realDelete(User.id)
            }
          } catch (_) {}
          console.error(error)
          let message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({
            success: false,
            message,
            ...(error?.message ? { code: error.message } : {}),
          })
        }
      }
    )

    app.post(
      '/member/api/verify-account',
      ValidationService.validateInput(
        {
          email: 'required|email',
        },
        {
          'email.required': 'Email is required.',
          'email.email': 'Invalid email.',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      async (req, res, next) => {
        const role_id = 2

        const { email } = req.body

        try {
          await AuthService.verifyAccount({ email, roleId: role_id })
          return res.status(200).json({
            success: true,
            message: 'An account verification link is sent to your inbox.',
          })
        } catch (error) {
          console.log(error, __filename)
          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({
            success: false,
            message,
            ...(error?.message ? { code: error.message } : {}),
          })
        }
      }
    )
    return app
  },
}
