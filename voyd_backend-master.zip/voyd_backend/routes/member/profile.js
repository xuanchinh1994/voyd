'use strict'

const ValidationService = require('../../services/ValidationService')
const AuthService = require('../../services/AuthService')
const JWTService = require('../../services/JwtService')
const SessionService = require('../../services/SessionService')
const PasswordService = require('../../services/PasswordService')
const db = require('../../models')
const { errors } = require('../../core/strings')
const { validateEmail } = require('../../core/utils')

module.exports = {
  initializeApp: function (app) {
    const role_id = 2

    // app.get(
    //   '/member/profile',
    //   SessionService.verifySessionMiddleware(role_id, 'member'),

    //   async function (req, res, next) {
    //     const user = req.session.user;

    //     const AuthViewModel = require('../../view_models/member_auth_view_model');

    //     const viewModel = new AuthViewModel(db.user, 'Profile');
    //     const { user_id } = req.body;
    //     console.log('User Id: ' + req.body);
    //     viewModel._base_url = '/member/profile';

    //     if (!user || !user.id) {
    //       viewModel.error = 'xUserNotFound';
    //       return res.render('member/Profile', viewModel);
    //     }
    //     if (req.session.csrf === undefined) {
    //       req.session.csrf = SessionService.randomString(100);
    //     }

    //     try {
    //       const exists = await db.user.get_user_credential(user.id, db);
    //       if (!exists || +exists.status === 0 || exists.credential.role_id !== role_id) {
    //         viewModel.error = 'profile_not_found';
    //         return res.render('member/Profile', viewModel);
    //       }
    //       const values = exists;
    //       Object.keys(viewModel.form_fields).forEach((field) => {
    //         if (field === 'email') {
    //           viewModel.form_fields[field] = values['credential'][field];
    //           return;
    //         }

    //         viewModel.form_fields[field] = values[field];
    //       });

    //       return res.render('member/Profile', viewModel);
    //     } catch (error) {
    //       viewModel.error = 'Something went wrong';
    //       return res.render('member/Profile', viewModel);
    //     }
    //   },
    // );

    app.post(
      '/member/api/update-profile',
      JWTService.verifyTokenMiddleware(role_id),
      ValidationService.validateInput(
        {
          first_name: 'required',
          last_name: 'required',
        },
        {
          'first_name.required': 'First name is required',
          'last_name.required': 'Last name is required',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      async function (req, res, next) {
        let UserRef
        let CredentialRef

        let User
        let Credential

        const { email, first_name, last_name } = req.body
        const tokenPayload = req?.tokenPayload
        const credentialId = tokenPayload?.credential_id

        const credentialFields = {
          ...(email !== undefined ? { email } : {}),
        }

        try {
          CredentialRef = await db.credential.getByFields({
            id: credentialId,
            status: 1,
            role_id,
          })

          if (!CredentialRef) throw new Error('EMAIL_ADDRESS_NOT_FOUND')

          const credentialType = CredentialRef.type

          UserRef = await db.user.getByFields({
            id: CredentialRef.user_id,
            status: 1,
          })

          if (!UserRef) throw new Error('EMAIL_ADDRESS_NOT_FOUND')

          if (credentialType === 'n' && credentialFields.email) {
            if (!validateEmail(credentialFields.email)) {
              return res.status(400).json({
                success: false,
                message: 'Invalid email address',
              })
            }

            // Check if user is changing email or not
            if (CredentialRef.email !== credentialFields.email) {
              const userExists = await db.credential.getByField(
                'email',
                credentialFields.email
              )
              if (userExists) {
                throw new Error('EMAIL_ADDRESS_ALREADY_EXIST')
              }
              Credential = await db.credential.edit(
                {
                  email: email,
                },
                CredentialRef.id
              )
            }
          }

          User = await db.user.edit(
            {
              first_name:
                typeof first_name === 'string'
                  ? first_name?.substring(0, 1).toUpperCase() +
                    first_name?.substring(1)?.toLowerCase()
                  : first_name,
              last_name:
                typeof last_name === 'string'
                  ? last_name?.substring(0, 1).toUpperCase() +
                    last_name?.substring(1)?.toLowerCase()
                  : last_name,
            },
            UserRef.id
          )

          return res.status(200).json({
            success: true,
            message: 'Profile updated successfully',
          })
        } catch (error) {
          try {
            if (Credential && CredentialRef) {
              await db.credential.edit(
                {
                  email: CredentialRef.email,
                },
                CredentialRef.id
              )
            }
            if (User && UserRef) {
              await db.user.edit(
                {
                  first_name: UserRef.first_name,
                  last_name: UserRef.last_name,
                },
                UserRef.id
              )
            }
          } catch (_) {}

          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({ success: false, message })
        }
      }
    )

    app.post(
      '/member/api/change-password',
      JWTService.verifyTokenMiddleware(role_id),
      ValidationService.validateInput(
        {
          old_password: 'required',
          new_password: 'required|minLength:6',
        },
        {
          'old_password.required': 'Old password is required.',
          'new_password.required': 'New password is required',
          'new_password.minLength':
            'New password should be at least 6 characters long.',
        }
      ),
      ValidationService.handleValidationErrorForAPI,

      async function (req, res, next) {
        const { old_password, new_password } = req.body
        const tokenPayload = req?.tokenPayload
        const credentialId = tokenPayload?.credential_id
        try {
          const userCredential = await db.credential.getByFields({
            id: credentialId,
            status: 1,
            role_id,
          })

          if (!userCredential) throw new Error('EMAIL_ADDRESS_NOT_FOUND')

          const credentialType = userCredential.type

          const user = await db.user.getByFields({
            id: userCredential.user_id,
            status: 1,
          })

          if (!user) throw new Error('EMAIL_ADDRESS_NOT_FOUND')

          if (credentialType !== 'n') {
            return res.status(400).json({
              success: false,
              message:
                "Can't change password for account registered with " +
                  credentialType ==
                'g'
                  ? 'Google'
                  : 'Facebook',
            })
          }

          const isOldPasswordCorrect = await PasswordService.compareHash(
            old_password,
            userCredential.password
          )
          if (!isOldPasswordCorrect) {
            return res.status(400).json({
              success: true,
              message: 'Wrong old password.',
            })
          }
          const hashedNewPassword = await PasswordService.hash(new_password)
          await db.credential.edit(
            {
              password: hashedNewPassword,
            },
            userCredential.id
          )

          return res.status(200).json({
            success: true,
            message: 'Password changed successfully',
          })
        } catch (error) {
          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({ success: false, message })
        }
      }
    )

    return app
  },
}
