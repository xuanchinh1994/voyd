'use strict';

const db = require('../../models');
const { errors } = require('../../core/strings');

module.exports = {
  initializeApp: function (app) {
    app.get(
      '/member/verify-account/:token',

      async function (req, res, next) {
        const role_id = 2;

        const { token } = req.params;

        const AuthViewModel = require('../../view_models/member_auth_view_model');

        const viewModel = new AuthViewModel(db.user, 'Account Verification');

        try {
          let decodedToken;
          try {
            decodedToken = Buffer.from(token, 'base64')?.toString();
          } catch (error) {
            console.log('Error', error);
            return res.redirect('/member/login');
          }
          const credential = await db.credential.getByFields({
            id: decodedToken,
            role_id,
            status: 1,
          });

          if (!credential) {
            return res.redirect('/member/login');
          }

          if (+credential?.verify) {
            viewModel.success = 'Account already verified.';
            return res.render('member/VerifyAccount', viewModel);
          }

          await db.credential.edit({ verify: 1 }, credential.id);

          viewModel.success = `Account verified for ${credential.email}`;
          return res.render('member/VerifyAccount', viewModel);
        } catch (error) {
          viewModel.error = errors[error.message] || 'Something went wrong';
          return res.render('member/Login', viewModel);
        }
      },
    );

    return app;
  },
};
