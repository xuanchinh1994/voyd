'use strict'

const ValidationService = require('../../services/ValidationService')
const AuthService = require('../../services/AuthService')
const JWTService = require('../../services/JwtService')
const SessionService = require('../../services/SessionService')
const db = require('../../models')
const { errors } = require('../../core/strings')
const Utilities = require('../../utils')

module.exports = {
  initializeApp: function (app) {
    const role_id = 2

    // app.get('/member/login', SessionService.preventAuthRoutes(role_id, 'member'), async function (req, res, next) {
    //   const AuthViewModel = require('../../view_models/member_auth_view_model');

    //   const viewModel = new AuthViewModel(db.user, 'Login');

    //   return res.render('member/Login', viewModel);
    // });

    // app.post(
    //   '/member/login',

    //   ValidationService.validateInput(
    //     {
    //       email: 'required|email',
    //       password: 'required|minLength:6',
    //     },
    //     {
    //       'email.required': 'Email is required',
    //       'email.email': 'Invalid email',
    //       'password.required': 'Password is required.',
    //       'password.minLength': 'Password should be at least 6 characters long.',
    //     },
    //   ),

    //   async function (req, res, next) {
    //     const role_id = 2;
    //     const { email, password } = req.body;

    //     const AuthViewModel = require('../../view_models/member_auth_view_model');

    //     const viewModel = new AuthViewModel(db.user, 'Login');

    //     ValidationService.handleValidationErrorForViews(req, res, viewModel, 'member/Login', 'login_fields', { email });

    //     try {
    //       const { user } = await AuthService.login(email, password, role_id);

    //       const session = req.session;

    //       session.role = role_id;
    //       session.user = user;

    //       return session.save((error) => {
    //         if (error) {
    //           throw new Error(error);
    //         }
    //         return res.redirect('/member/dashboard');
    //       });
    //     } catch (error) {
    //       viewModel.error = errors[error.message] || 'Something went wrong';
    //       viewModel.login_fields.email = email;
    //       return res.render('member/Login', viewModel);
    //     }
    //   },
    // );

    app.post(
      '/member/api/login',
      ValidationService.validateInput(
        {
          email: 'required|email',
          password: 'required',
        },
        {
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
          'password.required': 'Password is required.',
        }
      ),
      ValidationService.handleValidationErrorForAPI,

      async function (req, res, next) {
        const role_id = 2

        const { email, password } = req.body

        try {
          const payload = await AuthService.login(email, password, role_id)

          const { user, credential } = payload

          const tokenPayload = {
            credential_id: credential,
            user: {
              id: user.id,
            },
            role_id,
          }

          const response = {
            access_token: JWTService.createAccessToken(tokenPayload),
            refresh_token: JWTService.createRefreshToken(tokenPayload),
            user_id: user.id,
            email,
            image: user.image,
            first_name: Utilities.capitalizeFirstLetter(user.first_name),
            last_name: Utilities.capitalizeFirstLetter(user.last_name),
          }

          return res.status(200).json({ success: true, data: response })
        } catch (error) {
          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({
            success: false,
            message,
            ...(error?.message ? { code: error.message } : {}),
          })
        }
      }
    )

    app.post(
      '/member/api/refresh-token',
      ValidationService.validateInput(
        {
          refresh_token: 'required',
        },
        {
          'refresh_token.required': 'Refresh token is required',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      async function (req, res, next) {
        const { refresh_token } = req.body

        try {
          const verify = JWTService.verifyRefreshToken(refresh_token)

          if (!verify) {
            return res.status(403).json({
              success: false,
              message: 'Invalid refresh token',
              code: 'INVALID_REFRESH_TOKEN',
            })
          } else {
            delete verify.iat
            delete verify.exp
            delete verify.nbf
            delete verify.jti //We are generating a new token, if you are using jwtid during signing, pass it in refreshOptions
            const access_token = JWTService.createAccessToken(verify)
            const refresh_token = JWTService.createRefreshToken(verify)

            return res
              .status(201)
              .json({ success: true, data: { access_token, refresh_token } })
          }
        } catch (err) {
          return res
            .status(500)
            .json({ success: false, message: 'Something went wrong' })
        }
      }
    )

    return app
  },
}
