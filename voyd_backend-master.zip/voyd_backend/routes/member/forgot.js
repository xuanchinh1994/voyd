'use strict'

const ValidationService = require('../../services/ValidationService')
const SessionService = require('../../services/SessionService')
const db = require('../../models')
const { errors, errorCodes } = require('../../core/strings')
const { customAlphabet } = require('nanoid')

function isAccountVerified({ role_id = 2 }) {
  return async (req, res, next) => {
    const { email } = req.body
    if (!email) {
      return res.status(404).json({
        success: false,
        message: 'Email missing. Make sure to pass email as well.',
      })
    }
    const getUserCredential = await db.credential.getByFields({
      status: 1,
      email,
      role_id,
    })
    if (!getUserCredential) {
      return res.status(404).json({
        success: false,
        message: 'Account does not exists.',
        code: errorCodes.account.ACCOUNT_DOES_NOT_EXISTS,
      })
    }
    if (!+getUserCredential?.verify) {
      return res.json({
        success: false,
        message: 'Account not verified. Verify your account first.',
        code: errorCodes.account.ACCOUNT_NOT_VERIFIED,
      })
    }
    next()
  }
}

module.exports = {
  initializeApp: function (app) {
    const role_id = 2

    // app.get('/member/forgot', SessionService.preventAuthRoutes(role_id, 'member'), async function (req, res, next) {
    //   const AuthViewModel = require('../../view_models/member_auth_view_model');

    //   const viewModel = new AuthViewModel(db.user, 'Forgot Password');

    //   return res.render('member/Forgot', viewModel);
    // });

    // app.post(
    //   '/member/forgot',

    //   ValidationService.validateInput(
    //     {
    //       email: 'required|email',
    //     },
    //     {
    //       'email.required': 'Email is required',
    //       'email.email': 'Invalid email',
    //     },
    //   ),
    //   async function (req, res, next) {
    //     const role_id = 2;
    //     const { email } = req.body;

    //     const AuthViewModel = require('../../view_models/member_auth_view_model');

    //     const viewModel = new AuthViewModel(db.user, 'Forgot Password');

    //     ValidationService.handleValidationErrorForViews(req, res, viewModel, 'member/Forgot', 'forgot_fields', { email });

    //     try {
    //       const accountExists = await viewModel.account_exists(email, {
    //         role_id,
    //       });
    //       if (!accountExists) {
    //         viewModel.error = "Account doesn't exists.";
    //         return res.render('member/Forgot', viewModel);
    //       }

    //       const user = await viewModel.get_associated_user(accountExists.user_id);

    //       if (!user) {
    //         viewModel.error = "Account doesn't exists.";
    //         return res.render('member/Forgot', viewModel);
    //       }

    //       viewModel.initializeMailService(email);
    //       const mailTemplate = await viewModel.getForgotPasswordMailTemplate('reset-password');

    //       if (!mailTemplate) {
    //         throw new Error();
    //       }

    //       const token = viewModel.generateRandomToken();

    //       if (!token) {
    //         throw new Error();
    //       }

    //       const finalTemplate = viewModel.injectMailTemplate(
    //         {
    //           body: mailTemplate.html,
    //           subject: mailTemplate.subject,
    //         },
    //         {
    //           email,
    //           link: process.env.BASE_URL + '/member/reset',
    //           reset_token: token,
    //         },
    //       );

    //       if (!finalTemplate) {
    //         throw new Error();
    //       }

    //       await viewModel.saveTokenToDB(token, user.id);

    //       await viewModel.sendMail(finalTemplate);

    //       viewModel.success = 'A password reset link is sent to your inbox.';
    //       return res.render('member/Login', viewModel);
    //     } catch (error) {
    //       viewModel.error = 'Something went wrong';
    //       return res.render('member/Forgot', viewModel);
    //     }
    //   },
    // );

    // app.get('/member/reset/:token', SessionService.preventAuthRoutes(role_id, 'member'), async function (req, res, next) {
    //   const token = req.params.token;
    //   if (!token) {
    //     viewModel.error = 'Invalid token';
    //     return res.render('member/Login', viewModel);
    //   }
    //   const AuthViewModel = require('../../view_models/member_auth_view_model');

    //   const viewModel = new AuthViewModel(db.user, 'Reset Password');

    //   viewModel.resetToken = token;

    //   try {
    //     const tokenValid = await viewModel.validateToken(token);
    //     if (!tokenValid) {
    //       viewModel.error = 'Invalid token';
    //       return res.render('member/Login', viewModel);
    //     }
    //     return res.render('member/Reset', viewModel);
    //   } catch (error) {
    //     viewModel.error = 'Something went wrong';
    //     return res.render('member/Login', viewModel);
    //   }
    // });

    // app.post(
    //   '/member/reset/:token',

    //   ValidationService.validateInput(
    //     {
    //       password: 'required|minLength:6',
    //       confirm_password: 'required|minLength:6',
    //     },
    //     {
    //       'password.required': 'Password is required.',
    //       'confirm_password.required': 'Password is required.',
    //       'password.minLength': 'Password should be at least 6 characters long.',
    //       'confirm_password.minLength': 'Password should be at least 6 characters long.',
    //     },
    //   ),
    //   async function (req, res, next) {
    //     const token = req.params.token;
    //     const { password, confirm_password } = req.body;

    //     if (!token) {
    //       viewModel.error = 'Invalid token';
    //       return res.render('member/Login', viewModel);
    //     }

    //     if (password !== confirm_password) {
    //       viewModel.error = 'Passwords do not match';
    //       return res.render('member/Reset', viewModel);
    //     }
    //     const AuthViewModel = require('../../view_models/member_auth_view_model');

    //     const viewModel = new AuthViewModel(db.user, 'Reset Password');
    //     viewModel.resetToken = token;

    //     ValidationService.handleValidationErrorForViews(req, res, viewModel, 'member/Reset', 'reset_fields', { password, confirm_password });

    //     try {
    //       const tokenValid = await viewModel.validateToken(token);
    //       if (!tokenValid) {
    //         viewModel.error = 'Invalid token';
    //         return res.render('member/Login', viewModel);
    //       }

    //       const hashPassword = await viewModel.generate_hash(password);
    //       if (!hashPassword) {
    //         throw new Error();
    //       }
    //       const userCredential = await viewModel.getUserCredential(tokenValid.user_id);

    //       if (!userCredential) {
    //         throw new Error();
    //       }
    //       await viewModel.updatePassword(hashPassword, userCredential.id);

    //       viewModel.success = 'Password reset successful';
    //       return res.render('member/Login', viewModel);
    //     } catch (error) {
    //       viewModel.error = 'Something went wrong';
    //       return res.render('member/Reset', viewModel);
    //     }
    //   },
    // );

    // API
    app.post(
      '/member/api/forgot',

      ValidationService.validateInput(
        {
          email: 'required|email',
        },
        {
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      isAccountVerified({ role_id }),
      async function (req, res, next) {
        const role_id = 2
        const { email } = req.body

        const AuthViewModel = require('../../view_models/member_auth_view_model')

        const viewModel = new AuthViewModel(db.user)

        try {
          const accountExists = await viewModel.account_exists(email, {
            role_id,
          })
          if (!accountExists) {
            return res.status(404).json({
              success: false,
              message: "Account doesn't exists.",
              code: errorCodes.account.ACCOUNT_DOES_NOT_EXISTS,
            })
          }

          const user = await viewModel.get_associated_user(
            accountExists.user_id
          )

          if (!user) {
            return res.status(404).json({
              success: false,
              message: "Account doesn't exists.",
              code: errorCodes.account.ACCOUNT_DOES_NOT_EXISTS,
            })
          }

          viewModel.initializeMailService(email)
          const mailTemplate = await viewModel.getForgotPasswordMailTemplate(
            'reset-password-mobile'
          )

          if (!mailTemplate) {
            throw new Error()
          }

          const token = customAlphabet('0123456789', 8)()

          if (!token) {
            throw new Error()
          }

          const finalTemplate = viewModel.injectMailTemplate(
            {
              body: mailTemplate.html,
              subject: mailTemplate.subject,
            },
            {
              email,
              code: token,
            }
          )

          if (!finalTemplate) {
            throw new Error()
          }
          const previousTokens = await db.token.getAll({
            user_id: accountExists.user_id,
          })
          if (previousTokens?.length) {
            await db.token.realDelete(previousTokens)
          }
          await viewModel.saveTokenToDB(token, user.id)
          await viewModel.sendMail(finalTemplate)

          return res.status(200).json({
            success: true,
            message: 'A password reset code is sent to your inbox.',
          })
        } catch (error) {
          return res.status(500).json({
            success: false,
            message: 'Something went wrong',
            ...(error?.message ? { code: error.message } : {}),
          })
        }
      }
    )

    app.post(
      '/member/api/validate-reset-code/',

      ValidationService.validateInput(
        {
          code: 'required|minLength:8',
          email: 'required|email',
        },
        {
          'code.required': 'Confirmation code is required.',
          'code.minLength': 'Code should be at least 8 characters long.',
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
        }
      ),
      ValidationService.handleValidationErrorForAPI,
      isAccountVerified({ role_id }),

      async function (req, res, next) {
        const role_id = 2
        const { code } = req.body

        if (!code) {
          throw new Error('INVALID_EMAIL_CONFIRMATION_CODE')
        }

        const AuthViewModel = require('../../view_models/member_auth_view_model')

        const viewModel = new AuthViewModel(db.user)

        try {
          const tokenValid = await viewModel.validateToken(code)
          if (!tokenValid) {
            throw new Error('INVALID_EMAIL_CONFIRMATION_CODE')
          }

          const userCredential = await viewModel.getUserCredential(
            tokenValid.user_id,
            role_id
          )

          if (!userCredential) {
            throw new Error('INVALID_EMAIL_CONFIRMATION_CODE')
          }

          return res
            .status(200)
            .json({ success: true, message: 'Code is valid' })
        } catch (error) {
          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({
            success: false,
            message,
            ...(error?.message ? { code: error.message } : {}),
          })
        }
      }
    )
    app.post(
      '/member/api/reset-password',

      ValidationService.validateInput(
        {
          code: 'required|minLength:8',
          password: 'required|minLength:6',
          email: 'required|email',
        },
        {
          'password.required': 'Password is required.',
          'password.minLength':
            'Password should be at least 6 characters long.',
          'code.required': 'Confirmation code is required.',
          'code.minLength': 'Code should be at least 8 characters long.',
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
        }
      ),
      ValidationService.handleValidationErrorForAPI,

      isAccountVerified({ role_id }),

      async function (req, res, next) {
        const role_id = 2
        const { code, password } = req.body

        if (!code) {
          throw new Error(errors.INVALID_EMAIL_CONFIRMATION_CODE)
        }

        const AuthViewModel = require('../../view_models/member_auth_view_model')

        const viewModel = new AuthViewModel(db.user)

        try {
          const tokenValid = await viewModel.validateToken(code)
          if (!tokenValid) {
            throw new Error('INVALID_EMAIL_CONFIRMATION_CODE')
          }

          const userCredential = await viewModel.getUserCredential(
            tokenValid.user_id,
            role_id
          )

          if (!userCredential) {
            // Return code invalid if user doesn't exist
            throw new Error('INVALID_EMAIL_CONFIRMATION_CODE')
          }

          const hashPassword = await viewModel.generate_hash(password)
          if (!hashPassword) {
            throw new Error()
          }

          await viewModel.updatePassword(hashPassword, userCredential.id)

          await db.token.realDeleteByUniqueField('token', code)

          return res
            .status(200)
            .json({ success: true, message: 'Password reset successful.' })
        } catch (error) {
          const message = errors[error.message] || 'Something went wrong'
          return res.status(500).json({
            success: false,
            message,
            code:
              error.message === 'INVALID_EMAIL_CONFIRMATION_CODE'
                ? 'INVALID_CODE'
                : null,
          })
        }
      }
    )

    return app
  },
}
