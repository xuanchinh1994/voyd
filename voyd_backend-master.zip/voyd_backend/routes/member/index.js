const Forgot = require("./forgot");
const Login = require("./login");
const Logout = require("./logout");
const Profile = require("./profile");
const Register = require("./register");
const VerifyAccount = require("./verifyAccount");

module.exports = {
            initializeApp: function (app) {
              const routes = [Forgot,Login,Logout,Profile,Register,VerifyAccount]
              routes.forEach((item) => item.initializeApp(app))
            },
          }
          