const AdminRoutes = require("./admin/index");
const MemberRoutes = require("./member/index");


module.exports = function initializeApp(app) {
     const allRoutes = [AdminRoutes,MemberRoutes];

allRoutes.forEach(item => item.initializeApp(app))
     return app
    };
    