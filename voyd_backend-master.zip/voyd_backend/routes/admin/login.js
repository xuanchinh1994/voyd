'use strict';

const ValidationService = require('../../services/ValidationService');
const AuthService = require('../../services/AuthService');
const JWTService = require('../../services/JwtService');
const SessionService = require('../../services/SessionService');
const db = require('../../models');
const { errors } = require('../../core/strings');

module.exports = {
  initializeApp: function (app) {
    const role_id = 1;

    app.get('/admin/login', SessionService.preventAuthRoutes(role_id, 'admin'), async function (req, res, next) {
      const AuthViewModel = require('../../view_models/admin_auth_view_model');

      const viewModel = new AuthViewModel(db.user, 'Login');

      return res.render('admin/Login', viewModel);
    });

    app.post(
      '/admin/login',

      ValidationService.validateInput(
        {
          email: 'required|email',
          password: 'required|minLength:6',
        },
        {
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
          'password.required': 'Password is required.',
          'password.minLength': 'Password should be at least 6 characters long.',
        },
      ),

      async function (req, res, next) {
        const role_id = 1;
        const { email, password } = req.body;

        const AuthViewModel = require('../../view_models/admin_auth_view_model');

        const viewModel = new AuthViewModel(db.user, 'Login');

        ValidationService.handleValidationErrorForViews(req, res, viewModel, 'admin/Login', 'login_fields', { email });

        try {
          const { user } = await AuthService.login(email, password, role_id);

          const session = req.session;

          session.role = role_id;
          session.user = user;
          console.log('session is: ' + JSON.stringify(session.user));

          return session.save((error) => {
            if (error) {
              throw new Error(error);
            }
            return res.redirect('/admin/dashboard');
          });
        } catch (error) {
          console.log(error);
          viewModel.error = errors[error.message] || 'Something went wrong';
          viewModel.login_fields.email = email;
          return res.render('admin/Login', viewModel);
        }
      },
    );

    app.post(
      '/admin/api/login',
      ValidationService.validateInput(
        {
          email: 'required|email',
          password: 'required|minLength:6',
        },
        {
          'email.required': 'Email is required',
          'email.email': 'Invalid email',
          'password.required': 'Password is required.',
          'password.minLength': 'Password should be at least 6 characters long.',
        },
      ),
      ValidationService.handleValidationErrorForAPI,

      async function (req, res, next) {
        const role_id = 1;

        const { email, password } = req.body;

        try {
          const payload = await AuthService.login(email, password, role_id);

          const response = {
            access_token: JWTService.createAccessToken(payload),
            refresh_token: JWTService.createRefreshToken(payload),
          };

          return res.status(200).json({ success: true, data: response });
        } catch (error) {
          const message = errors[error.message] || 'Something went wrong';
          return res.status(500).json({ success: false, message });
        }
      },
    );

    app.post(
      '/admin/api/refresh-token',
      ValidationService.validateInput(
        {
          refresh_token: 'required',
        },
        {
          'refresh_token.required': 'Refresh token is required',
        },
      ),
      ValidationService.handleValidationErrorForAPI,
      async function (req, res, next) {
        const { refresh_token } = req.body;

        try {
          const verify = JWTService.verifyRefreshToken(refresh_token);

          if (!verify) {
            return res.status(403).json({ success: false, message: 'Invalid refresh token' });
          } else {
            delete verify.iat;
            delete verify.exp;
            delete verify.nbf;
            delete verify.jti; //We are generating a new token, if you are using jwtid during signing, pass it in refreshOptions
            const access_token = JWTService.createAccessToken(verify);
            const refresh_token = JWTService.createRefreshToken(verify);

            return res.status(201).json({ success: true, data: { access_token, refresh_token } });
          }
        } catch (err) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    return app;
  },
};
