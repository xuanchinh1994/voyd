'use strict';




module.exports = {
  initializeApp: function (app) {

  app.get('/admin/logout', async function (req, res, next) {
  req.session.destroy(function(err) {
    req.session = {}
  })

  return res.redirect("/admin/login")
});



app.get('/admin/api/logout', async function (req, res, next) {
  req.session.destroy(function(err) {
    res.status(201).json({ success: false });
  })

  res.status(201).json({ success: true });
});


    return app;
  }
};


