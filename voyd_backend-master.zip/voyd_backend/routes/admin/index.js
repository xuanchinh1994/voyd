const Login = require("./login");
const Logout = require("./logout");
const Profile = require("./profile");

module.exports = {
            initializeApp: function (app) {
              const routes = [Login,Logout,Profile]
              routes.forEach((item) => item.initializeApp(app))
            },
          }
          