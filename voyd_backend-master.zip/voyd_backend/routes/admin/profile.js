'use strict';

const SessionService = require('../../services/SessionService');
const PasswordService = require('../../services/PasswordService');
const db = require('../../models');
const { errors } = require('../../core/strings');
const { validateEmail } = require('../../core/utils');

module.exports = {
  initializeApp: function (app) {
    const role_id = 1;

    app.get(
      '/admin/profile',
      SessionService.verifySessionMiddleware(role_id, 'admin'),

      async function (req, res, next) {
        const user = req.session.user;

        const AuthViewModel = require('../../view_models/admin_auth_view_model');

        const viewModel = new AuthViewModel(db.user, 'Profile');

        viewModel._base_url = '/admin/profile';

        if (!user || !user.id) {
          viewModel.error = 'xUserNotFound';
          return res.render('admin/Profile', viewModel);
        }
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }

        try {
          const exists = await db.user.get_user_credential(user.id, db);
          if (!exists || +exists.status === 0 || exists.credential.role_id !== role_id) {
            viewModel.error = 'profile_not_found';
            return res.render('admin/Profile', viewModel);
          }
          const values = exists;
          Object.keys(viewModel.form_fields).forEach((field) => {
            if (field === 'email') {
              viewModel.form_fields[field] = values['credential'][field];
              return;
            }
            viewModel.form_fields[field] = values[field];
          });

          return res.render('admin/Profile', viewModel);
        } catch (error) {
          viewModel.error = 'Something went wrong';
          return res.render('admin/Profile', viewModel);
        }
      },
    );

    app.post(
      '/admin/profile',

      SessionService.verifySessionMiddleware(role_id, 'admin'),

      async function (req, res, next) {
        let UserRef;
        let CredentialRef;

        let User;
        let Credential;

        const user = req.session.user;

        const AuthViewModel = require('../../view_models/admin_auth_view_model');

        const viewModel = new AuthViewModel(db.user, 'Profile');
        viewModel._base_url = '/admin/profile';

        if (!user || !user.id) {
          viewModel.error = 'xUserNotFound';
          return res.render('admin/Profile', viewModel);
        }

        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }

        const { email, password, first_name, last_name, status } = req.body;

        const credentialFields = {
          email,
        };

        if (password && password.trim() !== '') {
          credentialFields.password = password;
        }

        viewModel.form_fields = {
          ...viewModel.form_fields,
          email,
          first_name,
          last_name,
          status,
        };

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Profile', viewModel);
          }

          CredentialRef = await db.credential.getByFields({
            user_id: user.id,
            status: 1,
            role_id,
          });

          if (!CredentialRef) throw new Error('EMAIL_ADDRESS_NOT_FOUND');

          const credentialType = CredentialRef.type;

          UserRef = await db.user.getByFields({
            id: user.id,
            status: 1,
          });

          if (!UserRef) throw new Error('EMAIL_ADDRESS_NOT_FOUND');

          if (credentialType === 'n' && Object.entries(credentialFields).length > 0) {
            if (credentialFields.email) {
              if (!validateEmail(credentialFields.email)) {
                viewModel.error = 'Invalid email';
                return res.render('admin/Profile', viewModel);
              }

              if (CredentialRef.email !== credentialFields.email) {
                const userExists = await db.credential.getByField('email', credentialFields.email);
                if (userExists) {
                  throw new Error('EMAIL_ADDRESS_ALREADY_EXIST');
                }
              }
            }
            if (credentialFields.password) {
              const hashedPassword = await PasswordService.hash(credentialFields.password);
              credentialFields.password = hashedPassword;
            }
            Credential = await db.credential.edit(
              {
                ...credentialFields,
              },
              CredentialRef.id,
            );
          }
          User = await db.user.edit(
            {
              first_name,
              last_name,
              status,
            },
            UserRef.id,
          );

          viewModel.success = 'Profile is successfully updated!';
          return res.render('admin/Profile', viewModel);
        } catch (error) {
          try {
            if (Credential && CredentialRef) {
              await db.credential.edit(
                {
                  email: CredentialRef.email,
                  password: CredentialRef.password,
                  status: CredentialRef.status,
                },
                CredentialRef.id,
              );
            }
          } catch (_) {}

          viewModel.error = errors[error.message] || 'Something went wrong';
          return res.render('admin/Profile', viewModel);
        }
      },
    );

    return app;
  },
};
