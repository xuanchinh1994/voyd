# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 199.241.139.243 (MySQL 5.5.5-10.5.10-MariaDB-1:10.5.10+maria~bionic-log)
# Database: vyold_api_ZGrVZ
# Generation Time: 2021-09-22 04:05:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table activity_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;

INSERT INTO `activity_log` (`id`, `name`, `action`, `data`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'Code_controller.js','ADD','{\"code\":\"1\"}',NULL,'2021-09-15 12:42:01','2021-09-15 12:42:01');

/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table admin_operation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `admin_operation`;

CREATE TABLE `admin_operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `last_ip` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table calendar
# ------------------------------------------------------------

DROP TABLE IF EXISTS `calendar`;

CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `calendar` WRITE;
/*!40000 ALTER TABLE `calendar` DISABLE KEYS */;

INSERT INTO `calendar` (`id`, `event_id`, `title`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`, `user_id`)
VALUES
	(37,'DF0AE8A8-4C0A-4FDD-B75C-7C8834BE9E9F','Test','2021-09-17 10:00:00','2021-09-17 11:00:00',1,'2021-09-17 09:27:44','2021-09-17 09:27:44',2);

/*!40000 ALTER TABLE `calendar` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table code
# ------------------------------------------------------------

DROP TABLE IF EXISTS `code`;

CREATE TABLE `code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `is_used` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `code` WRITE;
/*!40000 ALTER TABLE `code` DISABLE KEYS */;

INSERT INTO `code` (`id`, `code`, `is_used`, `status`, `created_at`, `updated_at`, `user_id`)
VALUES
	(1,'rF9UDNRQ',1,NULL,'2021-09-15 09:26:51','2021-09-15 09:26:51',2),
	(2,'wUc_YmP-',NULL,NULL,'2021-09-15 12:42:01','2021-09-15 12:42:01',NULL);

/*!40000 ALTER TABLE `code` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table credential
# ------------------------------------------------------------

DROP TABLE IF EXISTS `credential`;

CREATE TABLE `credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `verify` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `two_factor_authentication` int(11) DEFAULT NULL,
  `force_password_change` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `credential` WRITE;
/*!40000 ALTER TABLE `credential` DISABLE KEYS */;

INSERT INTO `credential` (`id`, `email`, `password`, `type`, `verify`, `role_id`, `status`, `two_factor_authentication`, `force_password_change`, `created_at`, `updated_at`, `user_id`)
VALUES
	(1,'admin@manaknight.com','$2a$04$u162h6DBhEJGXQt6naMHauFlgihlrcEOu9GRFip7g.p.6BWCh2PjK','n',1,1,1,0,NULL,'2021-09-15 09:26:51','2021-09-15 09:26:51',1),
	(2,'member@manaknight.com','$2a$04$ZOWNYcW89wpP/rEkELjpuOBhN7eXvR4xgibXx4uRJxhtjRQnDiKIS','n',1,2,1,0,NULL,'2021-09-15 09:26:51','2021-09-15 09:26:51',2);

/*!40000 ALTER TABLE `credential` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `html` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;

INSERT INTO `email` (`id`, `slug`, `subject`, `tag`, `html`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'reset-password','Reset your password','reset_token,link','You have requested to reset your password. Please click the link below to reset it.<br/><a href=\"{{{link}}}/{{{reset_token}}}\">Link</a>. <br/>Thanks,<br/> Admin',1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(2,'reset-password-mobile','Reset your password','code','You have requested to reset your password. Here is your confirmation code <span style=\'font-size:25px\'><strong>{{{code}}}</strong></span>.<br/>Thanks,<br/> Admin',1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(3,'register','Welcome to Voydx','first_name','Hi {{{first_name}}}, Thanks for registering on Voydx.<br/>',1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(4,'verify-account','Confirm your account','link','Please click the <a href=\"{{{link}}}\">link</a> to confirm your account.<br/>Thanks<br/> Admin',1,'2021-09-15 09:26:51','2021-09-15 09:26:51');

/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table image
# ------------------------------------------------------------

DROP TABLE IF EXISTS `image`;

CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` text DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;

INSERT INTO `image` (`id`, `url`, `caption`, `width`, `height`, `type`, `status`, `created_at`, `updated_at`, `user_id`)
VALUES
	(1,'https://i.imgur.com/AzJ7DRw.png','',581,581,1,1,'2021-09-15 09:26:51','2021-09-15 09:26:51',1),
	(4,'/userUploads/NaBD_BTo-u4VccM1GhCET_20218179950304346IMG_2776.HEIC',NULL,NULL,NULL,6,1,'2021-09-17 09:09:55','2021-09-17 09:09:55',2);

/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table link
# ------------------------------------------------------------

DROP TABLE IF EXISTS `link`;

CREATE TABLE `link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `link` WRITE;
/*!40000 ALTER TABLE `link` DISABLE KEYS */;

INSERT INTO `link` (`id`, `link`, `status`, `created_at`, `updated_at`, `user_id`)
VALUES
	(2,'https://www.worldwildlife.org/species/sea-turtle',0,'2021-09-17 09:17:39','2021-09-17 09:17:42',2),
	(3,'https://www.worldwildlife.org/species/sea-turtle',0,'2021-09-17 09:18:12','2021-09-17 09:19:46',2),
	(4,'https://www.google.com/amp/s/www.livescience.com/amp/52361-turtle-facts.html',0,'2021-09-17 09:20:38','2021-09-17 09:21:05',2),
	(5,'https://www.musthavemenus.com/x/api/qr/1c7bb327-ee07-44e1-986b-259f934ab82c',0,'2021-09-17 09:22:06','2021-09-17 09:22:44',2),
	(6,'https://www.google.com/amp/s/www.livescience.com/amp/52361-turtle-facts.html',0,'2021-09-17 09:23:39','2021-09-17 09:25:16',2),
	(7,'https://www.google.com/amp/s/www.livescience.com/amp/52361-turtle-facts.html',0,'2021-09-17 09:25:32','2021-09-17 09:26:15',2),
	(8,'https://www.musthavemenus.com/x/api/qr/1c7bb327-ee07-44e1-986b-259f934ab82c',0,'2021-09-17 09:26:30','2021-09-21 12:27:54',2);

/*!40000 ALTER TABLE `link` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table links
# ------------------------------------------------------------

DROP TABLE IF EXISTS `links`;

CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table member_operation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `member_operation`;

CREATE TABLE `member_operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `last_ip` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table note
# ------------------------------------------------------------

DROP TABLE IF EXISTS `note`;

CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;

INSERT INTO `note` (`id`, `message`, `status`, `created_at`, `updated_at`, `user_id`)
VALUES
	(1,'First note',1,'2021-09-15 09:29:23','2021-09-15 09:29:23',2),
	(2,'Second note',1,'2021-09-16 19:41:57','2021-09-16 19:41:57',2),
	(5,'Third',1,'2021-09-17 09:09:01','2021-09-17 09:09:01',2);

/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table notes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `notes`;

CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table profile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timezone` varchar(255) DEFAULT NULL,
  `dashboard_code` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table refer_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `refer_log`;

CREATE TABLE `refer_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referrer_user_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;

INSERT INTO `role` (`id`, `name`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'admin',1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(2,'member',1,'2021-09-15 09:26:51','2021-09-15 09:26:51');

/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table setting
# ------------------------------------------------------------

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `maintenance` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;

INSERT INTO `setting` (`id`, `key`, `type`, `value`, `maintenance`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'site_name',0,'Manaknight Inc',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(2,'site_logo',0,'https://manaknightdigital.com/assets/img/logo.png',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(3,'maintenance',1,'0',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(4,'version',0,'1.0.0',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(5,'copyright',0,'Copyright © 2019 Manaknightdigital Inc. All rights reserved.',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(6,'license_key',4,'4097fbd4f340955de76ca555c201b185cf9d6921d977301b05cdddeae4af54f924f0508cd0f7ca66',NULL,1,'2021-09-15 09:26:51','2021-09-15 09:26:51');

/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sms`;

CREATE TABLE `sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) DEFAULT NULL,
  `tag` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;

INSERT INTO `sms` (`id`, `slug`, `tag`, `content`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'verify','code','Your verification # is {{{code}}}',1,'2021-09-15 09:26:51','2021-09-15 09:26:51');

/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table token
# ------------------------------------------------------------

DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `ttl` int(11) DEFAULT NULL,
  `issue_at` datetime DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `refer` varchar(255) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `stripe_uid` varchar(255) DEFAULT NULL,
  `paypal_uid` varchar(255) DEFAULT NULL,
  `sync_code` varchar(255) DEFAULT NULL,
  `font_color` varchar(255) DEFAULT NULL,
  `time_zone` varchar(255) DEFAULT NULL,
  `time_format` int(11) DEFAULT NULL,
  `clock_format` int(11) DEFAULT NULL,
  `date_format` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `expire_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sync_code` (`sync_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `status`, `first_name`, `last_name`, `phone`, `image`, `image_id`, `refer`, `profile_id`, `role_id`, `stripe_uid`, `paypal_uid`, `sync_code`, `font_color`, `time_zone`, `time_format`, `clock_format`, `date_format`, `location`, `lat`, `lng`, `expire_at`, `created_at`, `updated_at`)
VALUES
	(1,1,'Admin','Admin','12345678','https://i.imgur.com/AzJ7DRw.png',1,'842185265808',0,1,NULL,NULL,NULL,'#ffffff','UTC',1,1,1,'',NULL,NULL,NULL,'2021-09-15 09:26:51','2021-09-15 09:26:51'),
	(2,1,'Member','Member','12345678','https://i.imgur.com/AzJ7DRw.png',1,'760702500840',0,2,NULL,NULL,'rF9UDNRQ','#ffffff','EDT',2,1,1,'Sacramento',38.5556,-121.469,NULL,'2021-09-15 09:26:51','2021-09-17 09:12:08');

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
