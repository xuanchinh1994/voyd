require('dotenv').config()

const db = require('../../models')
const TimezoneService = require('../../services/TimezoneService')
const { errorCodes } = require('../../core/strings')

const timezoneService = new TimezoneService()

const ROLE_ID = {
  member: 2,
}

const BASE_URL = process.env.BASE_URL

function withVerifyUser(role_id = 0) {
  return async (req, res, next) => {
    const { code } = req.query
    if (!code) {
      return res.status(404).json({
        success: false,
        message: 'Missing code',
        code: errorCodes.extra.INVALID_SYNC_CODE,
      })
    }
    const userCode = await db.code.findOne({
      where: {
        status: 1,
        code,
      },
      include: { model: db.user, as: 'user' },
    })
    if (!userCode?.user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.',
        code: errorCodes.account.ACCOUNT_DOES_NOT_EXISTS,
      })
    }
    req.user = userCode.user
    next()
  }
}

function filterPrivateFields(target = {}, type) {
  let validFields
  let final = {}
  switch (type?.toUpperCase?.()) {
    case 'USER':
      validFields = db.user
        .allowFields()
        ?.filter((item) =>
          [
            'id',
            'font_color',
            'time_zone',
            'time_format',
            'clock_format',
            'date_format',
            'location',
            'lat',
            'lng',
          ].includes(item)
        )
      break
    case 'NOTE':
      validFields = db.note
        .allowFields()
        ?.filter((item) =>
          ['id', 'message', 'created_at', 'updated_at'].includes(item)
        )
      break
    default:
      validFields = []
  }
  validFields?.forEach((field) => {
    if (field in target) {
      final[field] = target[field]
    }
  })
  return final
}

module.exports = {
  initializeApi: function (app) {
    app.get(
      '/global/api/user-settings',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const getPublicFields = filterPrivateFields(user, 'User')
        const timezone = getPublicFields?.time_zone
        const timezoneFullDetail = timezoneService.findTimezone(timezone)
        return res.json({
          success: true,
          data: {
            ...getPublicFields,
            time_zone: timezoneFullDetail,
          },
        })
      }
    )

    app.get(
      '/global/api/user-notes',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const allNotes = await db.note.getAll({
          status: 1,
          user_id: user.id,
        })
        return res.json({
          success: true,
          data: allNotes,
        })
      }
    )
    app.get(
      '/global/api/user-calendar',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const allCalendarEvents = await db.calendar.getAll({
          status: 1,
          user_id: user.id,
        })
        return res.json({
          success: true,
          data: allCalendarEvents,
        })
      }
    )
    app.get(
      '/global/api/user-calendar',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const allCalendarEvents = await db.calendar.getAll({
          status: 1,
          user_id: user.id,
        })
        return res.json({
          success: true,
          data: allCalendarEvents,
        })
      }
    )
    app.get(
      '/global/api/user-custom-image',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const customImage = await db.image.getByFields({
          status: 1,
          user_id: user.id,
          type: 6,
        })
        return res.json({
          success: true,
          data: customImage
            ? { id: customImage?.id, url: `${BASE_URL}${customImage?.url}` }
            : null,
        })
      }
    )

    app.get(
      '/global/api/user-link',
      withVerifyUser(ROLE_ID.member),
      async (req, res) => {
        const user = req.user
        const link = await db.link.getByFields({
          status: 1,
          user_id: user.id,
        })
        return res.json({
          success: true,
          data: link,
        })
      }
    )
    return app
  },
}
