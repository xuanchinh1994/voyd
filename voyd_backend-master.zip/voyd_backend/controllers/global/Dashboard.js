
module.exports = {
  initializeApi: function (app) {

    app.get('/dashboard', async (_, res) => {
     return res.render("global/dashboard")
    });

    return app;
  },
};
