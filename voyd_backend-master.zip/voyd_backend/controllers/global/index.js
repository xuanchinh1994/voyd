const AppDetails = require('./MobileAppDetails');
const Mirror = require('./Mirror');
const Dashboard = require('./Dashboard');


module.exports = {
  initializeApi: function (app) {
    const controllers = [Dashboard,AppDetails, Mirror];
    controllers.forEach((item) => item.initializeApi(app));
  },
};
