require('dotenv').config()

module.exports = {
  initializeApi: function (app) {
    app.get('/global/api/mobile-app-details', (_, res) => {
      const appVersion = process.env.MOBILE_APP_VERSION
      const appStoreUrl = process.env.APP_STORE_URL

      return res.status(200).json({
        appVersion,
        appStoreUrl,
      })
    })
    return app
  },
}
