'use strict';

const Sequelize = require('sequelize')
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService')
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require("../../models");
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/link/');





module.exports = {
  initializeApi: function (app) {
  const role = 1;

app.get("/admin/links/:num", SessionService.verifySessionMiddleware(role, "admin"),
   async function (
      req,
      res,
      next
    ) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/link_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';

      let viewModel =new paginateListViewModel(
        db.link,
        "Links",
        session.success,
        session.error,
        '/admin/links');

        // Check for flash messages
        const flashMessageSuccess = req.flash('success');
        if (flashMessageSuccess && flashMessageSuccess.length > 0) {
          viewModel.success = flashMessageSuccess[0];
        }
        const flashMessageError = req.flash('error');
        if (flashMessageError && flashMessageError.length > 0) {
          viewModel.error = flashMessageError[0];
        }

      viewModel.set_id(req.query.id ? req.query.id : '');
		viewModel.set_user_id(req.query.user_id ? req.query.user_id : '');
		viewModel.set_link(req.query.link ? req.query.link : '');
		viewModel.set_status(req.query.status ? req.query.status : '');
		

      let where = {
        'id': viewModel.get_id(),
			'user_id': viewModel.get_user_id(),
			'link': viewModel.get_link(),
			'status': viewModel.get_status(),
			
        
        
      };


      const filteredWhere = Object.entries(where).reduce(
        (accumulator, currentValue) => {
          const [key, value] = currentValue;
          if (!accumulator[key]) {
            if (value !== null && value !== "" && value !== undefined) {
              accumulator[key] = value;
            }
            return accumulator;
          }
        },
        {},
      );


      try {
        const count  = await db.link._count(filteredWhere,[]);

        viewModel.set_total_rows(count);  
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/links');

        


        const list = await db.link.getPaginated(
          
          viewModel.get_page() - 1 < 0 ? 0 : viewModel.get_page() - 1,
          viewModel.get_per_page(),
          filteredWhere,
          order_by,
          direction)
        viewModel.set_list(list);

        

        if (format == 'csv') {
          const csv = viewModel.to_csv();
          return res
            .set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            })
            .send(csv);
        }

        // if (format != 'view') {
        //   res.json(viewModel.to_json());
        // } else {
        // }

        

        return res.render('admin/Links', viewModel);
      } catch (error) {
        console.dir(error, {depth: null});
        viewModel.error = "Something went wrong"
        return res.render('admin/Links', viewModel);
      }

       
    });

    

app.get("/admin/links-add", SessionService.verifySessionMiddleware(role, "admin"),
  async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }

  const linkAdminAddViewModelJs = require("../../view_models/link_admin_add_view_model.js")


  const viewModel =new linkAdminAddViewModelJs(db.link,"Add link", "","","/admin/links")
  
  

  res.render('admin/Add_Links', 
  viewModel
  );
});


app.post("/admin/links-add", SessionService.verifySessionMiddleware(role,"admin"), ValidationService.validateInput(
        {"link":"required","status":"required|integer"},
        {"link.required":"Link is required","status.required":"Status is required","status.integer":"Status must be integer."}
      ),
async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const linkAdminAddViewModelJs = require("../../view_models/link_admin_add_view_model.js")

 const viewModel = new linkAdminAddViewModelJs(db.link,"Add link", "","","/admin/links")

// TODO use separate controller for image upload  
//  {{{upload_field_setter}}}

 const { user_id,link,status } = req.body;

 viewModel.form_fields =  {
   ...viewModel.form_fields,
   user_id,link,status
 }

 try{
   if (req.validationError) {
     viewModel.error = req.validationError;
     return res.render("admin/Add_Links", viewModel);
   }

   viewModel.session = req.session

   

    
          
          const data =  await db.link.insert({ user_id,link,status });
        


    if(!data){
      viewModel.error = "Something went wrong";
      return res.render("admin/Add_Links", viewModel)
    }

   

   
    
   req.flash("success","Link created successfully")
   return res.redirect("/admin/links/0");
 } catch(error){   
    console.dir(error, {depth: null});
    viewModel.error = errors[error.message] || 'Something went wrong';
    return res.render("admin/Add_Links", viewModel)
 }
});



app.get("/admin/links-edit/:id", SessionService.verifySessionMiddleware(role,"admin"),  async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const linkAdminEditViewModel = require("../../view_models/link_admin_edit_view_model")

  const viewModel =new linkAdminEditViewModel(db.link,"Edit link", "","","/admin/links")


  try{
    const exists = await db.link.getByPK(id);

    if(!exists){
      req.flash('error', "Link not found");
      return res.redirect("/admin/links/0")
    }
    const values = exists;
    Object.keys(viewModel.form_fields).forEach((field) => {
      
      viewModel.form_fields[field] = values[field] || '';
    });

    return res.render("admin/Edit_Links",viewModel)
  } catch(error){
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_Links", viewModel)
  }

});

app.post("/admin/links-edit/:id", SessionService.verifySessionMiddleware(role, "admin"), ValidationService.validateInput(
        {"link":"required","status":"required|integer"},
        {"link.required":"Link is required","status.required":"Status is required","status.integer":"Status must be integer."}
      ), async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  

  const linkAdminEditViewModel = require("../../view_models/link_admin_edit_view_model")

  const viewModel =new linkAdminEditViewModel(db.link,"Edit link", "","","/admin/links")

  
  const { user_id,link,status } = req.body

  viewModel.form_fields = {
    ...viewModel.form_fields,
    user_id,link,status
  }

    delete viewModel.form_fields.id

  try{
    if (req.validationError) {
      viewModel.error = req.validationError;
      return res.render("admin/Edit_Links", viewModel)
    }



    const resourceExists = await db.link.getByPK(id);
    if(!resourceExists){
      req.flash('error', "Link not found");
      return res.redirect("/admin/links/0")
    }

    viewModel.session = req.session

    

    const data = await db.link.edit({ user_id,link,status  }, id);
    if(!data){
      viewModel.error = "Something went wrong"
      return res.render("admin/Edit_Links", viewModel);
    }

    

    

    req.flash("success","Link edited successfully")

    return res.redirect("/admin/links/0")
  } catch(error){    
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_Links", viewModel);

  }
});



app.get(
  "/admin/links-view/:id",
  SessionService.verifySessionMiddleware(role, "admin"),
  
  async function (req, res, next) {
    let id = req.params.id;

    const linkAdminDetailViewModel = require("../../view_models/link_admin_detail_view_model")

    const viewModel =new linkAdminDetailViewModel(db.link,"Link details","","","/admin/links")

    try{

      

      const data = await db.link.getByPK(id);
      data.status = db.link.status_mapping(data.status);
      
      if(!data){
        viewModel.error = "Link not found"
        viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",user_id:"N/A",link:"N/A",status:"N/A"  }
      }
      else{
        viewModel.detail_fields = {...viewModel.detail_fields, id:data["id"] || "",user_id:data["user_id"] || "",link:data["link"] || "",status:data["status"] || ""  }
      }

      

      res.render('admin/View_Link', viewModel);


    } catch(error){
      console.dir(error, {depth: null});
      viewModel.error = "Something went wrong"
      viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",user_id:"N/A",link:"N/A",status:"N/A"}
      res.render('admin/View_Link', viewModel);

    }    

  }
);

app.get(
  "/admin/links-delete/:id",
  SessionService.verifySessionMiddleware(role,"admin"), 
  async function (req, res, next) {
  
    let id = req.params.id;
  
    const linkAdminDeleteViewModel = require("../../view_models/link_admin_delete_view_model")
    
    const viewModel = new linkAdminDeleteViewModel(db.link)
  
    try {
      const exists = await db.link.getByPK(id);

      if(!exists){
        req.flash("error","Link not found")

        return res.redirect("/admin/links/0")
      }

      viewModel.session = req.session

      

      await db.link.realDelete(id)

      
      
      
      
      req.flash("success","Link was deleted successfully")

      return res.redirect("/admin/links/0")
    }catch(error){
      console.dir(error, {depth: null});
      req.flash("error","Something went wrong")
      return res.redirect("/admin/links/0")
    }
    
  }
);



// APIS


app.post("/admin/api/links-add", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"link":"required","status":"required|integer"},
            {"link.required":"Link is required","status.required":"Status is required","status.integer":"Status must be integer."}
          ), async function (
  req,
  res,
  next
) {
  const linkAdminAddViewModelJs = require("../../view_models/link_admin_add_view_model.js")

  const viewModel = new linkAdminAddViewModelJs(db.link)

  const { user_id,link,status } = req.body;
  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    

          
          const data =  await db.link.insert({ user_id,link,status });
        

    if(!data){
      return res.status(500).json({success:false, message:"Something went wrong"})
    }

    

    

    return res.status(201).json({success:true, message:"Link created successfully"});

  } catch(error){
    return res.status(500).json({success:false, message:"Something went wrong"})
  }
 
});



app.put("/admin/api/links-edit/:id", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"link":"required","status":"required|integer"},
            {"link.required":"Link is required","status.required":"Status is required","status.integer":"Status must be integer."}
          ), async function (
  req,
  res,
  next
) {
  
  let id = req.params.id;
    
  const linkAdminEditViewModel = require("../../view_models/link_admin_edit_view_model")

  const viewModel =new linkAdminEditViewModel(db.link)
  
  const { user_id,link,status } = req.body;

  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    const resourceExists = await db.link.getByPK(id);
    if(!resourceExists){
      return res.status(404).json({success:false, message: 'Link not found' })
    }

    

    const data = await db.link.edit({ user_id,link,status  }, id);

    if(!data){
      return res.status(500).json({success:false, message: "Something went wrong" })
    }

    
    
    

    return res.json({success:true, message:"Link edited successfully"});
    
  } catch(error){
    return res.status(500).json({success:false, message: "Something went wrong" })
}

});



app.get(
  "/admin/api/links-view/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
    
    const linkAdminDetailViewModel = require("../../view_models/link_admin_detail_view_model")

    const viewModel =new linkAdminDetailViewModel(db.link)
    
    try{

      

      const data = await db.link.getByPK(id);

      

      if(!data){
        return res.status(404).json({message:"Link not found", data:null})

      }else{
       const fields = {...viewModel.detail_fields, id:data["id"] || "",user_id:data["user_id"] || "",link:data["link"] || "",status:data["status"] || ""  }
         return res.status(200).json({data:fields})
      }

    } catch(error){
      return res.status(404).json({message:"Something went wrong", data:null})
    }
  }
);

app.delete(
  "/admin/api/links-delete/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
   
    const linkAdminDeleteViewModel = require("../../view_models/link_admin_delete_view_model")

    const viewModel =new   linkAdminDeleteViewModel(db.link)
    
    
    try {
      const exists = await db.link.getByPK(id);

      if(!exists){
        return res.status(404).json({success:false,message:'Link not found'})
      }

      
      
      await db.link.realDelete(id)

      
      
      
      
      return res.status(200).json({success:true, message:"Link deleted successfully"})

      }catch(error){

      return res.status(500).json({success:false,message: 'Something went wrong'})    }
  }
);



    return app;
  }
};


