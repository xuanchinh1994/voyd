const AdminCalendarController = require("./Admin_calendar_controller");
const AdminLinkController = require("./Admin_link_controller");
const AdminLinksController = require("./Admin_links_controller");
const AdminNotesController = require("./Admin_notes_controller");
const AdminProfileController = require("./Admin_profile_controller");
const CodeController = require("./Code_controller");
const CredentialController = require("./Credential_controller");
const CsvController = require("./Csv_controller");
const Dashboard = require("./Dashboard");
const ImageController = require("./Image_controller");
const UserController = require("./User_controller");

module.exports = {
              initializeApi: function (app) {
                const controllers = [AdminCalendarController,AdminLinkController,AdminLinksController,AdminNotesController,AdminProfileController,CodeController,CredentialController,CsvController,Dashboard,ImageController,UserController]
                controllers.forEach((item) => item.initializeApi(app))
              },
            }
            