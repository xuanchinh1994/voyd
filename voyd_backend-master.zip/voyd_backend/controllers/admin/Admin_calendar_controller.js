'use strict';

const { Op } = require('sequelize');
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService');
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require('../../models');
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/calendar/');
const dateformat = require('dateformat');

module.exports = {
  initializeApi: function (app) {
    const role = 1;

    app.get('/admin/calendar/:num', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/calendar_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';

      let viewModel = new paginateListViewModel(db.calendar, 'Schedules', session.success, session.error, '/admin/calendar');

      // Check for flash messages
      const flashMessageSuccess = req.flash('success');
      if (flashMessageSuccess && flashMessageSuccess.length > 0) {
        viewModel.success = flashMessageSuccess[0];
      }
      const flashMessageError = req.flash('error');
      if (flashMessageError && flashMessageError.length > 0) {
        viewModel.error = flashMessageError[0];
      }

      viewModel.set_id(req.query.id ? req.query.id : '');
      viewModel.set_user_id(req.query.user_id ? req.query.user_id : '');
      viewModel.set_user_first_name(req.query.user_first_name ? req.query.user_first_name : '');
      viewModel.set_user_last_name(req.query.user_last_name ? req.query.user_last_name : '');
      viewModel.set_title(req.query.title ? req.query.title : '');
      viewModel.set_start_date(req.query.start_date ? req.query.start_date : '');
      viewModel.set_end_date(req.query.end_date ? req.query.end_date : '');

      let where = {
        id: viewModel.get_id(),
        '$user.id$': viewModel.get_user_id(),
        '$user.first_name$': viewModel.get_user_first_name(),
        '$user.last_name$': viewModel.get_user_last_name(),
        title: viewModel.get_title(),
        ...(req.query.start_date && req.query.end_date
          ? {
              start_date: {
                [Op.and]: {
                  [Op.gte]: viewModel.get_start_date(),
                  [Op.lte]: viewModel.get_end_date(),
                },
              },
            }
          : {}),
      };

      const filteredWhere = Object.entries(where).reduce((accumulator, currentValue) => {
        const [key, value] = currentValue;
        if (!accumulator[key]) {
          if (value !== null && value !== '' && value !== undefined) {
            accumulator[key] = value;
          }
          return accumulator;
        }
      }, {});

      try {
        const count = await db.calendar._count(filteredWhere, [{ model: db.user, as: 'user' }]);

        viewModel.set_total_rows(count);
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/calendar');

        const list = await db.calendar.get_user_paginated(
          db,
          viewModel.get_page() - 1 < 0 ? 0 : viewModel.get_page() - 1,
          viewModel.get_per_page(),
          filteredWhere,
          order_by,
          direction,
        );
        viewModel.set_list(list);

        if (format == 'csv') {
          const csv = viewModel.to_csv();
          return res
            .set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            })
            .send(csv);
        }

        // if (format != 'view') {
        //   res.json(viewModel.to_json());
        // } else {
        // }

        return res.render('admin/Calendar', viewModel);
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        return res.render('admin/Calendar', viewModel);
      }
    });

    app.get('/admin/calendar-add', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }

      const calendarAdminAddViewModelJs = require('../../view_models/calendar_admin_add_view_model.js');

      const viewModel = new calendarAdminAddViewModelJs(db.calendar, 'Add calendar', '', '', '/admin/calendar');
      viewModel.users = await db.user.findAll({
        include: [{ model: db.credential, as: 'credential' }],
      });
      res.render('admin/Add_Calendar', viewModel);
    });

    app.post(
      '/admin/calendar-add',
      SessionService.verifySessionMiddleware(role, 'admin'),
      ValidationService.validateInput(
        { user_id: 'required|integer', title: 'required', date: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'title.required': 'Title is required',
          'date.required': 'Date is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }
        const calendarAdminAddViewModelJs = require('../../view_models/calendar_admin_add_view_model.js');

        const viewModel = new calendarAdminAddViewModelJs(db.calendar, 'Add calendar', '', '', '/admin/calendar');
        viewModel.users = await db.user.findAll({
          include: [{ model: db.credential, as: 'credential' }],
        });
        // TODO use separate controller for image upload
        //  {{{upload_field_setter}}}

        const { user_id, title, date, status } = req.body;

        viewModel.form_fields = {
          ...viewModel.form_fields,
          user_id,
          title,
          date,
          status,
        };

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Add_Calendar', viewModel);
          }

          viewModel.session = req.session;

          const data = await db.calendar.insert({ user_id, title, date, status });

          if (!data) {
            viewModel.error = 'Something went wrong';
            return res.render('admin/Add_Calendar', viewModel);
          }

          req.flash('success', 'Calendar created successfully');
          return res.redirect('/admin/calendar/0');
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = errors[error.message] || 'Something went wrong';
          return res.render('admin/Add_Calendar', viewModel);
        }
      },
    );

    app.get('/admin/calendar-edit/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }
      const calendarAdminEditViewModel = require('../../view_models/calendar_admin_edit_view_model');

      const viewModel = new calendarAdminEditViewModel(db.calendar, 'Edit calendar', '', '', '/admin/calendar');
      viewModel.users = await db.user.findAll({
        include: [{ model: db.credential, as: 'credential' }],
      });
      try {
        const exists = await db.calendar.getByPK(id);

        if (!exists) {
          req.flash('error', 'Calendar not found');
          return res.redirect('/admin/calendar/0');
        }
        const values = exists;
        Object.keys(viewModel.form_fields).forEach((field) => {
          if (field == 'date') {
            let date = dateformat(values[field], 'isoDateTime');
            viewModel.form_fields[field] = date.slice(0, -5) || '';
          } else {
            viewModel.form_fields[field] = values[field] || '';
          }
        });

        return res.render('admin/Edit_Calendar', viewModel);
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        return res.render('admin/Edit_Calendar', viewModel);
      }
    });

    app.post(
      '/admin/calendar-edit/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),
      ValidationService.validateInput(
        { user_id: 'required|integer', title: 'required', date: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'title.required': 'Title is required',
          'date.required': 'Date is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let id = req.params.id;
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }

        const calendarAdminEditViewModel = require('../../view_models/calendar_admin_edit_view_model');

        const viewModel = new calendarAdminEditViewModel(db.calendar, 'Edit calendar', '', '', '/admin/calendar');
        viewModel.users = await db.user.findAll({
          include: [{ model: db.credential, as: 'credential' }],
        });

        const { user_id, title, date, status } = req.body;

        viewModel.form_fields = {
          ...viewModel.form_fields,
          user_id,
          title,
          date,
          status,
        };

        delete viewModel.form_fields.id;

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Edit_Calendar', viewModel);
          }

          const resourceExists = await db.calendar.getByPK(id);
          if (!resourceExists) {
            req.flash('error', 'Calendar not found');
            return res.redirect('/admin/calendar/0');
          }

          viewModel.session = req.session;

          const data = await db.calendar.edit({ user_id, title, date, status }, id);
          if (!data) {
            viewModel.error = 'Something went wrong';
            return res.render('admin/Edit_Calendar', viewModel);
          }

          req.flash('success', 'Calendar edited successfully');

          return res.redirect('/admin/calendar/0');
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          return res.render('admin/Edit_Calendar', viewModel);
        }
      },
    );

    app.get(
      '/admin/calendar-view/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),

      async function (req, res, next) {
        let id = req.params.id;

        const calendarAdminDetailViewModel = require('../../view_models/calendar_admin_detail_view_model');

        const viewModel = new calendarAdminDetailViewModel(db.calendar, 'Calendar details', '', '', '/admin/calendar');

        try {
          const data = await db.calendar.getByPK(id);
          data.status = db.calendar.status_mapping(data.status);

          if (!data) {
            viewModel.error = 'Calendar not found';
            viewModel.detail_fields = { ...viewModel.detail_fields, id: 'N/A', user_id: 'N/A', title: 'N/A', date: 'N/A', status: 'N/A' };
          } else {
            viewModel.detail_fields = {
              ...viewModel.detail_fields,
              id: data['id'] || '',
              user_id: data['user_id'] || '',
              title: data['title'] || '',
              date: data['date'] || '',
              status: data['status'] || '',
            };
          }

          res.render('admin/View_Calendar', viewModel);
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          viewModel.detail_fields = { ...viewModel.detail_fields, id: 'N/A', user_id: 'N/A', title: 'N/A', date: 'N/A', status: 'N/A' };
          res.render('admin/View_Calendar', viewModel);
        }
      },
    );

    app.get('/admin/calendar-delete/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;

      const calendarAdminDeleteViewModel = require('../../view_models/calendar_admin_delete_view_model');

      const viewModel = new calendarAdminDeleteViewModel(db.calendar);

      try {
        const exists = await db.calendar.getByPK(id);

        if (!exists) {
          req.flash('error', 'Calendar not found');

          return res.redirect('/admin/calendar/0');
        }

        viewModel.session = req.session;

        await db.calendar.realDelete(id);

        req.flash('success', 'Calendar was deleted successfully');

        return res.redirect('/admin/calendar/0');
      } catch (error) {
        console.dir(error, { depth: null });
        req.flash('error', 'Something went wrong');
        return res.redirect('/admin/calendar/0');
      }
    });

    // APIS

    app.post(
      '/admin/api/calendar-add',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { user_id: 'required|integer', title: 'required', date: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'title.required': 'Title is required',
          'date.required': 'Date is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        const calendarAdminAddViewModelJs = require('../../view_models/calendar_admin_add_view_model.js');

        const viewModel = new calendarAdminAddViewModelJs(db.calendar);

        const { user_id, title, date, status } = req.body;
        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const data = await db.calendar.insert({ user_id, title, date, status });

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          return res.status(201).json({ success: true, message: 'Calendar created successfully' });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.put(
      '/admin/api/calendar-edit/:id',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { user_id: 'required|integer', title: 'required', date: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'title.required': 'Title is required',
          'date.required': 'Date is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let id = req.params.id;

        const calendarAdminEditViewModel = require('../../view_models/calendar_admin_edit_view_model');

        const viewModel = new calendarAdminEditViewModel(db.calendar);

        const { user_id, title, date, status } = req.body;

        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const resourceExists = await db.calendar.getByPK(id);
          if (!resourceExists) {
            return res.status(404).json({ success: false, message: 'Calendar not found' });
          }

          const data = await db.calendar.edit({ user_id, title, date, status }, id);

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          return res.json({ success: true, message: 'Calendar edited successfully' });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.get('/admin/api/calendar-view/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const calendarAdminDetailViewModel = require('../../view_models/calendar_admin_detail_view_model');

      const viewModel = new calendarAdminDetailViewModel(db.calendar);

      try {
        const data = await db.calendar.getByPK(id);

        if (!data) {
          return res.status(404).json({ message: 'Calendar not found', data: null });
        } else {
          const fields = {
            ...viewModel.detail_fields,
            id: data['id'] || '',
            user_id: data['user_id'] || '',
            title: data['title'] || '',
            date: data['date'] || '',
            status: data['status'] || '',
          };
          return res.status(200).json({ data: fields });
        }
      } catch (error) {
        return res.status(404).json({ message: 'Something went wrong', data: null });
      }
    });

    app.delete('/admin/api/calendar-delete/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const calendarAdminDeleteViewModel = require('../../view_models/calendar_admin_delete_view_model');

      const viewModel = new calendarAdminDeleteViewModel(db.calendar);

      try {
        const exists = await db.calendar.getByPK(id);

        if (!exists) {
          return res.status(404).json({ success: false, message: 'Calendar not found' });
        }

        await db.calendar.realDelete(id);

        return res.status(200).json({ success: true, message: 'Calendar deleted successfully' });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Something went wrong' });
      }
    });

    return app;
  },
};
