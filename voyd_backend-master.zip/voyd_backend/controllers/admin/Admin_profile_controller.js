'use strict';

const Sequelize = require('sequelize')
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService')
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require("../../models");
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/profile/');





module.exports = {
  initializeApi: function (app) {
  const role = 1;







// APIS


app.get("/admin/api/profile", JwtService.verifyTokenMiddleware(role), async function (
  req,
  res,
  next
) {
  const user_id = req.user_id
  let listViewModel = require('../../view_models/profile_admin_list_view_model.js');
  let viewModel = new listViewModel(db.profile);

    try {
      

      const allItems = await db.profile.getAll({   })
      viewModel.set_list(allItems)
      const getJSON = viewModel.to_json()

      

      return res.status(200).json({success:true,data:getJSON})
    } catch (error) {

      return res.status(500).json({success:false, message:'Something went wrong'})

    }
});


app.post("/admin/api/profile-add", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"user_id":"required|integer","timezone":"required","dashboard_code":"required"},
            {"user_id.required":"UserId is required","user_id.integer":"UserId must be integer.","timezone.required":"Timezone is required","dashboard_code.required":"DashboardCode is required"}
          ), async function (
  req,
  res,
  next
) {
  const profileAdminAddViewModelJs = require("../../view_models/profile_admin_add_view_model.js")

  const viewModel = new profileAdminAddViewModelJs(db.profile)

  const { user_id,timezone,dashboard_code } = req.body;
  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    

          
          const data =  await db.profile.insert({ user_id,timezone,dashboard_code });
        

    if(!data){
      return res.status(500).json({success:false, message:"Something went wrong"})
    }

    

    

    return res.status(201).json({success:true, message:"Profile created successfully"});

  } catch(error){
    return res.status(500).json({success:false, message:"Something went wrong"})
  }
 
});



app.put("/admin/api/profile-edit/:id", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"user_id":"required|integer","timezone":"required","dashboard_code":"required"},
            {"user_id.required":"UserId is required","user_id.integer":"UserId must be integer.","timezone.required":"Timezone is required","dashboard_code.required":"DashboardCode is required"}
          ), async function (
  req,
  res,
  next
) {
  
  let id = req.params.id;
    
  const profileAdminEditViewModel = require("../../view_models/profile_admin_edit_view_model")

  const viewModel =new profileAdminEditViewModel(db.profile)
  
  const { user_id,timezone,dashboard_code } = req.body;

  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    const resourceExists = await db.profile.getByPK(id);
    if(!resourceExists){
      return res.status(404).json({success:false, message: 'Profile not found' })
    }

    

    const data = await db.profile.edit({ user_id,timezone,dashboard_code  }, id);

    if(!data){
      return res.status(500).json({success:false, message: "Something went wrong" })
    }

    
    
    

    return res.json({success:true, message:"Profile edited successfully"});
    
  } catch(error){
    return res.status(500).json({success:false, message: "Something went wrong" })
}

});



app.get(
  "/admin/api/profile-view/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
    
    const profileAdminDetailViewModel = require("../../view_models/profile_admin_detail_view_model")

    const viewModel =new profileAdminDetailViewModel(db.profile)
    
    try{

      

      const data = await db.profile.getByPK(id);

      

      if(!data){
        return res.status(404).json({message:"Profile not found", data:null})

      }else{
       const fields = {...viewModel.detail_fields, id:data["id"] || "",user_id:data["user_id"] || "",timezone:data["timezone"] || "",dashboard_code:data["dashboard_code"] || ""  }
         return res.status(200).json({data:fields})
      }

    } catch(error){
      return res.status(404).json({message:"Something went wrong", data:null})
    }
  }
);

app.delete(
  "/admin/api/profile-delete/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
   
    const profileAdminDeleteViewModel = require("../../view_models/profile_admin_delete_view_model")

    const viewModel =new   profileAdminDeleteViewModel(db.profile)
    
    
    try {
      const exists = await db.profile.getByPK(id);

      if(!exists){
        return res.status(404).json({success:false,message:'Profile not found'})
      }

      
      
      await db.profile.realDelete(id)

      
      
      
      
      return res.status(200).json({success:true, message:"Profile deleted successfully"})

      }catch(error){

      return res.status(500).json({success:false,message: 'Something went wrong'})    }
  }
);



    return app;
  }
};


