'use strict';

const Sequelize = require('sequelize');
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService');
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require('../../models');
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/image/');
const multer = require('multer');
const multerS3 = require('multer-s3');
const aws = require('aws-sdk');
const path = require('path');
const fs = require('fs');

module.exports = {
  initializeApi: function (app) {
    const role = 1;

    app.get('/admin/image/:num', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/image_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';
      const _where = {};

      let viewModel = new paginateListViewModel(db.image, 'Images', session.success, session.error, '/admin/image');

      // Check for flash messages
      const flashMessageSuccess = req.flash('success');
      if (flashMessageSuccess && flashMessageSuccess.length > 0) {
        viewModel.success = flashMessageSuccess[0];
      }
      const flashMessageError = req.flash('error');
      if (flashMessageError && flashMessageError.length > 0) {
        viewModel.error = flashMessageError[0];
      }

      try {
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/image');
        viewModel.set_order_by(order_by);
        viewModel.set_sort(direction);

        const where = { ..._where, ...viewModel.get_query() };
        const filteredWhere = Object.entries(where).reduce((accumulator, currentValue) => {
          const [key, value] = currentValue;
          if (!accumulator[key]) {
            if (value !== null && value !== '' && value !== undefined) {
              accumulator[key] = value;
            }
            return accumulator;
          }
        }, {});

        let sess = req.session;
        console.log('User Credential Ids: ' + sess.user.credential_id);

        const count = await db.image._count(filteredWhere, []);
        viewModel.set_total_rows(count);

        const allItems = await db.image.getPaginated(viewModel.get_page() - 1 < 0 ? 0 : viewModel.get_page() - 1, viewModel.get_per_page(), filteredWhere, order_by, direction);

        viewModel.set_list(allItems);

        if (format == 'csv') {
          const csv = viewModel.to_csv();
          return res
            .set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            })
            .send(csv);
        }

        return res.render('admin/User_image', viewModel);
      } catch (error) {
        console.log('Pagination error', error);
        viewModel.error = 'Something went wrong';
        return res.render('admin/User_image', viewModel);
      }
    });

    app.get('/admin/image-add', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }

      const imageAdminAddViewModelJs = require('../../view_models/image_admin_add_view_model.js');

      const viewModel = new imageAdminAddViewModelJs(db.image, 'Add image', '', '', '/admin/image');

      res.render('admin/Add_User_image', viewModel);
    });

    const storage = multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '..', '..', 'public', 'images', 'uploads'));
      },
      filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
      },
    });

    const upload = multer({
      storage: storage,
    });

    app.post(
      '/admin/image-add',
      SessionService.verifySessionMiddleware(role, 'admin'),
      upload.single('url'),
      ValidationService.validateInput(
        { status: 'required|integer', user_id: 'required|integer', type: 'required|integer' },
        {
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
          'user_id.required': 'User Id is required',
          'user_id.integer': 'User Id must be integer.',
          'type.integer': 'Type must be integer.',
          'type.required': 'Type is required',
        },
      ),
      async function (req, res, next) {
        let new_id = 0;
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }
        let new_user_id;
        const imageAdminAddViewModelJs = require('../../view_models/image_admin_add_view_model.js');

        const viewModel = new imageAdminAddViewModelJs(db.image, 'Add image', '', '', '/admin/image');

        const { caption, width, height, type, status, user_id } = req.body;

        db.image
          .findAll({
            where: {
              user_id: user_id,
            },
          })
          .then((data) => {
            data.forEach((item, index) => {
              new_user_id = item.user_id;
            });
          });

        console.log('User Id is: ' + new_user_id);

        const session_user_id = req.session;

        console.log('Session User Id: ' + session_user_id);

        if (new_user_id != user_id) {
          const url = req.file;

          console.log('Hello World!');
          if (!url) {
            viewModel.error = 'Url is required';
            return res.render('admin/Add_User_image', viewModel);
          }

          viewModel.form_fields = {
            ...viewModel.form_fields,

            url: url.path,
            caption,
            width,
            height,
            type,
            status,
            user_id: req.body.user_id,
          };

          try {
            if (req.validationError) {
              viewModel.error = req.validationError;
              return res.render('admin/Add_User_image', viewModel);
            }

            viewModel.session = req.session;

            console.log('URL Full: ' + JSON.stringify(url));
            let removePath = path.join(__dirname, '..', '..', 'public');
            let dev_path = '';

            if (process.env.NODE_ENV == 'development') {
              dev_path = 'http://localhost:3001';
            } else {
              dev_path = 'https://vyod.manaknightdigital.com';
            }
            let newPath = req.file.path.replace(removePath, dev_path);

            const data = await db.image.insert({
              url: newPath,
              caption,
              width,
              height,
              type,
              status,
              user_id: req.body.user_id,
            });

            if (!data) {
              viewModel.error = 'Something went wrong';
              return res.render('admin/Add_User_image', viewModel);
            }

            await db.activity_log.insert({
              action: 'ADD',
              name: 'Image_controller.js',
              portal: 'admin',
              data: JSON.stringify({
                url: newPath,
                caption,
                width,
                height,
                type,
                status,
                user_id: req.body.user_id,
              }),
            });

            req.flash('success', 'Image created successfully');
            return res.redirect('/admin/image/0');
          } catch (error) {
            console.error(error);
            viewModel.error = errors[error.message] || 'Something went wrong';
            return res.render('admin/Add_User_image', viewModel);
          }
        } else {
          const url = req.file;
          if (fs.existsSync(url.path)) {
            console.log('true');
            fs.unlinkSync(url.path);
          }
          req.flash('error', 'Each User can upload one image at one time!');
          return res.redirect('/admin/image/0');
        }
      },
    );

    app.get('/admin/image-edit/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }
      const imageAdminEditViewModel = require('../../view_models/image_admin_edit_view_model');

      const viewModel = new imageAdminEditViewModel(db.image, 'Edit image', '', '', '/admin/image');

      try {
        const exists = await db.image.getByPK(id);

        if (!exists) {
          req.flash('error', 'Image not found');
          return res.redirect('/admin/image/0');
        }
        const values = exists;
        Object.keys(viewModel.form_fields).forEach((field) => {
          viewModel.form_fields[field] = values[field] || '';
        });

        return res.render('admin/Edit_User_image', viewModel);
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        return res.render('admin/Edit_User_image', viewModel);
      }
    });

    app.post(
      '/admin/image-edit/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),
      upload.single('url'),
      ValidationService.validateInput(
        { id: 'required', status: 'required|integer' },
        {
          'id.required': 'Id is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let previous_url = '';
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }

        const imageAdminEditViewModel = require('../../view_models/image_admin_edit_view_model');

        const viewModel = new imageAdminEditViewModel(db.image, 'Edit image', '', '', '/admin/image');

        const { id, caption, width, height, type, status } = req.body;
        await db.image.getByField('id', id).then((data) => {
          previous_url = data.url;
        });

        // console.log('File URL: ' + JSON.stringify(req.file));

        let url = '';
        if (req.file != null) {
          console.log('File URL: ' + JSON.stringify(req.file));
          let removePath = path.join(__dirname, '..', '..', 'public');
          let dev_path = '';

          if (process.env.NODE_ENV == 'development') {
            dev_path = 'http://localhost:3001';
          } else {
            dev_path = 'https://vyod.manaknightdigital.com';
          }
          url = req.file.path.replace(removePath, 'http://localhost:3001');

          await db.image.getByField('id', id).then((res) => {
            console.log('URL is: ' + res.url);
            if (fs.existsSync(res.url)) {
              console.log('true');
              fs.unlinkSync(res.url);
            }
          });
        } else {
          url = previous_url;
        }

        console.log('URL EDIT: ' + JSON.stringify(req.file));
        if (!url) {
          viewModel.error = 'Url is required';
          return res.render('admin/Add_User_image', viewModel);
        }

        viewModel.form_fields = {
          ...viewModel.form_fields,
          id,
          url: url,
          caption,
          width,
          height,
          type,
          status,
        };

        delete viewModel.form_fields.id;

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Edit_User_image', viewModel);
          }

          const resourceExists = await db.image.getByPK(id);
          if (!resourceExists) {
            req.flash('error', 'Image not found');
            return res.redirect('/admin/image/0');
          }

          viewModel.session = req.session;

          const data = await db.image.edit({ id, url: url.path, caption, width, height, type, status }, id);
          if (!data) {
            viewModel.error = 'Something went wrong';
            return res.render('admin/Edit_User_image', viewModel);
          }

          await db.activity_log.insert({
            action: 'EDIT',
            name: 'Image_controller.js',
            portal: 'admin',
            data: JSON.stringify({
              id,
              url: url,
              caption,
              width,
              height,
              type,
              status,
            }),
          });

          req.flash('success', 'Image edited successfully');

          return res.redirect('/admin/image/0');
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          return res.render('admin/Edit_User_image', viewModel);
        }
      },
    );

    app.get(
      '/admin/image-view/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),

      async function (req, res, next) {
        let id = req.params.id;

        const imageAdminDetailViewModel = require('../../view_models/image_admin_detail_view_model');

        const viewModel = new imageAdminDetailViewModel(db.image, 'Image details', '', '', '/admin/image');

        try {
          const data = await db.image.getByPK(id);
          data.type = db.image.type_mapping(data.type);
          data.status = db.image.status_mapping(data.status);

          if (!data) {
            viewModel.error = 'Image not found';
            viewModel.detail_fields = {
              ...viewModel.detail_fields,
              id: 'N/A',
              url: 'N/A',
              caption: 'N/A',
              width: 'N/A',
              height: 'N/A',
              type: 'N/A',
              status: 'N/A',
            };
          } else {
            viewModel.detail_fields = {
              ...viewModel.detail_fields,
              id: data['id'] || '',
              url: data['url'] || '',
              caption: data['caption'] || '',
              width: data['width'] || '',
              height: data['height'] || '',
              type: data['type'] || '',
              status: data['status'] || '',
            };
          }

          res.render('admin/View_Image', viewModel);
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          viewModel.detail_fields = {
            ...viewModel.detail_fields,
            id: 'N/A',
            url: 'N/A',
            caption: 'N/A',
            width: 'N/A',
            height: 'N/A',
            type: 'N/A',
            status: 'N/A',
          };
          res.render('admin/View_Image', viewModel);
        }
      },
    );

    app.get('/admin/image-delete/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;

      const imageAdminDeleteViewModel = require('../../view_models/image_admin_delete_view_model');

      const viewModel = new imageAdminDeleteViewModel(db.image);

      try {
        const exists = await db.image.getByPK(id);

        if (!exists) {
          req.flash('error', 'Image not found');

          return res.redirect('/admin/image/0');
        }

        viewModel.session = req.session;

        await db.image.getByField('id', id).then((res) => {
          console.log('URL is: ' + res.url);
          if (fs.existsSync(res.url)) {
            console.log('true');
            fs.unlinkSync(res.url);
          }
        });
        await db.image.realDelete(id);

        // await db.activity_log.insert({
        //   action: 'DELETE',
        //   name: 'Image_controller.js',
        //   portal: 'admin',
        //   data: JSON.stringify(exists),
        // });

        req.flash('success', 'Image was deleted successfully');

        return res.redirect('/admin/image/0');
      } catch (error) {
        console.dir(error, { depth: null });
        req.flash('error', 'Something went wrong');
        return res.redirect('/admin/image/0');
      }
    });

    app.get('/admin/image-bulk-delete/:ids', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let ids = req.params.ids ? req.params.ids.split('|') : [];

      const imageAdminDeleteViewModel = require('../../view_models/image_admin_delete_view_model');

      const viewModel = new imageAdminDeleteViewModel(db.image);

      try {
        await db.image.delete(idArray);

        await db.activity_log.insert({
          action: 'BULK_DELETE',
          name: 'Image_controller.js',
          portal: 'admin',
          data: JSON.stringify({ ids }),
        });

        req.flash('success', ids.length + ' ' + 'item(s) were deleted.');
        res.redirect('/admin/image/0');
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        res.redirect('/admin/image/0');
      }
    });

    // APIS

    app.get('/admin/api/image/:num', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/image_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';
      const _where = {};

      let viewModel = new paginateListViewModel(db.image, 'image', session.success, session.error, '/admin/image');

      try {
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/image');
        viewModel.set_order_by(order_by);
        viewModel.set_sort(direction);

        const where = { ..._where, ...viewModel.get_query() };

        const count = await db.image._count(where);
        viewModel.set_total_rows(count);

        const allItems = await db.image.getPaginated(viewModel.get_page(), viewModel.get_per_page(), where, order_by, direction);

        viewModel.set_list(allItems);

        const getJSON = viewModel.to_json();

        return res.status(200).json({ success: true, data: getJSON });
      } catch (error) {
        console.log({ error });
        return res.status(500).json({ success: false, message: 'Something went wrong' });
      }
    });

    app.post(
      '/admin/api/image-add',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { id: 'required', url: 'required', status: 'required|integer' },
        {
          'id.required': 'Id is required',
          'url.required': 'Url is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        const imageAdminAddViewModelJs = require('../../view_models/image_admin_add_view_model.js');

        const viewModel = new imageAdminAddViewModelJs(db.image);

        const { url, caption, width, height, type, status } = req.body;
        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const data = await db.image.insert({
            id,
            url,
            caption,
            width,
            height,
            type,
            status,
          });

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          await db.activity_log.insert({
            action: 'ADD',
            name: 'Image_controller.js',
            portal: 'admin',
            data: JSON.stringify({
              id,
              url,
              caption,
              width,
              height,
              type,
              status,
            }),
          });

          return res.status(201).json({ success: true, message: 'Image created successfully' });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.put(
      '/admin/api/image-edit/:id',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { id: 'required', url: 'required', status: 'required|integer' },
        {
          'id.required': 'Id is required',
          'url.required': 'Url is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let id = req.params.id;

        const imageAdminEditViewModel = require('../../view_models/image_admin_edit_view_model');

        const viewModel = new imageAdminEditViewModel(db.image);

        const { url, caption, width, height, type, status } = req.body;

        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const resourceExists = await db.image.getByPK(id);
          if (!resourceExists) {
            return res.status(404).json({ success: false, message: 'Image not found' });
          }

          const data = await db.image.edit({ id, url, caption, width, height, type, status }, id);

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          await db.activity_log.insert({
            action: 'EDIT',
            name: 'Image_controller.js',
            portal: 'admin',
            data: JSON.stringify({
              id,
              url,
              caption,
              width,
              height,
              type,
              status,
            }),
          });

          return res.json({
            success: true,
            message: 'Image edited successfully',
          });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.get('/admin/api/image-view/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const imageAdminDetailViewModel = require('../../view_models/image_admin_detail_view_model');

      const viewModel = new imageAdminDetailViewModel(db.image);

      try {
        const data = await db.image.getByPK(id);

        if (!data) {
          return res.status(404).json({ message: 'Image not found', data: null });
        } else {
          const fields = {
            ...viewModel.detail_fields,
            id: data['id'] || '',
            url: data['url'] || '',
            caption: data['caption'] || '',
            width: data['width'] || '',
            height: data['height'] || '',
            type: data['type'] || '',
            status: data['status'] || '',
          };
          return res.status(200).json({ data: fields });
        }
      } catch (error) {
        return res.status(404).json({ message: 'Something went wrong', data: null });
      }
    });

    app.delete('/admin/api/image-delete/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const imageAdminDeleteViewModel = require('../../view_models/image_admin_delete_view_model');

      const viewModel = new imageAdminDeleteViewModel(db.image);

      try {
        const exists = await db.image.getByPK(id);

        if (!exists) {
          return res.status(404).json({ success: false, message: 'Image not found' });
        }

        await db.image.delete(id);

        await db.activity_log.insert({
          action: 'DELETE',
          name: 'Image_controller.js',
          portal: 'admin',
          data: JSON.stringify(exists),
        });

        return res.status(200).json({ success: true, message: 'Image deleted successfully' });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Something went wrong' });
      }
    });

    return app;
  },
};
