const SessionService = require('../../services/SessionService');


module.exports = {
    initializeApi: function (app) {
      const role = 1;

app.get(
    "/admin/dashboard",
    SessionService.verifySessionMiddleware(role,"admin"),
    async function (req, res, next) {

      res.render('admin/Dashboard',{
        get_page_name: () => 'Dashboard',
        _base_url: '/admin/dashboard',
      });
    }
  );

}
}
  