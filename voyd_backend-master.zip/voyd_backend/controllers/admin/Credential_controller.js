'use strict';

const Sequelize = require('sequelize')
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService')
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require("../../models");
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/credential/');





module.exports = {
  initializeApi: function (app) {
  const role = 1;

app.get("/admin/credentials/:num", SessionService.verifySessionMiddleware(role, "admin"),
   async function (
      req,
      res,
      next
    ) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/credential_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';
      const _where ={  }

      let viewModel =new paginateListViewModel(
        db.credential,
        "Users",
        session.success,
        session.error,
        '/admin/credentials');
        

        // Check for flash messages
        const flashMessageSuccess = req.flash('success');
        if (flashMessageSuccess && flashMessageSuccess.length > 0) {
          viewModel.success = flashMessageSuccess[0];
        }
        const flashMessageError = req.flash('error');
        if (flashMessageError && flashMessageError.length > 0) {
          viewModel.error = flashMessageError[0];
        }

        try {

          viewModel.set_per_page(25);
          viewModel.set_page(+req.params.num);
          viewModel.set_query(req.query);
          viewModel.set_sort_base_url('/admin/credentials');
          viewModel.set_order_by(order_by);
          viewModel.set_sort(direction);

          const where = {..._where,...viewModel.get_query() };
          const filteredWhere = Object.entries(where).reduce(
            (accumulator, currentValue) => {
              const [key, value] = currentValue;
              if (!accumulator[key]) {
                if (value !== null && value !== "" && value !== undefined) {
                  accumulator[key] = value;
                }
                return accumulator;
              }
            },
            {},
          );
          
          const count = await db.credential._count(filteredWhere,[]);
          viewModel.set_total_rows(count);

          

          const allItems = await db.credential.getPaginated(
           
            viewModel.get_page() - 1 < 0 ? 0 : viewModel.get_page() - 1,
            viewModel.get_per_page(),
            filteredWhere,
            order_by,
            direction)
        
            viewModel.set_list(allItems);

  
          if (format == 'csv') {
            const csv = viewModel.to_csv();
            return res.set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            }).send(csv)

          }
  
          // if (format != 'view') {
          //   return res.json(viewModel.to_json());
          // } else {
          // }

          

          return res.render('admin/User_credentials', viewModel);

        } catch (error) {
          console.log("Pagination error", error)
          viewModel.error = 'Something went wrong'
          return res.render('admin/User_credentials', viewModel);

        }
       
    });


app.get("/admin/credentials-add", SessionService.verifySessionMiddleware(role, "admin"),
  async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }

  const credentialAdminAddViewModelJs = require("../../view_models/credential_admin_add_view_model.js")


  const viewModel =new credentialAdminAddViewModelJs(db.credential,"Add credential", "","","/admin/credentials")
  
  

  res.render('admin/Add_User_credentials', 
  viewModel
  );
});


app.post("/admin/credentials-add", SessionService.verifySessionMiddleware(role,"admin"), ValidationService.validateInput(
        {"password":"required","email":"required|email"},
        {"password.required":"Password is required","email.required":"Email is required","email.email":"Invalid email"}
      ),
async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const credentialAdminAddViewModelJs = require("../../view_models/credential_admin_add_view_model.js")

 const viewModel = new credentialAdminAddViewModelJs(db.credential,"Add credential", "","","/admin/credentials")

// TODO use separate controller for image upload  
//  {{{upload_field_setter}}}

 const { password,role_id,status,email } = req.body;

 viewModel.form_fields =  {
   ...viewModel.form_fields,
   password,role_id,status,email
 }

 try{
   if (req.validationError) {
     viewModel.error = req.validationError;
     return res.render("admin/Add_User_credentials", viewModel);
   }

   viewModel.session = req.session

   

    
          
          const data =  await db.credential.insert({ password,role_id,status,email });
        


    if(!data){
      viewModel.error = "Something went wrong";
      return res.render("admin/Add_User_credentials", viewModel)
    }

   

   
          await db.activity_log.insert({
            action: 'ADD',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify({password,role_id,status,email, }),
          });          
        
    
   req.flash("success","Credential created successfully")
   return res.redirect("/admin/credentials/0");
 } catch(error){   
    console.dir(error, {depth: null});
    viewModel.error = errors[error.message] || 'Something went wrong';
    return res.render("admin/Add_User_credentials", viewModel)
 }
});



app.get("/admin/credentials-edit/:id", SessionService.verifySessionMiddleware(role,"admin"),  async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const credentialAdminEditViewModel = require("../../view_models/credential_admin_edit_view_model")

  const viewModel =new credentialAdminEditViewModel(db.credential,"Edit credential", "","","/admin/credentials")


  try{
    const exists = await db.credential.getByPK(id);

    if(!exists){
      req.flash('error', "Credential not found");
      return res.redirect("/admin/credentials/0")
    }
    const values = exists;
    Object.keys(viewModel.form_fields).forEach((field) => {
      
      viewModel.form_fields[field] = values[field] || '';
    });

    return res.render("admin/Edit_User_credentials",viewModel)
  } catch(error){
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_User_credentials", viewModel)
  }

});

app.post("/admin/credentials-edit/:id", SessionService.verifySessionMiddleware(role, "admin"), ValidationService.validateInput(
        {"status":"required"},
        {"status.required":"Status is required"}
      ), async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  

  const credentialAdminEditViewModel = require("../../view_models/credential_admin_edit_view_model")

  const viewModel =new credentialAdminEditViewModel(db.credential,"Edit credential", "","","/admin/credentials")

  
  const { status,email,verify } = req.body

  viewModel.form_fields = {
    ...viewModel.form_fields,
    status,email,verify
  }

    delete viewModel.form_fields.id

  try{
    if (req.validationError) {
      viewModel.error = req.validationError;
      return res.render("admin/Edit_User_credentials", viewModel)
    }



    const resourceExists = await db.credential.getByPK(id);
    if(!resourceExists){
      req.flash('error', "Credential not found");
      return res.redirect("/admin/credentials/0")
    }

    viewModel.session = req.session

    

    const data = await db.credential.edit({ status,email,verify  }, id);
    if(!data){
      viewModel.error = "Something went wrong"
      return res.render("admin/Edit_User_credentials", viewModel);
    }

    

    
          await db.activity_log.insert({
            action: 'EDIT',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify({status,email,verify, }),
          });          
        

    req.flash("success","Credential edited successfully")

    return res.redirect("/admin/credentials/0")
  } catch(error){    
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_User_credentials", viewModel);

  }
});


app.post(
  '/admin/credential/email_status-autocomplete',
  async function (req, res, next) {
    try {
      const { term } = req.body;

      const data = await db.credential.findAll({
        where: {
          [Sequelize.Op.or]: [
            {email:{
                  [Sequelize.Op.like]: "%" + term + "%"
                }},{status:{
                  [Sequelize.Op.like]: "%" + term + "%"
                }}
          ],
        },
        attributes: ['id', "email","status"],
        
      });

      return res.status(200).json(data);

    } catch (error) {
      return res
        .status(404)
        .json({ success:false, message: "Something went wrong" });
    }
  },
);
app.get(
  "/admin/credentials-view/:id",
  SessionService.verifySessionMiddleware(role, "admin"),
  
  async function (req, res, next) {
    let id = req.params.id;

    const credentialAdminDetailViewModel = require("../../view_models/credential_admin_detail_view_model")

    const viewModel =new credentialAdminDetailViewModel(db.credential,"Credential details","","","/admin/credentials")

    try{

      

      const data = await db.credential.getByPK(id);
      data.verify = db.credential.verify_mapping(data.verify);
data.status = db.credential.status_mapping(data.status);
data.role_id = db.credential.role_id_mapping(data.role_id);
data.two_factor_authentication = db.credential.two_factor_authentication_mapping(data.two_factor_authentication);
      
      if(!data){
        viewModel.error = "Credential not found"
        viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",email:"N/A",role_id:"N/A",status:"N/A"  }
      }
      else{
        viewModel.detail_fields = {...viewModel.detail_fields, id:data["id"] || "",email:data["email"] || "",role_id:data["role_id"] || "",status:data["status"] || ""  }
      }

      

      res.render('admin/View_Credential', viewModel);


    } catch(error){
      console.dir(error, {depth: null});
      viewModel.error = "Something went wrong"
      viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",email:"N/A",role_id:"N/A",status:"N/A"}
      res.render('admin/View_Credential', viewModel);

    }    

  }
);

app.get(
  "/admin/credentials-delete/:id",
  SessionService.verifySessionMiddleware(role,"admin"), 
  async function (req, res, next) {
  
    let id = req.params.id;
  
    const credentialAdminDeleteViewModel = require("../../view_models/credential_admin_delete_view_model")
    
    const viewModel = new credentialAdminDeleteViewModel(db.credential)
  
    try {
      const exists = await db.credential.getByPK(id);

      if(!exists){
        req.flash("error","Credential not found")

        return res.redirect("/admin/credentials/0")
      }

      viewModel.session = req.session

      

      await db.credential.delete(id)

      
      
      
          await db.activity_log.insert({
            action: 'DELETE',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify(exists),
          });          
        
      
      req.flash("success","Credential was deleted successfully")

      return res.redirect("/admin/credentials/0")
    }catch(error){
      console.dir(error, {depth: null});
      req.flash("error","Something went wrong")
      return res.redirect("/admin/credentials/0")
    }
    
  }
);



// APIS

app.get("/admin/api/credentials/:num", JwtService.verifyTokenMiddleware(role), 
 async function (
    req,
    res,
    next
  ) {
    let session = req.session;
    let paginateListViewModel = require('../../view_models/credential_admin_list_paginate_view_model');
    const format = req.query.format ? req.query.format : 'view';
    const order_by = req.query.order_by ? req.query.order_by : '';
    const direction = req.query.direction ? req.query.direction : 'ASC';
    const _where ={  }

    let viewModel =new paginateListViewModel(
      db.credential,
      "Users",
      session.success,
      session.error,
      '/admin/credentials');

      try {

        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/credentials');
        viewModel.set_order_by(order_by);
        viewModel.set_sort(direction);

        const where = {..._where,...viewModel.get_query() 
      };

        const count = await db.credential._count(where);
        viewModel.set_total_rows(count);

        


        const allItems= await db.credential.getPaginated(
          
          viewModel.get_page(),
          viewModel.get_per_page(),
          where,
          order_by,
          direction)
      
          viewModel.set_list(allItems);


          const getJSON = viewModel.to_json();

          

          return res.status(200).json({ success: true, data: getJSON });
      } catch (error) {
        console.log({ error });
        return res
          .status(500)
          .json({ success: false, message: 'Something went wrong' });
      }
  });


app.post("/admin/api/credentials-add", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"password":"required","email":"required|email"},
            {"password.required":"Password is required","email.required":"Email is required","email.email":"Invalid email"}
          ), async function (
  req,
  res,
  next
) {
  const credentialAdminAddViewModelJs = require("../../view_models/credential_admin_add_view_model.js")

  const viewModel = new credentialAdminAddViewModelJs(db.credential)

  const { password,role_id,status,email } = req.body;
  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    

          
          const data =  await db.credential.insert({ password,role_id,status,email });
        

    if(!data){
      return res.status(500).json({success:false, message:"Something went wrong"})
    }

    

    
          await db.activity_log.insert({
            action: 'ADD',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify({password,role_id,status,email, }),
          });          
        

    return res.status(201).json({success:true, message:"Credential created successfully"});

  } catch(error){
    return res.status(500).json({success:false, message:"Something went wrong"})
  }
 
});



app.put("/admin/api/credentials-edit/:id", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"status":"required"},
            {"status.required":"Status is required"}
          ), async function (
  req,
  res,
  next
) {
  
  let id = req.params.id;
    
  const credentialAdminEditViewModel = require("../../view_models/credential_admin_edit_view_model")

  const viewModel =new credentialAdminEditViewModel(db.credential)
  
  const { status,email,verify } = req.body;

  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    const resourceExists = await db.credential.getByPK(id);
    if(!resourceExists){
      return res.status(404).json({success:false, message: 'Credential not found' })
    }

    

    const data = await db.credential.edit({ status,email,verify  }, id);

    if(!data){
      return res.status(500).json({success:false, message: "Something went wrong" })
    }

    
    
    
          await db.activity_log.insert({
            action: 'EDIT',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify({status,email,verify, }),
          });          
        

    return res.json({success:true, message:"Credential edited successfully"});
    
  } catch(error){
    return res.status(500).json({success:false, message: "Something went wrong" })
}

});



app.get(
  "/admin/api/credentials-view/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
    
    const credentialAdminDetailViewModel = require("../../view_models/credential_admin_detail_view_model")

    const viewModel =new credentialAdminDetailViewModel(db.credential)
    
    try{

      

      const data = await db.credential.getByPK(id);

      

      if(!data){
        return res.status(404).json({message:"Credential not found", data:null})

      }else{
       const fields = {...viewModel.detail_fields, id:data["id"] || "",email:data["email"] || "",role_id:data["role_id"] || "",status:data["status"] || ""  }
         return res.status(200).json({data:fields})
      }

    } catch(error){
      return res.status(404).json({message:"Something went wrong", data:null})
    }
  }
);

app.delete(
  "/admin/api/credentials-delete/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
   
    const credentialAdminDeleteViewModel = require("../../view_models/credential_admin_delete_view_model")

    const viewModel =new   credentialAdminDeleteViewModel(db.credential)
    
    
    try {
      const exists = await db.credential.getByPK(id);

      if(!exists){
        return res.status(404).json({success:false,message:'Credential not found'})
      }

      
      
      await db.credential.delete(id)

      
      
      
          await db.activity_log.insert({
            action: 'DELETE',
            name: 'Credential_controller.js',
            portal: 'admin',
            data: JSON.stringify(exists),
          });          
        
      
      return res.status(200).json({success:true, message:"Credential deleted successfully"})

      }catch(error){

      return res.status(500).json({success:false,message: 'Something went wrong'})    }
  }
);



    return app;
  }
};


