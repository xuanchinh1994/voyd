'use strict';

const Sequelize = require('sequelize');
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService');
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require('../../models');
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/notes/');

module.exports = {
  initializeApi: function (app) {
    const role = 1;

    app.get('/admin/notes/:num', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/note_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';

      let viewModel = new paginateListViewModel(db.note, 'Notes', session.success, session.error, '/admin/notes');

      // Check for flash messages
      const flashMessageSuccess = req.flash('success');
      if (flashMessageSuccess && flashMessageSuccess.length > 0) {
        viewModel.success = flashMessageSuccess[0];
      }
      const flashMessageError = req.flash('error');
      if (flashMessageError && flashMessageError.length > 0) {
        viewModel.error = flashMessageError[0];
      }

      viewModel.set_id(req.query.id ? req.query.id : '');
      viewModel.set_user_id(req.query.user_id ? req.query.user_id : '');
      viewModel.set_message(req.query.message ? req.query.message : '');
      viewModel.set_status(req.query.status ? req.query.status : '');

      let where = {
        id: viewModel.get_id(),
        user_id: viewModel.get_user_id(),
        message: viewModel.get_message(),
        status: viewModel.get_status(),
      };

      const filteredWhere = Object.entries(where).reduce((accumulator, currentValue) => {
        const [key, value] = currentValue;
        if (!accumulator[key]) {
          if (value !== null && value !== '' && value !== undefined) {
            accumulator[key] = value;
          }
          return accumulator;
        }
      }, {});

      try {
        const count = await db.note._count(filteredWhere, []);

        viewModel.set_total_rows(count);
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/notes');

        const list = await db.note.getPaginated(viewModel.get_page() - 1 < 0 ? 0 : viewModel.get_page() - 1, viewModel.get_per_page(), filteredWhere, order_by, direction);
        viewModel.set_list(list);

        if (format == 'csv') {
          const csv = viewModel.to_csv();
          return res
            .set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            })
            .send(csv);
        }

        // if (format != 'view') {
        //   res.json(viewModel.to_json());
        // } else {
        // }

        return res.render('admin/Notes', viewModel);
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        return res.render('admin/Notes', viewModel);
      }
    });

    app.get('/admin/notes', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let session = req.session;
      let listViewModel = require('../../view_models/notes_admin_list_view_model.js');
      let viewModel = new listViewModel(db.note, 'Notes', session.success, session.error);

      // Check for flash messages
      const flashMessageSuccess = req.flash('success');
      if (flashMessageSuccess && flashMessageSuccess.length > 0) {
        viewModel.success = flashMessageSuccess[0];
      }
      const flashMessageError = req.flash('error');
      if (flashMessageError && flashMessageError.length > 0) {
        viewModel.error = flashMessageError[0];
      }

      try {
        const allItems = await db.note.getAll({});
        console.log('Notes Items: ' + JSON.stringify(allItems));
        viewModel.set_list(allItems);

        // if (format == 'csv') {
        //   const csv = viewModel.to_csv();
        //   return res.set({
        //     'Content-Type': 'text/csv',
        //     'Content-Disposition': 'attachment; filename="export.csv"',
        //   }).send(csv)

        // }

        res.render('admin/Notes', viewModel);
      } catch (error) {
        console.log('List error', error);
        // viewModel.error = 'Something went wrong'
        res.render('admin/Notes', viewModel);
      }
    });

    app.get('/admin/notes-add', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }

      const notesAdminAddViewModelJs = require('../../view_models/notes_admin_add_view_model.js');

      const viewModel = new notesAdminAddViewModelJs(db.note, 'Add notes', '', '', '/admin/notes');

      res.render('admin/Add_Notes', viewModel);
    });

    app.post(
      '/admin/notes-add',
      SessionService.verifySessionMiddleware(role, 'admin'),
      ValidationService.validateInput(
        { user_id: 'required|integer', message: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'message.required': 'Message is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let email = '';

        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }
        const notesAdminAddViewModelJs = require('../../view_models/notes_admin_add_view_model.js');

        const viewModel = new notesAdminAddViewModelJs(db.note, 'Add notes', '', '', '/admin/notes');

        // TODO use separate controller for image upload
        //  {{{upload_field_setter}}}

        const { user_id, message, status } = req.body;

        viewModel.form_fields = {
          ...viewModel.form_fields,
          user_id,
          message,
          status,
        };

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Add_Notes', viewModel);
          }

          viewModel.session = req.session;

          await db.credential.getByField('user_id', user_id).then((res) => {
            email = res.toJSON().email;
          });

          console.log('Usersss Emails: ' + email);
          const data = await db.note.insert({ user_id, message, status, email });

          if (!data) {
            return res.render('admin/Add_Notes', viewModel);
          }

          req.flash('success', 'Notes created successfully');
          return res.redirect('/admin/notes/0');
          // console.log('User Email: ' + email);
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = errors[error.message] || 'Something went wrong';
          return res.render('admin/Add_Notes', viewModel);
        }
      },
    );

    app.get('/admin/notes-edit/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;
      if (req.session.csrf === undefined) {
        req.session.csrf = SessionService.randomString(100);
      }
      const notesAdminEditViewModel = require('../../view_models/notes_admin_edit_view_model');

      const viewModel = new notesAdminEditViewModel(db.note, 'Edit notes', '', '', '/admin/notes');

      try {
        const exists = await db.note.getByPK(id);

        if (!exists) {
          req.flash('error', 'Notes not found');
          return res.redirect('/admin/notes/0');
        }
        const values = exists;
        Object.keys(viewModel.form_fields).forEach((field) => {
          viewModel.form_fields[field] = values[field] || '';
        });

        return res.render('admin/Edit_Notes', viewModel);
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        return res.render('admin/Edit_Notes', viewModel);
      }
    });

    app.post(
      '/admin/notes-edit/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),
      ValidationService.validateInput(
        { user_id: 'required|integer', message: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'message.required': 'Message is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let id = req.params.id;
        let email = '';
        if (req.session.csrf === undefined) {
          req.session.csrf = SessionService.randomString(100);
        }

        const notesAdminEditViewModel = require('../../view_models/notes_admin_edit_view_model');

        const viewModel = new notesAdminEditViewModel(db.note, 'Edit notes', '', '', '/admin/notes');

        const { user_id, message, status } = req.body;

        viewModel.form_fields = {
          ...viewModel.form_fields,
          user_id,
          message,
          status,
        };

        delete viewModel.form_fields.id;

        try {
          if (req.validationError) {
            viewModel.error = req.validationError;
            return res.render('admin/Edit_Notes', viewModel);
          }

          const resourceExists = await db.note.getByPK(id);
          if (!resourceExists) {
            req.flash('error', 'Notes not found');
            return res.redirect('/admin/notes/0');
          }

          viewModel.session = req.session;

          await db.credential.getByField('user_id', user_id).then((res) => {
            email = res.toJSON().email;
          });

          const data = await db.note.edit({ user_id, message, status, email }, id);
          if (!data) {
            viewModel.error = 'Something went wrong';
            return res.render('admin/Edit_Notes', viewModel);
          }

          req.flash('success', 'Notes edited successfully');

          return res.redirect('/admin/notes/0');
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          return res.render('admin/Edit_Notes', viewModel);
        }
      },
    );

    app.get(
      '/admin/notes-view/:id',
      SessionService.verifySessionMiddleware(role, 'admin'),

      async function (req, res, next) {
        let id = req.params.id;

        const notesAdminDetailViewModel = require('../../view_models/notes_admin_detail_view_model');

        const viewModel = new notesAdminDetailViewModel(db.note, 'Notes details', '', '', '/admin/notes');

        try {
          const data = await db.note.getByPK(id);
          data.status = db.note.status_mapping(data.status);

          if (!data) {
            viewModel.error = 'Notes not found';
            viewModel.detail_fields = { ...viewModel.detail_fields, id: 'N/A', user_id: 'N/A', message: 'N/A', status: 'N/A' };
          } else {
            viewModel.detail_fields = {
              ...viewModel.detail_fields,
              id: data['id'] || '',
              user_id: data['user_id'] || '',
              message: data['message'] || '',
              status: data['status'] || '',
            };
          }

          res.render('admin/View_Notes', viewModel);
        } catch (error) {
          console.dir(error, { depth: null });
          viewModel.error = 'Something went wrong';
          viewModel.detail_fields = { ...viewModel.detail_fields, id: 'N/A', user_id: 'N/A', message: 'N/A', status: 'N/A' };
          res.render('admin/View_Notes', viewModel);
        }
      },
    );

    app.get('/admin/notes-delete/:id', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let id = req.params.id;

      const notesAdminDeleteViewModel = require('../../view_models/notes_admin_delete_view_model');

      const viewModel = new notesAdminDeleteViewModel(db.note);

      try {
        const exists = await db.note.getByPK(id);

        if (!exists) {
          req.flash('error', 'Notes not found');

          return res.redirect('/admin/notes');
        }

        viewModel.session = req.session;

        await db.note.realDelete(id);

        req.flash('success', 'Notes was deleted successfully');

        return res.redirect('/admin/notes/0');
      } catch (error) {
        console.dir(error, { depth: null });
        req.flash('error', 'Something went wrong');
        return res.redirect('/admin/notes/0');
      }
    });

    app.get('/admin/notes-bulk-delete/:ids', SessionService.verifySessionMiddleware(role, 'admin'), async function (req, res, next) {
      let ids = req.params.ids ? req.params.ids.split('|') : [];

      const notesAdminDeleteViewModel = require('../../view_models/notes_admin_delete_view_model');

      const viewModel = new notesAdminDeleteViewModel(db.note);

      try {
        await db.note.realDelete(idArray);

        req.flash('success', ids.length + ' ' + 'item(s) were deleted.');
        res.redirect('/admin/notes');
      } catch (error) {
        console.dir(error, { depth: null });
        viewModel.error = 'Something went wrong';
        res.redirect('/admin/notes');
      }
    });

    // APIS

    app.get('/admin/api/notes', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      const user_id = req.user_id;
      let listViewModel = require('../../view_models/notes_admin_list_view_model.js');
      let viewModel = new listViewModel(db.note);

      try {
        const allItems = await db.note.getAll({});
        viewModel.set_list(allItems);
        const getJSON = viewModel.to_json();

        return res.status(200).json({ success: true, data: getJSON });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Something went wrong' });
      }
    });

    app.post(
      '/admin/api/notes-add',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { user_id: 'required|integer', message: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'message.required': 'Message is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        const notesAdminAddViewModelJs = require('../../view_models/notes_admin_add_view_model.js');

        const viewModel = new notesAdminAddViewModelJs(db.note);

        const { user_id, message, status } = req.body;
        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const data = await db.note.insert({ user_id, message, status });

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          return res.status(201).json({ success: true, message: 'Notes created successfully' });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.put(
      '/admin/api/notes-edit/:id',
      JwtService.verifyTokenMiddleware(role),
      ValidationService.validateInput(
        { user_id: 'required|integer', message: 'required', status: 'required|integer' },
        {
          'user_id.required': 'UserId is required',
          'user_id.integer': 'UserId must be integer.',
          'message.required': 'Message is required',
          'status.required': 'Status is required',
          'status.integer': 'Status must be integer.',
        },
      ),
      async function (req, res, next) {
        let id = req.params.id;

        const notesAdminEditViewModel = require('../../view_models/notes_admin_edit_view_model');

        const viewModel = new notesAdminEditViewModel(db.note);

        const { user_id, message, status } = req.body;

        try {
          if (req.validationError) {
            return res.status(500).json({ success: false, message: req.validationError });
          }

          const resourceExists = await db.note.getByPK(id);
          if (!resourceExists) {
            return res.status(404).json({ success: false, message: 'Notes not found' });
          }

          const data = await db.note.edit({ user_id, message, status }, id);

          if (!data) {
            return res.status(500).json({ success: false, message: 'Something went wrong' });
          }

          return res.json({ success: true, message: 'Notes edited successfully' });
        } catch (error) {
          return res.status(500).json({ success: false, message: 'Something went wrong' });
        }
      },
    );

    app.get('/admin/api/notes-view/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const notesAdminDetailViewModel = require('../../view_models/notes_admin_detail_view_model');

      const viewModel = new notesAdminDetailViewModel(db.note);

      try {
        const data = await db.note.getByPK(id);

        if (!data) {
          return res.status(404).json({ message: 'Notes not found', data: null });
        } else {
          const fields = { ...viewModel.detail_fields, id: data['id'] || '', user_id: data['user_id'] || '', message: data['message'] || '', status: data['status'] || '' };
          return res.status(200).json({ data: fields });
        }
      } catch (error) {
        return res.status(404).json({ message: 'Something went wrong', data: null });
      }
    });

    app.delete('/admin/api/notes-delete/:id', JwtService.verifyTokenMiddleware(role), async function (req, res, next) {
      let id = req.params.id;

      const notesAdminDeleteViewModel = require('../../view_models/notes_admin_delete_view_model');

      const viewModel = new notesAdminDeleteViewModel(db.note);

      try {
        const exists = await db.note.getByPK(id);

        if (!exists) {
          return res.status(404).json({ success: false, message: 'Notes not found' });
        }

        await db.note.realDelete(id);

        return res.status(200).json({ success: true, message: 'Notes deleted successfully' });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Something went wrong' });
      }
    });

    return app;
  },
};
