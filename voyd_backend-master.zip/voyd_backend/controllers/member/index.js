const Dashboard = require("./Dashboard");
const MemberNotesController = require("./Member_notes_controller");
const UserController = require("./User_Controller");

module.exports = {
              initializeApi: function (app) {
                const controllers = [Dashboard,MemberNotesController,UserController]
                controllers.forEach((item) => item.initializeApi(app))
              },
            }
            