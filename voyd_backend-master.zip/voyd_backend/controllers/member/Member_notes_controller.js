'use strict';

const Sequelize = require('sequelize')
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService')
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require("../../models");
const { errors } = require('../../core/strings');
const upload = UploadService.upload('member/note/');





module.exports = {
  initializeApi: function (app) {
  const role = 2;







// APIS








    return app;
  }
};


