'use strict';

const Sequelize = require('sequelize')
const logger = require('../../services/LoggingService');
let pagination = require('../../services/PaginationService');
let SessionService = require('../../services/SessionService');
let JwtService = require('../../services/JwtService');
const ValidationService = require('../../services/ValidationService')
const PermissionService = require('../../services/PermissionService');
const UploadService = require('../../services/UploadService');
const AuthService = require('../../services/AuthService');
const db = require("../../models");
const { errors } = require('../../core/strings');
const upload = UploadService.upload('admin/user/');





module.exports = {
  initializeApi: function (app) {
  const role = 2;

app.get("/member/users/:num", SessionService.verifySessionMiddleware(role, "member"),
   async function (
      req,
      res,
      next
    ) {
      let session = req.session;
      let paginateListViewModel = require('../../view_models/user_admin_list_paginate_view_model');
      const format = req.query.format ? req.query.format : 'view';
      const order_by = req.query.order_by ? req.query.order_by : '';
      const direction = req.query.direction ? req.query.direction : 'ASC';

      let viewModel =new paginateListViewModel(
        db.user,
        "Users",
        session.success,
        session.error,
        '/admin/users');

        // Check for flash messages
        const flashMessageSuccess = req.flash('success');
        if (flashMessageSuccess && flashMessageSuccess.length > 0) {
          viewModel.success = flashMessageSuccess[0];
        }
        const flashMessageError = req.flash('error');
        if (flashMessageError && flashMessageError.length > 0) {
          viewModel.error = flashMessageError[0];
        }

      viewModel.set_id(req.query.id ? req.query.id : '');
		viewModel.set_email(req.query.email ? req.query.email : '');
		viewModel.set_first_name(req.query.first_name ? req.query.first_name : '');
		viewModel.set_last_name(req.query.last_name ? req.query.last_name : '');
		

      let where = {
        'id': viewModel.get_id(),
			"$credential.email$": viewModel.get_email(),
			'first_name': viewModel.get_first_name(),
			'last_name': viewModel.get_last_name(),
			
        
        
      };


      const filteredWhere = Object.entries(where).reduce(
        (accumulator, currentValue) => {
          const [key, value] = currentValue;
          if (!accumulator[key]) {
            if (value !== null) {
              accumulator[key] = value;
            }
            return accumulator;
          }
        },
        {},
      );


      try {
        const count  = await db.user._count(filteredWhere,[{model: db.credential, as: 'credential' }]);

        viewModel.set_total_rows(count);  
        viewModel.set_per_page(25);
        viewModel.set_page(+req.params.num);
        viewModel.set_query(req.query);
        viewModel.set_sort_base_url('/admin/users');

        


        const list = await db.user.get_credential_paginated(
          db,
          viewModel.get_page(),
          viewModel.get_per_page(),
          filteredWhere,
          order_by,
          direction)
        viewModel.set_list(list);

        

        if (format == 'csv') {
          const csv = viewModel.to_csv();
          return res
            .set({
              'Content-Type': 'text/csv',
              'Content-Disposition': 'attachment; filename="export.csv"',
            })
            .send(csv);
        }

        // if (format != 'view') {
        //   res.json(viewModel.to_json());
        // } else {
        // }

        

        return res.render('admin/User', viewModel);
      } catch (error) {
        console.dir(error, {depth: null});
        viewModel.error = "Something went wrong"
        return res.render('admin/User', viewModel);
      }

       
    });

    

app.get("/member/users-add", SessionService.verifySessionMiddleware(role, "member"),
  async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }

  const userAdminAddViewModelJs = require("../../view_models/user_member_add_view_model.js")


  const viewModel =new userAdminAddViewModelJs(db.user,"Add user", "","","/member/users")
  
  

  res.render('member/Add_User', 
  viewModel
  );
});


app.post("/member/users-add", SessionService.verifySessionMiddleware(role,"member"), ValidationService.validateInput(
        {"first_name":"required","last_name":"required"},
        {"first_name.required":"FirstName is required","last_name.required":"LastName is required"}
      ),
async function (
  req,
  res,
  next
) {
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const userAdminAddViewModelJs = require("../../view_models/user_member_add_view_model.js")

 const viewModel = new userAdminAddViewModelJs(db.user,"Add user", "","","/member/users")

// TODO use separate controller for image upload  
//  {{{upload_field_setter}}}

 const { email,password,first_name,last_name,role_id,phone } = req.body;

 viewModel.form_fields =  {
   ...viewModel.form_fields,
   email,password,first_name,last_name,role_id,phone
 }

 try{
   if (req.validationError) {
     viewModel.error = req.validationError;
    //  return res.render("member/Add_User", viewModel);
   }

   viewModel.session = req.session

   

    
    
          const { email, password = '', role_id, ...rest } = viewModel.form_fields;
          const data = await AuthService.register(
            email,
            password,
            role_id,
            rest,
          );
        


    if(!data){
      viewModel.error = "Something went wrong";
    //   return res.render("member/Add_User", viewModel)
    }

   
    console.log('Data:' + JSON.stringify({email,password}));
   
          await db.activity_log.insert({
            action: 'ADD',
            name: 'User_controller.js',
            portal: 'member',
            data: JSON.stringify({email,password,first_name,last_name,role_id,phone, }),
          });          
        
    
   req.render("success","User created successfully")
//    return res.redirect("/member/users/0");
 } catch(error){   
    console.dir(error, {depth: null});
    viewModel.error = errors[error.message] || 'Something went wrong';
    // return res.render("member/Add_User", viewModel)
    req.flash("success","User created successfully")
 }
});



app.get("/member/users-edit/:id", SessionService.verifySessionMiddleware(role,"member"),  async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  const userAdminEditViewModel = require("../../view_models/user_admin_edit_view_model")

  const viewModel =new userAdminEditViewModel(db.user,"Edit user", "","","/member/users")


  try{
    const exists = await db.user.get_user_credential(id, db);

    if(!exists){
      req.flash('error', "User not found");
    //   return res.redirect("/member/users/0")
    }
    const values = exists;
    Object.keys(viewModel.form_fields).forEach((field) => {
      if (field === 'email') {
             viewModel.form_fields[field] = values["credential"][field];
             return;
           }
      viewModel.form_fields[field] = values[field] || '';
    });

    return res.render("admin/Edit_User",viewModel)
  } catch(error){
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_User", viewModel)
  }

});

app.post("/admin/users-edit/:id", SessionService.verifySessionMiddleware(role, "admin"),  async function (
  req,
  res,
  next
) {
  let id = req.params.id;
  if (req.session.csrf === undefined) {
    req.session.csrf = SessionService.randomString(100);
  }
  

  const userAdminEditViewModel = require("../../view_models/user_admin_edit_view_model")

  const viewModel =new userAdminEditViewModel(db.user,"Edit user", "","","/admin/users")

  
  const { email,first_name,last_name,role_id,phone,status } = req.body

  viewModel.form_fields = {
    ...viewModel.form_fields,
    email,first_name,last_name,role_id,phone,status
  }

    delete viewModel.form_fields.id

  try{
    if (req.validationError) {
      viewModel.error = req.validationError;
      return res.render("admin/Edit_User", viewModel)
    }



    const resourceExists = await db.user.getByPK(id);
    if(!resourceExists){
      req.flash('error', "User not found");
      return res.redirect("/admin/users/0")
    }

    viewModel.session = req.session

    

    const data = await db.user.edit({ email,first_name,last_name,role_id,phone,status  }, id);
    if(!data){
      viewModel.error = "Something went wrong"
      return res.render("admin/Edit_User", viewModel);
    }

    const credential = await db.credential.getByField('user_id', id);
if (!credential) {
throw new Error();
}
 await db.credential.edit({ email, status }, credential.id);

    
          await db.activity_log.insert({
            action: 'EDIT',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify({email,first_name,last_name,role_id,phone,status, }),
          });          
        

    req.flash("success","User edited successfully")

    return res.redirect("/admin/users/0")
  } catch(error){    
    console.dir(error, {depth: null});
    viewModel.error = "Something went wrong"
    return res.render("admin/Edit_User", viewModel);

  }
});



app.get(
  "/admin/users-view/:id",
  SessionService.verifySessionMiddleware(role, "admin"),
  
  async function (req, res, next) {
    let id = req.params.id;

    const userAdminDetailViewModel = require("../../view_models/user_admin_detail_view_model")

    const viewModel =new userAdminDetailViewModel(db.user,"User details","","","/admin/users")

    try{

      

      const data = await db.user.get_user_credential(id, db)
      data.status = db.user.status_mapping(data.status);
      
      if(!data){
        viewModel.error = "User not found"
        viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",email:"N/A",first_name:"N/A",last_name:"N/A",role_id:"N/A",status:"N/A"  }
      }
      else{
        viewModel.detail_fields = {...viewModel.detail_fields, id:data["id"] || "",email:data['credential']["email"] || "",first_name:data["first_name"] || "",last_name:data["last_name"] || "",role_id:data["role_id"] || "",status:data["status"] || ""  }
      }

      

      res.render('admin/View_User', viewModel);


    } catch(error){
      console.dir(error, {depth: null});
      viewModel.error = "Something went wrong"
      viewModel.detail_fields = {...viewModel.detail_fields, id:"N/A",email:"N/A",first_name:"N/A",last_name:"N/A",role_id:"N/A",status:"N/A"}
      res.render('admin/View_User', viewModel);

    }    

  }
);

app.get(
  "/admin/users-delete/:id",
  SessionService.verifySessionMiddleware(role,"admin"), 
  async function (req, res, next) {
  
    let id = req.params.id;
  
    const userAdminDeleteViewModel = require("../../view_models/user_admin_delete_view_model")
    
    const viewModel = new userAdminDeleteViewModel(db.user)
  
    try {
      const exists = await db.user.getByPK(id);

      if(!exists){
        req.flash("error","User not found")

        return res.redirect("/admin/users/0")
      }

      viewModel.session = req.session

      

      await db.user.delete(id)

      	
const credential = await db.credential.getByField('user_id', id);
if (!credential) {
throw new Error();
	}
await db.credential.delete(credential.id)
      
      
          await db.activity_log.insert({
            action: 'DELETE',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify(exists),
          });          
        
      
      req.flash("success","User was deleted successfully")

      return res.redirect("/admin/users/0")
    }catch(error){
      console.dir(error, {depth: null});
      req.flash("error","Something went wrong")
      return res.redirect("/admin/users/0")
    }
    
  }
);

app.get(
  '/admin/users-bulk-delete/:ids',
  SessionService.verifySessionMiddleware(role, 'admin'),
  async function (req, res, next) {
    let ids = req.params.ids ? req.params.ids.split('|') : [];

    const userAdminDeleteViewModel = require("../../view_models/user_admin_delete_view_model")
    
    const viewModel = new  userAdminDeleteViewModel(db.user)
  
    try {
      

      await db.user.delete(idArray);

      await db.credential.delete(ids)
      
      
          await db.activity_log.insert({
            action: 'BULK_DELETE',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify({ids}),
          });          
        
      
      req.flash('success', ids.length + ' ' + 'item(s) were deleted.');
      res.redirect("/admin/users/0")
    }catch(error){
      console.dir(error, {depth:null});
      viewModel.error = "Something went wrong"
      res.redirect("/admin/users/0")
    }
  },
);

// APIS


app.post("/admin/api/users-add", JwtService.verifyTokenMiddleware(role),ValidationService.validateInput(
            {"first_name":"required","last_name":"required"},
            {"first_name.required":"FirstName is required","last_name.required":"LastName is required"}
          ), async function (
  req,
  res,
  next
) {
  const userAdminAddViewModelJs = require("../../view_models/user_admin_add_view_model.js")

  const viewModel = new userAdminAddViewModelJs(db.user)

  const { email,password,first_name,last_name,role_id,phone } = req.body;
  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    

    
          const { email, password = '', role_id, ...rest } = req.body;
          const data = await AuthService.register(
            email,
            password,
            role_id,
            rest,
          );
        

    if(!data){
      return res.status(500).json({success:false, message:"Something went wrong"})
    }

    

    
          await db.activity_log.insert({
            action: 'ADD',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify({email,password,first_name,last_name,role_id,phone, }),
          });          
        

    return res.status(201).json({success:true, message:"User created successfully"});

  } catch(error){
    return res.status(500).json({success:false, message:"Something went wrong"})
  }
 
});



app.put("/admin/api/users-edit/:id", JwtService.verifyTokenMiddleware(role), async function (
  req,
  res,
  next
) {
  
  let id = req.params.id;
    
  const userAdminEditViewModel = require("../../view_models/user_admin_edit_view_model")

  const viewModel =new userAdminEditViewModel(db.user)
  
  const { email,first_name,last_name,role_id,phone,status } = req.body;

  try{
    if (req.validationError) {
      return res.status(500).json({success:false, message: req.validationError })
    }

    const resourceExists = await db.user.getByPK(id);
    if(!resourceExists){
      return res.status(404).json({success:false, message: 'User not found' })
    }

    

    const data = await db.user.edit({ email,first_name,last_name,role_id,phone,status  }, id);

    if(!data){
      return res.status(500).json({success:false, message: "Something went wrong" })
    }

    const credential = await db.credential.getByField('user_id', id);
if (!credential) {
throw new Error();
}
 await db.credential.edit({ email, status }, credential.id);
    
    
          await db.activity_log.insert({
            action: 'EDIT',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify({email,first_name,last_name,role_id,phone,status, }),
          });          
        

    return res.json({success:true, message:"User edited successfully"});
    
  } catch(error){
    return res.status(500).json({success:false, message: "Something went wrong" })
}

});



app.get(
  "/admin/api/users-view/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
    
    const userAdminDetailViewModel = require("../../view_models/user_admin_detail_view_model")

    const viewModel =new userAdminDetailViewModel(db.user)
    
    try{

      

      const data = await db.user.get_user_credential(id, db)

      

      if(!data){
        return res.status(404).json({message:"User not found", data:null})

      }else{
       const fields = {...viewModel.detail_fields, id:data["id"] || "",email:data['credential']["email"] || "",first_name:data["first_name"] || "",last_name:data["last_name"] || "",role_id:data["role_id"] || "",status:data["status"] || ""  }
         return res.status(200).json({data:fields})
      }

    } catch(error){
      return res.status(404).json({message:"Something went wrong", data:null})
    }
  }
);

app.delete(
  "/admin/api/users-delete/:id",
  JwtService.verifyTokenMiddleware(role),
  async function (req, res, next) {
    let id = req.params.id;
   
    const userAdminDeleteViewModel = require("../../view_models/user_admin_delete_view_model")

    const viewModel =new   userAdminDeleteViewModel(db.user)
    
    
    try {
      const exists = await db.user.getByPK(id);

      if(!exists){
        return res.status(404).json({success:false,message:'User not found'})
      }

      
      
      await db.user.delete(id)

      	
const credential = await db.credential.getByField('user_id', id);
if (!credential) {
throw new Error();
	}
await db.credential.delete(credential.id)
      
      
          await db.activity_log.insert({
            action: 'DELETE',
            name: 'User_controller.js',
            portal: 'admin',
            data: JSON.stringify(exists),
          });          
        
      
      return res.status(200).json({success:true, message:"User deleted successfully"})

      }catch(error){

      return res.status(500).json({success:false,message: 'Something went wrong'})    }
  }
);



    return app;
  }
};


