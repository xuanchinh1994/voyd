const SessionService = require('../../services/SessionService');


module.exports = {
    initializeApi: function (app) {
      const role = 2;

app.get(
    "/member/dashboard",
    SessionService.verifySessionMiddleware(role,"member"),
    async function (req, res, next) {

      res.render('member/Dashboard',{
        get_page_name: () => 'Dashboard',
        _base_url: '/member/dashboard',
      });
    }
  );

}
}
  