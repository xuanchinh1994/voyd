const AdminControllers = require('./admin/index');
const MemberControllers = require('./member/index');
const GlobalControllers = require('./global/index');

module.exports = function initializeApi(app) {
  const allControllers = [AdminControllers, MemberControllers, GlobalControllers];

  allControllers.forEach((item) => item.initializeApi(app));
  return app;
};
