import React from 'react';
import RNBootSplash from 'react-native-bootsplash';
import {ApolloProvider} from '@apollo/client';
import {ApolloProvider as ApolloProviderClient} from '@apollo/react-hooks';
import Toast from 'react-native-toast-message';
import {NavigationContainer} from '@react-navigation/native';
import {PersistGate} from 'redux-persist/integration/react';
import {Provider} from 'react-redux';

import AppNavigator from './src/navigators/AppNavigator';
import configureStore from './src/redux';
import client from './src/apollo';
import toastConfig from './src/tools/toastConfig';
import {withAppDetails} from './src/components/HOC';
import {navigationRef, isReadyRef} from './src/navigators/NavigationService';

const {store, persistor} = configureStore();

function App() {
  React.useEffect(() => {
    RNBootSplash.hide({fade: true});
  }, []);

  return (
    <ApolloProvider client={client}>
      <ApolloProviderClient client={client}>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <NavigationContainer
              ref={navigationRef}
              onReady={() => {
                isReadyRef.current = true;
              }}>
              <AppNavigator />
              <Toast ref={ref => Toast.setRef(ref)} config={toastConfig} />
            </NavigationContainer>
          </PersistGate>
        </Provider>
      </ApolloProviderClient>
    </ApolloProvider>
  );
}

export default withAppDetails(App);
