const actionTypes = Object.freeze({
  HIDE_LOADER: 'HIDE_LOADER',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  UPDATE_PROFILE: 'UPDATE_PROFILE',
  SET_CURRENT_LOCATION: 'SET_CURRENT_LOCATION',
});

export default actionTypes;
