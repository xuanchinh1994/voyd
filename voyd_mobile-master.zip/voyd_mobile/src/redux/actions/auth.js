import actionTypes from '../actionTypes';

export const login = payload => ({
  type: actionTypes.LOGIN,
  payload,
});

export const logout = payload => ({
  type: actionTypes.LOGOUT,
  payload,
});

export const updateProfile = payload => ({
  type: actionTypes.UPDATE_PROFILE,
  payload,
});

export const setCurrentLocation = payload => ({
  type: actionTypes.SET_CURRENT_LOCATION,
  payload,
});
