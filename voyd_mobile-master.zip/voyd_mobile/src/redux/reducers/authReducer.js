import AsyncStorage from '@react-native-community/async-storage';

import actionTypes from '../actionTypes';
import {persistent} from '../../assets/strings';

const INITIAL_STATE = {
  access_token: '',
  refresh_token: '',
  user: null,
  doesUserChangedPassword: false,
  currentLocation: null,
};

const setToken = async (accessToken, refreshToken, userID) => {
  try {
    //?? Multi-set was not working
    await AsyncStorage.setItem(persistent.ACCESS_TOKEN, accessToken);
    await AsyncStorage.setItem(persistent.REFRESH_TOKEN, refreshToken);
    await AsyncStorage.setItem(persistent.USER_ID, JSON.stringify(userID));
  } catch (_) {}
};

export default (state = INITIAL_STATE, action) => {
  const {type} = action;

  switch (type) {
    case actionTypes.LOGIN:
      setToken(
        action.payload.access_token,
        action.payload.refresh_token,
        action?.payload?.user?.userId,
      );
      return {
        ...state,
        access_token: action.payload.access_token,
        refresh_token: action.payload.refresh_token,
        user: action.payload?.user,
      };

    case actionTypes.UPDATE_PROFILE:
      return {
        ...state,
        user: {
          ...(state.user ?? {}),
          ...action?.payload,
        },
      };
    case actionTypes.REFRESH_USER:
      return {
        ...state,
        user: action.payload.user,
      };
    case actionTypes.SET_CURRENT_LOCATION:
      return {
        ...state,
        currentLocation: action?.payload || null,
      };

    case actionTypes.LOGOUT:
      return {
        ...INITIAL_STATE,
        doesUserChangedPassword:
          action?.payload?.doesUserChangedPassword || false,
      };

    default:
      return state;
  }
};
