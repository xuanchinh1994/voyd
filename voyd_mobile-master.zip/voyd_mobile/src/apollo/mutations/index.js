import {gql} from '@apollo/client';

export const CREATE_LINK = gql`
  mutation createLink($link: String!) {
    createLink(link: $link) {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const CREATE_NOTE = gql`
  mutation ($message: String!) {
    createNote(message: $message) {
      success
      message
      errors {
        path
        message
      }
      code
    }
  }
`;
export const UPDATE_NOTE = gql`
  mutation ($message: String!, $id: ID!) {
    updateNote(message: $message, id: $id) {
      success
      message
      errors {
        path
        message
      }
      code
    }
  }
`;
export const DELETE_NOTE = gql`
  mutation ($id: ID!) {
    deleteNote(id: $id) {
      success
      message
      errors {
        path
        message
      }
      code
    }
  }
`;

export const SYNC_CALENDAR = gql`
  mutation ($input: [SyncCalendarInput!]) {
    syncCalendar(input: $input) {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const UPLOAD_FILE = gql`
  mutation uploadFile($file: Upload!) {
    uploadFile(file: $file) {
      success
      data {
        id
        path
      }
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const CREATE_CUSTOM_IMAGE = gql`
  mutation createCustomImage($url: String!) {
    createCustomImage(url: $url) {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const UPDATE_CUSTOM_IMAGE = gql`
  mutation updateCustomImage($id: ID!, $url: String!) {
    updateCustomImage(id: $id, url: $url) {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const DELETE_CUSTOM_IMAGE = gql`
  mutation deleteCustomImage($id: ID!) {
    deleteCustomImage(id: $id) {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const DEACTIVATE_ALL_LINKS = gql`
  mutation {
    deactivateAllLinks {
      success
      message
      code
      errors {
        path
        message
      }
    }
  }
`;

export const UPDATE_USER = gql`
  mutation updateUser(
    $syncCode: String
    $fontColor: String
    $timezone: String
    $timeFormat: Int
    $clockFormat: Int
    $dateFormat: Int
    $location: String
    $lat: Float
    $lng: Float
  ) {
    updateUser(
      sync_code: $syncCode
      font_color: $fontColor
      time_zone: $timezone
      time_format: $timeFormat
      clock_format: $clockFormat
      date_format: $dateFormat
      location: $location
      lat: $lat
      lng: $lng
    ) {
      success
      message
      errors {
        path
        message
      }
      code
    }
  }
`;
