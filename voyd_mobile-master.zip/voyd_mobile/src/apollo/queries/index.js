import {gql} from '@apollo/client';

export const GET_ALL_NOTES = gql`
  {
    getAllNotes {
      success
      errors {
        path
        message
      }
      data {
        id
        message
        user {
          first_name
        }
      }
    }
  }
`;

export const GET_ALL_CALENDAR_EVENTS = gql`
  {
    getAllCalendarEvents {
      success
      message
      errors {
        path
        message
      }
      code
      data
    }
  }
`;

export const GET_CUSTOM_IMAGE = gql`
  {
    getCustomImage {
      success
      message
      errors {
        path
        message
      }
      code
      data {
        id
        url
      }
    }
  }
`;

export const GET_USER = gql`
  {
    user {
      code
      data {
        time_zone
        time_format
        sync_code
        font_color
        clock_format
        date_format
        location
      }
    }
  }
`;

export const GET_LINK = gql`
  {
    link {
      success
      code
      data {
        id
        link
      }
    }
  }
`;

export const GET_STEPS_IMAGES = gql`
  {
    getStepsImages {
      success
      code
      data
    }
  }
`;
