import {createHttpLink} from '@apollo/client';
import {GRAPHQL_URL, GRAPHQL_URL_DEV} from '@env';

const uri =
  process.env.NODE_ENV === 'development' ? GRAPHQL_URL_DEV : GRAPHQL_URL;

const http = createHttpLink({
  uri,
});

export default http;
