import React from 'react';
import {Text, ActivityIndicator, TouchableOpacity} from 'react-native';
import colors from '../../assets/colors';
import styles from './styles';

function Button(props) {
  const {
    text,
    color,
    subText,
    subTextColor,
    backgroundColor,
    disabled,
    loading,
    onPress,
    bold,
    subTextBold,
  } = props;

  const style = {
    ...styles.container,
    backgroundColor: backgroundColor || colors.primary,
    padding: subText ? 6 : 15,
    minHeight: 55,
    ...props.style,
  };

  const textStyle = {
    ...styles.text,
    fontWeight: bold ? 'bold' : 'normal',
    color: color || colors.white,
    ...props.textStyle,
  };

  const subTextStyle = {
    ...styles.subText,
    fontWeight:
      subTextBold !== undefined
        ? subTextBold
          ? 'bold'
          : 'normal'
        : textStyle.fontWeight,
    color: subTextColor || textStyle.color,
    ...props.subTextStyle,
  };

  // darken if disabled
  if (disabled) {
    style.backgroundColor = 'black';
    style.opacity = 0.5;
    textStyle.opacity = 0.5;
  }

  // remove padding for activity indicator
  if (loading) {
    style.padding = Number(style.padding) - 5;
  }

  const content = props.children || (
    <>
      <Text style={textStyle}>{text}</Text>
      {subText ? <Text style={subTextStyle}>{subText}</Text> : null}
    </>
  );

  const loadingIndicator = props.loadingIndicator || (
    <ActivityIndicator size="large" color="#FFFFFF" />
  );

  return (
    <TouchableOpacity style={style} disabled={disabled} onPress={onPress}>
      {loading ? loadingIndicator : content}
    </TouchableOpacity>
  );
}

export default Button;
