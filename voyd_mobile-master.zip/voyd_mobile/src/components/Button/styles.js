import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  text: {
    fontSize: 18,
    textAlign: 'center',
  },
  subText: {
    fontSize: 13,
    textAlign: 'center',
  },
});
