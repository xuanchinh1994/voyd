import React, {useCallback, useMemo, useRef} from 'react';
import {
  View,
  StyleSheet,
  StatusBar,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  BackHandler,
} from 'react-native';
import {
  BottomSheetView,
  BottomSheetModal,
  BottomSheetModalProvider,
  BottomSheetBackdrop,
} from '@gorhom/bottom-sheet';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedGestureHandler,
  useAnimatedStyle,
  withSpring,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import {PanGestureHandler} from 'react-native-gesture-handler';

import useWindowDimensions from '../../tools/hooks/useWindowDimensions';
import useKeyboard from '../../tools/hooks/useKeyboard';
import useAndroidSoftNavbarHeight from '../../tools/hooks/useAndroidNavbarHeight';
import colors from '../../assets/colors';
import {Icon} from '../../components';
import scale from '../../tools/scale';

const BottomSheet = ({
  visible,
  setVisible = () => null,
  onDismiss = null,
  children = null,
  automaticallyAdjustHeight = false,
  backdropComponent = null,
  enableHandle = true,
  panToDismiss = true,
  responsive = true,
  snapPoints: _snapPoints = ['25%', '50%'],
  defaultCloseIcon = false,
  index = 1,
  modalStyle = {},
}) => {
  const bottomSheetRef = useRef(null);
  const [contentHeight, setContentHeight] = React.useState(0);
  const {bottom: safeAreaBottom} = useSafeAreaInsets();

  const {window} = useWindowDimensions();

  const MAX_WIDTH = 600;
  const marginHorizontal =
    window.width > MAX_WIDTH ? (window.width - MAX_WIDTH) / 2 : 0;

  const snapPoints = useMemo(
    () => (automaticallyAdjustHeight ? [contentHeight] : _snapPoints),
    [contentHeight, automaticallyAdjustHeight, _snapPoints],
  );

  if (onDismiss === null) {
    onDismiss = () => {
      setVisible(false);
    };
  }

  const handleOnLayout = useCallback(
    ({
      nativeEvent: {
        layout: {height},
      },
    }) => {
      setContentHeight(height);
    },
    [],
  );

  React.useEffect(() => {
    if (visible) {
      bottomSheetRef.current?.present();
    } else {
      bottomSheetRef.current?.dismiss();
    }
  }, [visible]);

  const renderActualChildren = automaticallyAdjustHeight ? (
    <BottomSheetView onLayout={handleOnLayout}>{children}</BottomSheetView>
  ) : (
    children
  );

  const backPressed = React.useCallback(() => {
    bottomSheetRef.current?.dismiss();
    setVisible(false);
    return true;
  }, [setVisible]);

  React.useEffect(() => {
    if (visible) {
      BackHandler.addEventListener('hardwareBackPress', backPressed);
    } else {
      BackHandler.removeEventListener('hardwareBackPress', backPressed);
    }
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', backPressed);
    };
  }, [setVisible, visible, backPressed]);

  return (
    <BottomSheetModalProvider>
      {visible ? (
        <>
          <StatusBar barStyle="dark-content" backgroundColor={colors.grey} />
          <View style={{...styles.container, paddingBottom: safeAreaBottom}}>
            <BottomSheetModal
              style={[responsive ? {marginHorizontal} : {}, modalStyle]}
              name="bottomsheet"
              ref={bottomSheetRef}
              snapPoints={snapPoints}
              dismissOnPanDown
              onDismiss={onDismiss}
              enableContentPanningGesture={panToDismiss}
              keyboardBehavior="interactive"
              keyboardBlurBehavior="none"
              backdropComponent={props => (
                <BottomSheetBackdrop
                  {...props}
                  enableTouchThrough
                  pressBehavior="close"
                />
              )}
              {...(automaticallyAdjustHeight ? {} : {index})}
              {...(backdropComponent !== null ? {backdropComponent} : {})}
              {...(!enableHandle ? {handleComponent: null} : {})}
              enableHandlePanningGesture>
              {defaultCloseIcon ? (
                <Icon
                  name="plus"
                  tint={colors.black}
                  style={{
                    transform: [{rotate: '45deg'}],
                    position: 'absolute',
                    right: 20,
                    top: 0,
                    backgroundColor: colors.grey,
                  }}
                  size={20}
                  backTint={colors.grey}
                  onPress={() => setVisible(false)}
                  disableTapAnimation
                />
              ) : null}
              {renderActualChildren}
            </BottomSheetModal>
          </View>
        </>
      ) : null}
    </BottomSheetModalProvider>
  );
};

const SPRING_CONFIG = {
  damping: 200,
  overshootClamping: true,
  restDisplacementThreshold: 0.9,
  restSpeedThreshold: 0.9,
  stiffness: 450,
};

export function BottomSheetRaw({
  visible = false,
  setVisible = () => null,
  children = null,
  height = 500,
  style = {},
  disablePanGesture = true,
  closeSheetIcon = false,
  automaticallyAdjustHeight = false,
}) {
  const {
    screen: {height: screenHeight, width: screenWidth},
    window: {width: windowWidth},
  } = useWindowDimensions();

  const {hasInternetConnection} = true;

  const androidNavbarHeight = useAndroidSoftNavbarHeight();

  const [keyboardHeight] = useKeyboard();
  const actualHeight =
    screenHeight -
    scale.moderateScale(
      height + androidNavbarHeight + (hasInternetConnection ? 0 : 40),
      0.1,
    );
  const [contentHeight, setContentHeight] = React.useState(0);
  const {bottom: safeAreaBottom} = useSafeAreaInsets();

  const MAX_WIDTH = 600;
  const marginHorizontal =
    screenWidth > MAX_WIDTH ? (windowWidth - MAX_WIDTH) / 2 : 0;

  const childrenContainerRef = React.useRef();

  const top = useSharedValue(screenHeight);
  const animatedStyle = useAnimatedStyle(() => ({
    top: top.value,
  }));

  const overlayOpacity = useSharedValue(0);
  const overlayStyle = useAnimatedStyle(() => ({
    opacity: overlayOpacity.value,
  }));

  const touchY = useSharedValue(0);

  const timerId = React.useRef();
  const openedRef = React.useRef(false);

  const closeModal = React.useCallback(() => {
    top.value = withSpring(screenHeight, SPRING_CONFIG);
    overlayOpacity.value = withTiming(0);
    openedRef.current = false;
    touchY.value = 0;

    if (timerId.current) {
      clearTimeout(timerId.current);
    }
    timerId.current = setTimeout(() => {
      setVisible(false);
    }, 150);
  }, [overlayOpacity, screenHeight, setVisible, touchY, top]);

  const gestureHandler = useAnimatedGestureHandler({
    onStart(_, context) {
      context.startTop = top.value;
      context.lastTouchY = 0;
    },
    onActive: (event, context) => {
      const translationY = event.translationY;
      if (translationY > 0) {
        top.value = translationY + context.startTop;
        context.lastTouchY = translationY;
      }
    },
    onEnd: (_, context) => {
      const lastTouchY = context.lastTouchY;
      if (lastTouchY >= 0.4 * height) {
        runOnJS(closeModal)();
      } else {
        top.value = withSpring(actualHeight, SPRING_CONFIG);
      }
    },
  });
  const touchStyle = useAnimatedStyle(() => ({
    transform: [{translateY: touchY.value}],
  }));

  React.useEffect(() => {
    if (visible) {
      top.value = withSpring(actualHeight, SPRING_CONFIG);
      overlayOpacity.value = withTiming(0.5);
    } else {
      top.value = withSpring(screenHeight, SPRING_CONFIG);
    }
    return () => {
      clearTimeout(timerId.current);
    };
  }, [actualHeight, overlayOpacity, screenHeight, top, visible]);

  React.useEffect(() => {
    if (visible) {
      top.value = withSpring(actualHeight - keyboardHeight, SPRING_CONFIG);
    } else {
      closeModal();
    }
  }, [actualHeight, keyboardHeight, top, visible, closeModal]);

  const Container = React.useMemo(
    () =>
      disablePanGesture ? (
        <React.Fragment />
      ) : (
        <PanGestureHandler onGestureEvent={gestureHandler} />
      ),
    [disablePanGesture, gestureHandler],
  );

  const backPressed = React.useCallback(() => {
    closeModal();
    return true;
  }, [closeModal]);

  React.useEffect(() => {
    if (visible) {
      BackHandler.addEventListener('hardwareBackPress', backPressed);
    } else {
      BackHandler.removeEventListener('hardwareBackPress', backPressed);
    }
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', backPressed);
    };
  }, [setVisible, visible, backPressed]);

  return (
    <>
      {React.cloneElement(Container, {
        children: (
          <Animated.View
            onStartShouldSetResponder={() => true}
            style={[
              {
                position: 'absolute',
                bottom: 0,
                right: 0,
                left: 0,
                top: automaticallyAdjustHeight ? contentHeight : screenHeight,
                backgroundColor: 'white',
                borderTopRightRadius: 20,
                borderTopLeftRadius: 20,
                overflow: 'hidden',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.25,
                shadowRadius: 3.84,
                elevation: 5,
                zIndex: 100,
                marginHorizontal,
              },
              style,
              animatedStyle,
              touchStyle,
            ]}>
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : null}
              keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
              style={{flex: 1}}>
              {visible ? (
                <>
                  <StatusBar backgroundColor={colors.grey} />
                  {closeSheetIcon ? (
                    <View onStartShouldSetResponder={() => true}>
                      {
                        <Icon
                          name="plus"
                          tint={colors.white}
                          style={{
                            transform: [{rotate: '45deg'}],
                            position: 'absolute',
                            right: 20,
                            top: 20,
                          }}
                          size={25}
                          backTint={colors.grey}
                          onPress={closeModal}
                        />
                      }
                    </View>
                  ) : null}
                  <View
                    ref={childrenContainerRef}
                    style={{paddingBottom: safeAreaBottom}}>
                    {children}
                  </View>
                </>
              ) : null}
            </KeyboardAvoidingView>
          </Animated.View>
        ),
      })}
      {visible ? (
        <Animated.View
          style={[
            {
              backgroundColor: 'black',
              position: 'absolute',
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
            },
            overlayStyle,
          ]}>
          <Pressable
            onPress={closeModal}
            style={{
              width: '100%',
              height: '100%',
            }}
          />
        </Animated.View>
      ) : null}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'absolute',
    bottom: 0,
  },
});

export default BottomSheet;
