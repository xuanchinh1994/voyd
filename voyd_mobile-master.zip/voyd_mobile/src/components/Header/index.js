import React from 'react';
import {Text, View, Image} from 'react-native';

import colors from '../../assets/colors';
import styles from './styles.js';
import HeaderButton from './HeaderButton.js';
import Logo from '../../assets/images/logoCropped.jpg';
import responsive from '../../tools/scale';

export default function Header({
  title = '',
  backgroundColor = colors.white,
  borderColor = colors.white,
  left,
  right,
  iconStyle = {},
  noShadow = false,
  logo = false,
  renderRight = null,
}) {
  return (
    <View
      style={[
        {
          backgroundColor,
          borderColor,
          zIndex: 1,
          ...styles.containerWrapper,
        },
        !noShadow ? styles.shadow : {},
      ]}>
      <View
        style={{
          ...styles.container,
        }}>
        <HeaderButton
          action={left}
          style={styles.headerLeft}
          iconStyle={iconStyle}
        />
        <View style={styles.titleContainer}>
          {!logo ? (
            <Text style={styles.title}>{title}</Text>
          ) : (
            <Image
              source={Logo}
              style={{
                width: responsive.moderateScale(100, 0.1),
                height: responsive.moderateScale(65.7, 0.1),
                marginBottom: 10,
              }}
              resizeMode="contain"
            />
          )}
        </View>
        {renderRight === null ? (
          <HeaderButton
            action={right}
            style={styles.headerRight}
            iconStyle={iconStyle}
          />
        ) : (
          <View style={styles.headerRight}>{renderRight}</View>
        )}
      </View>
    </View>
  );
}
