import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  containerWrapper: {
    paddingHorizontal: 20,
    borderBottomWidth: 0.5,
  },
  container: {
    height: 50,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
  },
  titleContainer: {
    textAlign: 'center',
  },
  title: {
    fontSize: 17,
  },
  headerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    paddingLeft: 0,
  },
  headerLeft: {position: 'absolute', left: 0},
  headerRight: {position: 'absolute', right: 0},
  shadow: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
});
