import React from 'react';
import {Text, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';

import colors from '../../assets/colors';
import Icon from '../Icon';
import styles from './styles.js';

export default function HeaderButton({action, style = {}, iconStyle = {}}) {
  const navigation = useNavigation();
  let buttonConfig = {
    back: {
      icon: {
        name: 'chevron',
        tint: colors.primary,
        size: 18,
      },
      action: () => {
        if (navigation.canGoBack()) {
          navigation.goBack();
        }
      },
      suffix: '',
    },
  };

  let config;
  if (typeof action === 'string') {
    config = buttonConfig[action];
  } else {
    config = action;
  }
  return (
    <TouchableOpacity
      style={{
        ...styles.headerButton,
        ...style,
      }}
      onPress={config?.action || (() => null)}>
      <Text
        style={{
          color: config?.icon?.tint || 'black',
          fontSize: 18,
          ...config?.prefixStyle,
        }}>
        {config?.prefix}
      </Text>
      {!!config && !!config?.icon ? (
        <Icon
          {...config?.icon}
          style={
            config?.icon?.name === 'chevron'
              ? {...iconStyle, transform: [{rotate: '180deg'}]}
              : iconStyle
          }
        />
      ) : null}
      {!!config?.render ? config.render() : null}
      <Text
        style={{
          color: config?.icon?.tint || 'black',
          fontSize: 18,
          ...config?.suffixStyle,
        }}>
        {config?.suffix}
      </Text>
    </TouchableOpacity>
  );
}
