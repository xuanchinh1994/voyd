import React from 'react';
import {useNavigation} from '@react-navigation/native';

import checkPermission from '../../tools/permissions';

export default (WrappedComponent, willStay = true, requireAlert = true) =>
  props => {
    const [granted, setGranted] = React.useState(false);
    const navigation = useNavigation();

    React.useEffect(() => {
      checkPermission(
        'calendar',
        setGranted,
        willStay,
        requireAlert,
        true,
        navigation,
      );
    }, [navigation, setGranted]);

    return (
      <WrappedComponent
        {...props}
        calendarPermissionGranted={granted}
        setCalendarPermissionGranted={setGranted}
      />
    );
  };
