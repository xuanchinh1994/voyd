import React from 'react';
import {Modal, View, Image, StyleSheet, Text} from 'react-native';

import colors from '../../assets/colors';
import Icon from '../Icon';
import Button from '../Button';
import Logo from '../../assets/images/logo.jpg';
import locale from '../../assets/locale.json';
import useAppDetails from '../../tools/hooks/useAppDetails';
import {openLink} from '../../tools/utils';

export default WrappedComponent => props => {
  const {appStoreUrl, appVersion, appVersionFromServer} = useAppDetails();

  const shouldUpdateApp = appVersion !== appVersionFromServer;

  const handleUpdateButtonPress = React.useCallback(() => {
    try {
      openLink(appStoreUrl);
    } catch (error) {}
  }, [appStoreUrl]);
  return (
    <>
      <WrappedComponent {...props} />
      {shouldUpdateApp ? (
        <Modal>
          <View
            style={{
              backgroundColor: colors.white,
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image source={Logo} style={styles.logo} resizeMode="contain" />
            <Icon size={60} name="update" />
            <Text style={styles.title}>
              {locale.PleaseUpdateTheAppToContinue}
            </Text>
            <Button text={locale.Update} onPress={handleUpdateButtonPress} />
          </View>
        </Modal>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  logo: {
    width: 200,
    height: 67.4,
    marginBottom: 30,
  },
  title: {
    fontSize: 16,
    marginVertical: 30,
  },
});
