import React from 'react';
import {View, StyleSheet} from 'react-native';

import Button from '../Button';
import locale from '../../assets/locale.json';
import InfoModal from '../Modal/InfoModal';
import {RESEND_VERIFICATION_LINK} from '../../tools/api';
import {showToast, hideToast} from '../Toast';

export default WrappedComponent => props => {
  const [alertVisible, setAlertVisible] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [email, setEmail] = React.useState(null);

  const handleResendVerificationLink = React.useCallback(async () => {
    if (!email) {
      throw new Error('Email is required');
    }
    hideToast();
    setLoading(true);
    try {
      const {data} = await RESEND_VERIFICATION_LINK({email});
      const success = data?.success;
      const message = data?.message;
      showToast({
        type: success ? 'success' : 'error',
        message: success
          ? locale.AVerificationLinkIsSentToYourInbox
          : message || locale.SomethingWentWrongTryAgain,
      });
      if (success) {
        setAlertVisible(false);
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
    } finally {
      setLoading(false);
    }
  }, [email]);

  const showAccountNotVerifiedAlert = email => {
    setEmail(email);
    setAlertVisible(true);
  };

  const handleDismiss = () => {
    setEmail(null);
    setAlertVisible(false);
  };

  return (
    <>
      <WrappedComponent
        {...props}
        showAccountNotVerifiedAlert={showAccountNotVerifiedAlert}
      />
      {alertVisible ? (
        <InfoModal
          popUp={{
            state: alertVisible,
            data: {
              title: locale.AccountNotVerified,
              description: locale.YouNeedToVerifyYourAccountToContinue,
            },
          }}
          setVisible={() => {
            setAlertVisible(false);
          }}
          acceptText={false}
          height={200}>
          <View style={styles.buttonsContainer}>
            <Button
              text={locale.ResendLink}
              onPress={handleResendVerificationLink.bind(this, email)}
              loading={loading}
              disabled={loading}
              style={styles.resendButton}
            />
            <Button
              text={locale.OK}
              style={styles.OKButton}
              onPress={handleDismiss}
            />
          </View>
        </InfoModal>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  buttonsContainer: {
    flexDirection: 'row',
  },
  OKButton: {minWidth: 100, marginLeft: 10},
  resendButton: {minWidth: 100},
});
