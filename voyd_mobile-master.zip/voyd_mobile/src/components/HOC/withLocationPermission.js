import React from 'react';
import {Platform} from 'react-native';
import {PERMISSIONS, request, RESULTS} from 'react-native-permissions';
import LocationServicesDialogBox from 'react-native-android-location-services-dialog-box';

import locale from '../../assets/locale.json';
import permissionAlert from '../../tools/openAppSettingAlert';

const withGeolocationPermission =
  (
    WrappedComponent,
    willStayOnPermissionDenied = false,
    requirePermissionAlert = true,
    skip = false,
  ) =>
  props => {
    const [granted, setGranted] = React.useState(false);

    const requestLocationPermission = React.useCallback(
      (_requirePermissionAlert = true) => {
        try {
          request(
            Platform.OS === 'android'
              ? PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION
              : PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
          ).then(res => {
            if (res === RESULTS.GRANTED) {
              if (Platform.OS === 'android') {
                LocationServicesDialogBox.checkLocationServicesIsEnabled({
                  message: `<h4>${locale.locationServiceIsRequired} </h4>${locale.appWantsToEnableLocation}<br/>`,
                  ok: locale.allow,
                  cancel: locale.deny,
                  enableHighAccuracy: true,
                  showDialog: true,
                  openLocationServices: true,
                  preventOutSideTouch: true,
                  preventBackClick: true,
                  providerListener: false,
                })
                  .then(_ => {
                    setGranted(true);
                  })
                  .catch(_ => {
                    setGranted(false);
                  });
              } else {
                setGranted(true);
              }
            } else {
              _requirePermissionAlert &&
                permissionAlert(
                  locale.locationPermissionIsRequired,
                  locale.locationPermissionSteps,
                  props,
                  willStayOnPermissionDenied,
                );
            }
          });
        } catch (err) {
          console.warn(err);
        }
      },
      [props],
    );

    React.useEffect(() => {
      if (!skip) {
        requestLocationPermission(requirePermissionAlert);
      }
    }, [props, requestLocationPermission]);

    return (
      <WrappedComponent
        {...props}
        locationEnabled={granted}
        requestLocationPermission={requestLocationPermission}
      />
    );
  };

export default withGeolocationPermission;
