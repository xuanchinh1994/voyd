import React from 'react';

import {screens} from '../../assets/strings';
import {
  useNavigation,
  useFocusEffect,
  useRoute,
} from '@react-navigation/native';

function ScanQRCode({
  children = null,
  fromScreen = '',
  onSuccess = () => null,
}) {
  const navigation = useNavigation();
  const route = useRoute();
  const qrCode = route?.params?.qrCode;

  const successRef = React.useRef(false);

  useFocusEffect(
    React.useCallback(() => {
      if (qrCode?.length && !successRef.current) {
        successRef.current = true;
        onSuccess(qrCode);
      }
    }, [onSuccess, qrCode]),
  );

  const handleQRCodeScan = React.useCallback(() => {
    successRef.current = false;
    navigation.setParams({qrCode: null});
    navigation.navigate(screens.SCAN, {
      fromScreen: fromScreen,
    });
  }, [navigation, fromScreen]);

  return children({handleQRCodeScan});
}

export default ScanQRCode;
