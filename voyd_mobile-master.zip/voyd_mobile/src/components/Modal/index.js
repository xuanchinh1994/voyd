import React from 'react';
import {View, Modal, TouchableOpacity, StyleSheet} from 'react-native';
import {BlurView} from '@react-native-community/blur';

import styles from './styles';

export default function CommonModal({
  children,
  visible = false,
  setVisible = () => null,
  height = 350,
  width = 320,
  blurBackground = true,
}) {
  return (
    <Modal
      transparent
      animationType="fade"
      visible={visible}
      onRequestClose={() => {
        setVisible(false);
      }}>
      <TouchableOpacity
        activeOpacity={1}
        style={{flex: 1}}
        onPress={() => {
          setVisible(false);
        }}>
        {blurBackground && (
          <BlurView
            blurType="dark"
            blurAmount={1}
            reducedTransparencyFallbackColor="white"
            style={StyleSheet.absoluteFillObject}
          />
        )}
        <View
          onStartShouldSetResponder={() => false}
          style={styles.modalContainer}>
          <View
            style={{
              ...styles.modal,
              minHeight: height,
              width: width,
            }}>
            {children}
          </View>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}
