import React from 'react';
import {View, TouchableOpacity, Text, StyleSheet} from 'react-native';

import locale from '../../assets/locale.json';
import CommonModal from './index';
import colors from '../../assets/colors';

export default function InfoModal({
  children,
  popUp,
  setVisible,
  acceptText = true,
  height,
  width,
  blurBackground = true,
}) {
  return (
    <CommonModal
      visible={popUp.state}
      setVisible={setVisible}
      height={height}
      width={width}
      blurBackground={blurBackground}>
      <View style={{marginTop: 10}}>
        <Text style={styles.title}>{popUp?.data?.title}</Text>
        {popUp?.data?.description ? (
          <Text
            style={{
              ...styles.subtitle,
            }}>
            {popUp.data.description}
          </Text>
        ) : null}
      </View>

      {acceptText ? (
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={setVisible}>
            <Text style={styles.buttonText}>{locale.ok}</Text>
          </TouchableOpacity>
        </View>
      ) : null}
      {children}
    </CommonModal>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    textAlign: 'center',
    marginVertical: 20,
  },
  buttonContainer: {flexGrow: 1, justifyContent: 'flex-end'},
  button: {
    width: 150,
    minHeight: 50,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
  },
  buttonText: {
    color: colors.white,
    fontSize: 18,
  },
});
