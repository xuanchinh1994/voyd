import { StyleSheet } from 'react-native'
import colors from '../../assets/colors'

export default StyleSheet.create({
  modalContainer: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    bottom: 0,
    left: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    backgroundColor: colors.almostWhite,
    borderRadius: 20,
    alignItems: 'center',
    padding: 30,
  },
})
