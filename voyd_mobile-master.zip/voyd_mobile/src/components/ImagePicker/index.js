import React from 'react';
import {Text, StyleSheet, TouchableOpacity, View} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import ImagePicker from 'react-native-image-crop-picker';

import locale from '../../assets/locale.json';
import colors from '../../assets/colors';
import checkPermission from '../../tools/permissions';
import {withStoragePermission, withCameraPermission} from '../HOC';
import CommonModal from '../Modal/';
import Icon from '../Icon';

const PickImageDialog = ({
  visible,
  setVisible,
  onImageSelected,
  storagePermission,
  setStoragePermission,
  cameraPermission,
  setCameraPermission,
}) => {
  const navigation = useNavigation();
  const hide = () => {
    setVisible(false);
  };

  const selectFromAlbum = () => {
    storagePermission
      ? ImagePicker.openPicker({
          mediaType: 'any',
        })
          .then(image => {
            onImageSelected(image);
            hide();
          })
          .catch(error => console.log('Canceled by user', error))
      : checkPermission(
          'storage',
          setStoragePermission,
          {
            navigation,
          },
          true,
          true,
          false,
        );
  };

  const selectFromCamera = () => {
    cameraPermission
      ? !storagePermission
        ? checkPermission(
            'storage',
            setStoragePermission,
            {
              navigation,
            },
            true,
            true,
            false,
          )
        : ImagePicker.openCamera({
            mediaType: 'any',
          })
            .then(image => {
              onImageSelected(image);
              hide();
            })
            .catch(error => console.log('Canceled by user'))
      : checkPermission(
          'camera',
          setCameraPermission,
          {
            navigation,
          },
          true,
          true,
          false,
        );
  };

  return (
    <CommonModal visible={visible} setVisible={setVisible} height={100}>
      <Text style={{...styles.itemText, fontSize: 18}}>
        {locale.selectFrom}...
      </Text>
      <View style={styles.iconContainer}>
        <TouchableOpacity style={styles.dialogLink} onPress={selectFromCamera}>
          <Icon name="camera" tint={colors.black} size={40} />
          <Text style={styles.itemText}>{locale.camera}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dialogLink} onPress={selectFromAlbum}>
          <Icon name="gallery" tint={colors.black} size={40} />
          <Text style={styles.itemText}>{locale.gallery}</Text>
        </TouchableOpacity>
      </View>
    </CommonModal>
  );
};

const styles = StyleSheet.create({
  dialogTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  dialogLink: {
    paddingVertical: 20,
    alignItems: 'center',
  },
  itemText: {fontSize: 15, fontWeight: 'bold'},
  iconContainer: {
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    width: '100%',
    marginTop: 20,
  },
});

export default withCameraPermission(
  withStoragePermission(PickImageDialog, true, false),
  true,
  false,
  true,
);
