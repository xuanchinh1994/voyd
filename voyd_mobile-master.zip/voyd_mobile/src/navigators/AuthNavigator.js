import React from 'react';
import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';

import {screens} from '../assets/strings';

import {
  Login,
  Register,
  ForgotPassword,
  ValidateCode,
  ResetPassword,
  Scan,
} from '../screens';

const Stack = createStackNavigator();

const AuthNavigator = () => {
  return (
    <Stack.Navigator headerMode="none">
      <Stack.Screen name={screens.LOGIN} component={Login} />
      <Stack.Screen name={screens.REGISTER} component={Register} />
      <Stack.Screen name={screens.FORGOT_PASSWORD} component={ForgotPassword} />
      <Stack.Screen name={screens.VALIDATE_CODE} component={ValidateCode} />
      <Stack.Screen name={screens.RESET_PASSWORD} component={ResetPassword} />
      <Stack.Screen
        name={screens.SCAN}
        component={Scan}
        options={{
          gestureEnabled: false,
          ...TransitionPresets.ModalSlideFromBottomIOS,
        }}
      />
    </Stack.Navigator>
  );
};

export default AuthNavigator;
