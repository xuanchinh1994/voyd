import React from 'react';
import {StatusBar} from 'react-native';

import AuthNavigator from './AuthNavigator.js';
import UserNavigator from './UserNavigator.js';
import colors from '../assets/colors';
import useUser from '../tools/hooks/useUser';

const AppNavigator = () => {
  const [user] = useUser();

  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor={colors.white} />
      {user !== null ? <UserNavigator /> : <AuthNavigator />}
    </>
  );
};

export default AppNavigator;
