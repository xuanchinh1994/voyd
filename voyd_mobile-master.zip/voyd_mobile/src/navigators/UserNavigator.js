import React from 'react';
import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';

import {screens} from '../assets/strings';
import {
  Profile,
  LinkScreen,
  NotesScreen,
  SettingsScreen,
  ImagesScreen,
  CalendarScreen,
  CreateNote,
  ChangePassword,
  Scan,
  ForceLogout,
  ConnectionSteps,
} from '../screens';
import DrawerNavigator from './DrawerNavigator';

const Stack = createStackNavigator();

function StackNavigator() {
  return (
    <Stack.Navigator headerMode="none">
      <Stack.Screen name={screens.MAIN} component={DrawerNavigator} />
      <Stack.Screen
        name={screens.LINK_SCREEN}
        component={LinkScreen}
        options={{
          unmountOnBlur: true,
        }}
      />
      <Stack.Screen name={screens.NOTES} component={NotesScreen} />
      <Stack.Screen
        name={screens.SETTINGS}
        component={SettingsScreen}
        options={{
          unmountOnBlur: true,
        }}
      />
      <Stack.Screen name={screens.IMAGES} component={ImagesScreen} />
      <Stack.Screen name={screens.CALENDAR} component={CalendarScreen} />

      <Stack.Screen
        name={screens.PROFILE}
        component={Profile}
        options={{
          unmountOnBlur: true,
        }}
      />
      <Stack.Screen
        name={screens.CREATE_NOTE}
        component={CreateNote}
        options={{
          unmountOnBlur: true,
        }}
      />

      <Stack.Screen
        name={screens.CHANGE_PASSWORD}
        component={ChangePassword}
        options={{
          unmountOnBlur: true,
        }}
      />
      <Stack.Screen
        name={screens.SCAN}
        component={Scan}
        options={{
          gestureEnabled: false,
          unmountOnBlur: true,
          ...TransitionPresets.ModalSlideFromBottomIOS,
        }}
      />
      <Stack.Screen
        name={screens.FORCE_LOGOUT}
        component={ForceLogout}
        options={{
          gestureEnabled: false,
          unmountOnBlur: true,
          ...TransitionPresets.ModalSlideFromBottomIOS,
        }}
      />
      <Stack.Screen
        name={screens.CONNECTION_STEPS}
        component={ConnectionSteps}
      />
    </Stack.Navigator>
  );
}

export default StackNavigator;
