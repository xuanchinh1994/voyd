import React from 'react';
import {View} from 'react-native';
import {
  DrawerContentScrollView,
  DrawerItem,
  createDrawerNavigator,
} from '@react-navigation/drawer';
import {Drawer} from 'react-native-paper';

import Icon from '../components/Icon';
import {screens} from '../assets/strings';
import useLogout from '../tools/hooks/useLogout';
import colors from '../assets/colors';
import locale from '../assets/locale.json';
import Home from '../screens/Home';

const DrawerNavigator = createDrawerNavigator();

const DrawerItems = props => {
  const {logout} = useLogout();

  return (
    <View style={{flex: 1}}>
      <DrawerContentScrollView {...props}>
        <Drawer.Section>
          <DrawerItem
            label={locale.Link}
            icon={({size, color}) => (
              <Icon name={'link'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.LINK_SCREEN)}
          />

          <DrawerItem
            label={locale.Notes}
            icon={({size, color}) => (
              <Icon name={'notes'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.NOTES)}
          />

          <DrawerItem
            label={locale.Image}
            icon={({size, color}) => (
              <Icon name={'image'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.IMAGES)}
          />

          <DrawerItem
            label={locale.Calendar}
            icon={({size, color}) => (
              <Icon name={'calendar'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.CALENDAR)}
          />
          <DrawerItem
            label={locale.ConnectionSteps}
            icon={({size, color}) => (
              <Icon name={'gear'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.CONNECTION_STEPS)}
          />
          <DrawerItem
            label={locale.Profile}
            icon={({size, color}) => (
              <Icon name={'user'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.PROFILE)}
          />

          <DrawerItem
            label={locale.Settings}
            icon={({size, color}) => (
              <Icon name={'gear'} size={size} tint={color} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={() => props.navigation.navigate(screens.SETTINGS)}
          />

          <DrawerItem
            label={locale.LogOut}
            icon={({size}) => (
              <Icon name="logout" size={size} tint={colors.black} />
            )}
            labelStyle={{fontWeight: '700', fontSize: 16}}
            onPress={logout}
          />
        </Drawer.Section>
      </DrawerContentScrollView>
    </View>
  );
};

function DrawerNavigatorContainer() {
  return (
    <DrawerNavigator.Navigator
      drawerContent={props => <DrawerItems {...props} />}
      screenOptions={{
        gestureEnabled: true,
      }}>
      <DrawerNavigator.Screen name={screens.HOME} component={Home} />
    </DrawerNavigator.Navigator>
  );
}

export default DrawerNavigatorContainer;
