import React from 'react';
import {getVersion} from 'react-native-device-info';

import {GET_APP_DETAILS} from '../api';

const APP_DETAILS_INITIAL_DATA = {
  appVersion: getVersion(),
  appVersionFromServer: getVersion(), // appVersion === appVersionFromServer should always be true at first
  appStoreUrl: null,
  loading: false,
};

function useAuthUser() {
  const [appData, setAppData] = React.useState(APP_DETAILS_INITIAL_DATA);

  React.useEffect(() => {
    (async function () {
      setAppData(previousData => ({
        ...previousData,
        loading: true,
      }));
      try {
        const {data} = await GET_APP_DETAILS();
        const appVersionFromServer = data?.appVersion;
        const appStoreUrl = data?.appStoreUrl;

        setAppData(previousData => ({
          ...previousData,
          appVersionFromServer,
          appStoreUrl,
        }));
      } catch (_) {
      } finally {
        setAppData(previousData => ({
          ...previousData,
          loading: false,
        }));
      }
    })();
  }, []);

  return appData;
}

export default useAuthUser;
