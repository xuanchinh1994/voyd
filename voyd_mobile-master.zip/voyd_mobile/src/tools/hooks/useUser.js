import React from 'react';
import {useSelector} from 'react-redux';
import {useQuery} from '@apollo/react-hooks';

import {GET_USER} from '../../apollo/queries';

function useAuthUser() {
  const user = useSelector(state => state?.auth?.user);

  return [user];
}

const useUserDefaultOptions = {focused: false};
export function useUser(options = useUserDefaultOptions) {
  const {focused} = {...useUserDefaultOptions, ...options};
  const {data, refetch, loading, error} = useQuery(GET_USER, {
    fetchPolicy: 'no-cache',
  });

  console.log(JSON.stringify({error}, null, 2));

  React.useEffect(() => {
    if (focused) {
      refetch?.();
    }
  }, [focused, refetch]);

  return {
    data: data?.user?.data,
    refetch,
    loading,
    error,
  };
}

export default useAuthUser;
