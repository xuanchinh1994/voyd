import React from 'react';
import {Platform} from 'react-native';
import {useDispatch} from 'react-redux';
import AsyncStorage from '@react-native-community/async-storage';

import {logout} from '../../redux/actions/auth';
import {hideToast, showToast} from '../../components/Toast';
import client from '../../apollo/index';
import locale from '../../assets/locale.json';

const OPTIONS = {onError: () => null};

export default function useLogout(options = OPTIONS) {
  const {onError} = {...OPTIONS, ...options};
  const [isLogoutLoading, setIsLogOutLoading] = React.useState(false);

  const dispatch = useDispatch();

  const handleLogout = React.useCallback(async () => {
    setIsLogOutLoading(true);
    hideToast();
    try {
      const asyncStorageKeys = await AsyncStorage.getAllKeys();
      if (asyncStorageKeys.length > 0) {
        if (Platform.OS === 'android') {
          await AsyncStorage.clear();
        }
        if (Platform.OS === 'ios') {
          await AsyncStorage.multiRemove(asyncStorageKeys);
        }
      }
      await client.cache.reset();
      dispatch(logout());
    } catch (error) {
      onError?.();
      showToast({message: locale.CouldNotLogoutAtTheMoment});
    } finally {
      setIsLogOutLoading(false);
    }
  }, [dispatch, onError]);

  return {logout: handleLogout, isLogoutLoading, setIsLogOutLoading};
}
