import {useState, useEffect} from 'react';
import Geolocation from 'react-native-get-location';
import Geocoder from 'react-native-geocoder';

const useGeolocation = (locationEnabled = true) => {
  const [currentLocation, setCurrentLocation] = useState({
    longitude: null,
    latitude: null,
    address: null,
    loading: false,
    success: false,
  });

  useEffect(() => {
    (async function () {
      try {
        if (locationEnabled) {
          setCurrentLocation({
            loading: true,
          });
          const location = await Geolocation.getCurrentPosition({
            enableHighAccuracy: true,
          });
          const lat = location?.latitude;
          const lng = location?.longitude;
          setCurrentLocation(previousState => ({
            ...previousState,
            latitude: lat,
            longitude: lng,
          }));
          const position = await Geocoder.geocodePosition({
            lat,
            lng,
          });
          const actualPosition = position?.[0];
          const locality = actualPosition?.locality;
          const adminArea = actualPosition?.adminArea;
          const country = actualPosition?.country;

          setCurrentLocation(previousState => ({
            ...previousState,
            address: [locality || '']?.filter(item => item?.length)?.join(', '),
          }));
        }
      } catch (error) {
      } finally {
        setCurrentLocation(previousState => ({
          ...previousState,
          loading: false,
        }));
      }
    })();
  }, [locationEnabled]);

  return {currentLocation, loading: currentLocation.loading};
};

export default useGeolocation;
