import {ReactNativeFile} from 'apollo-upload-client';
import {useMutation} from '@apollo/react-hooks';

import {UPLOAD_FILE} from '../../apollo/mutations';

const useImageUpload = () => {
  const [uploadFile, {loading, data}] = useMutation(UPLOAD_FILE);

  const upload = image =>
    new Promise(async (resolve, reject) => {
      {
        const date = new Date();
        const nameComponents = [
          date.getFullYear(),
          date.getMonth(),
          date.getDate(),
          date.getHours(),
          date.getMinutes(),
          date.getSeconds(),
          date.getMilliseconds(),
          Math.floor(Math.random() * 1000),
          image.filename,
        ];

        try {
          const file = new ReactNativeFile({
            uri: image.path,
            name: nameComponents.join(''),
            type: image.mime,
          });

          const {data} = await uploadFile({
            variables: {file},
          });
          const success = data?.uploadFile?.success;
          const imageData = data?.uploadFile?.data;
          const message = data?.uploadFile?.message;

          if (success) {
            resolve(imageData);
          } else {
            reject(message);
          }
        } catch (error) {
          reject(error);
        }
      }
    });
  return {
    uploading: loading,
    upload,
    data,
  };
};

export default useImageUpload;
