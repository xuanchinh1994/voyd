import React, {useEffect, useState} from 'react';
import {Keyboard} from 'react-native';

const useKeyboardVisible = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const didShowListener = Keyboard.addListener('keyboardDidShow', () => {
      setIsVisible(true);
    });

    const didHideListener = Keyboard.addListener('keyboardDidHide', () => {
      setIsVisible(false);
    });

    return () => {
      didShowListener?.remove();
      didHideListener?.remove();
    };
  }, []);

  return isVisible;
};

export default useKeyboardVisible;
