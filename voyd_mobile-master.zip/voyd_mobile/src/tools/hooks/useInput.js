import React from 'react';

import colors from '../../assets/colors';

export default (inputArray = [], invalidity, initialValueKeyValuePair = {}) => {
  const reduceItems = (array = [], initialValue = '') => {
    return array.reduce((accumulator, currVal) => {
      accumulator[currVal] = initialValue;
      return accumulator;
    }, {});
  };

  // State for storing input values
  const [values, setValues] = React.useState(() => {
    return inputArray.reduce((accumulator, currVal) => {
      accumulator[currVal] =
        initialValueKeyValuePair != {}
          ? !!initialValueKeyValuePair[currVal]
            ? initialValueKeyValuePair[currVal]
            : ``
          : ``;
      return accumulator;
    }, {});
  });

  // Create state for checking invalidity in forms
  let invalidItems;
  if (!invalidity) {
    invalidItems = reduceItems(inputArray, false);
  } else {
    if (!Array.isArray(invalidity)) {
      throw new Error('Pass an array of items for invalidity check');
    } else if (!invalidity.every(item => typeof item === 'string')) {
      throw new Error('Array items must be string');
    }
    invalidItems = reduceItems(invalidity, false);
  }
  const [invalid, setInvalid] = React.useState(() => invalidItems);

  const handleChange = React.useCallback(
    (name, value) => {
      setValues({...values, [name]: value});
    },
    [setValues, values],
  );

  // Check if which input are empty
  const checkIsEmpty = React.useMemo(() => {
    let empty = {};
    for (let [key, value] of Object.entries(values)) {
      empty[key] = value === '';
    }
    let isEmpty = Object.values(empty).some(item => item);
    return [empty, isEmpty];
  }, [values]);

  // Show Invalid
  // Pass an array of key value pair for values state name and ref :{email:emailRef}
  const showInvalidOnEmpty = React.useCallback(
    (
      elementRefKeyValuePair,
      normalColor = colors.grey,
      invalidColor = colors.red,
      allBorder = true,
    ) => {
      if (!elementRefKeyValuePair) {
        throw new Error(
          'Pass key-value pair of ref for specific input container',
        );
      }
      for (let [name, ref] of Object.entries(elementRefKeyValuePair)) {
        if (!!ref.current?.setNativeProps) {
          ref.current.setNativeProps({
            style: allBorder
              ? {
                  borderColor: values[name] === '' ? invalidColor : normalColor,
                }
              : {
                  borderBottomColor:
                    values[name] === '' ? invalidColor : normalColor,
                },
          });
        }
      }
    },
    [values],
  );

  // Show invalid for invalid states
  // Pass an array of key value pair for invalid state name and ref :{email:emailRef}

  const showInvalid = React.useCallback(
    (
      elementRefKeyValuePair,
      normalColor = colors.grey,
      invalidColor = colors.red,
      allBorder = true,
    ) => {
      if (!elementRefKeyValuePair) {
        throw new Error(
          'Pass key-value pair of ref for specific input container',
        );
      }
      for (let [name, ref] of Object.entries(elementRefKeyValuePair)) {
        if (!!ref.current?.setNativeProps) {
          ref.current.setNativeProps({
            style: allBorder
              ? {
                  borderColor: invalid[name] ? invalidColor : normalColor,
                }
              : {
                  borderBottomColor: invalid[name] ? invalidColor : normalColor,
                },
          });
        }
      }
    },
    [invalid],
  );

  // Show invalid for specific input
  const showInvalidForSpecific = React.useCallback(
    (elementRef, color = colors.red, allBorder = true) => {
      if (!elementRef) {
        throw new Error('Pass ref for specific input container');
      }

      if (!!elementRef.current?.setNativeProps) {
        elementRef.current.setNativeProps({
          style: allBorder
            ? {
                borderColor: color,
              }
            : {
                borderBottomColor: color,
              },
        });
      }
    },
    [],
  );

  return {
    values,
    setValues,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
    showInvalid,
  };
};
