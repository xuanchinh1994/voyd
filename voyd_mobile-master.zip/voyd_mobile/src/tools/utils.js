import {Linking} from 'react-native';
import {API_URL, API_URL_DEV} from '@env';

const URL = process.env.NODE_ENV === 'development' ? API_URL_DEV : API_URL;
const DOMAIN = URL?.endsWith('/') ? URL : `${URL}/`;

export const validateEmail = email => {
  const re =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  const reStartAndEnd = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}/g;

  if (re.test(email) && reStartAndEnd.test(email)) {
    return true;
  }
  return false;
};

export const DateUtilities = {
  getDateToday: {
    iso: {
      start: () => new Date(new Date().setHours(0, 0, 0, 0)).toISOString(),
      now: () => new Date().toISOString(),
      end: () => new Date(new Date().setHours(23, 59, 59, 999)).toISOString(),
    },
    local: {
      start: () =>
        new Date(
          new Date(new Date().setHours(0, 0, 0, 0)).toString().split('GMT')[0] +
            ' UTC',
        ).toISOString(),
      now: () =>
        new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString(),
      end: () =>
        new Date(
          new Date(new Date().setHours(23, 59, 59, 999))
            .toString()
            .split('GMT')[0] + ' UTC',
        ).toISOString(),
    },
  },
  format_AM_PM: date => {
    if (new Date(date) === 'Invalid Date') {
      return '';
    }
    date = new Date(date);
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'pm' : 'am';

    hours %= 12;
    hours = hours || 12;
    minutes = minutes < 10 ? `0${minutes}` : minutes;

    const strTime = `${hours}:${minutes} ${ampm}`;

    return strTime;
  },
  getMonth: date => {
    if (new Date(date) === 'Invalid Date') {
      return '';
    }
    const months = [
      'Jan',
      'Feb',
      'March',
      'April',
      'May',
      'June',
      'July',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[new Date(date)?.getMonth()];
  },
};

export const URLUtilities = {
  validateUrl(userInput) {
    var res = userInput.match(
      /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g,
    );
    if (res == null) return false;
    else return true;
  },
  getDomain: () => DOMAIN,
  mergeWithDomain: url =>
    `${DOMAIN}${url?.startsWith('/') ? url?.slice(1) : url}`,
};

export const openLink = (link, type) => {
  switch (type) {
    case 'phone':
      return Linking.openURL(`tel:${link}`);
    case 'map':
      return Linking.openURL(`geo:${link.latitude}, ${link.longitude}`);
    default:
      if (!link.startsWith('https://')) {
        link = 'https://' + link;
      }
      return Linking.openURL(link);
  }
};
