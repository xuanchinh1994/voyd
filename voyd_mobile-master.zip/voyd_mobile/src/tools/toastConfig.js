import React from 'react';
import Toast, {BaseToast} from 'react-native-toast-message';

export default {
  error: ({text1, props, ...rest}) => (
    <BaseToast
      {...rest}
      style={{borderLeftColor: 'tomato'}}
      contentContainerStyle={{paddingHorizontal: 15}}
      text1Style={{
        fontSize: 14,
        fontWeight: '400',
      }}
      text1={text1}
      text1NumberOfLines={2}
      onTrailingIconPress={() => Toast.hide()}
    />
  ),
  success: ({text1, props, ...rest}) => (
    <BaseToast
      {...rest}
      style={{borderLeftColor: 'green'}}
      contentContainerStyle={{paddingHorizontal: 15}}
      text1Style={{
        fontSize: 14,
        fontWeight: '400',
      }}
      text1={text1}
      text1NumberOfLines={2}
      onTrailingIconPress={() => Toast.hide()}
    />
  ),
};
