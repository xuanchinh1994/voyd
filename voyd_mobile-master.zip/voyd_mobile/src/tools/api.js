import axios from './axiosConfig';

import {apiEndPoint} from '../assets/strings';

export function LOGIN(data) {
  return axios({
    url: apiEndPoint.LOGIN,
    method: 'POST',
    data,
  });
}

export function SIGNUP(data) {
  return axios({
    url: apiEndPoint.SIGNUP,
    method: 'POST',
    data,
  });
}

export function FORGOT_PASSWORD(data) {
  return axios({
    url: apiEndPoint.FORGOT,
    method: 'POST',
    data,
  });
}

export function CONFIRM_RESET_PIN(data) {
  return axios({
    url: apiEndPoint.VALIDATE_CODE,
    method: 'POST',
    data,
  });
}

export function RESET_PASSWORD(data) {
  return axios({
    url: apiEndPoint.RESET_PASSWORD,
    method: 'POST',
    data,
  });
}
export function CHANGE_PASSWORD(data) {
  return axios({
    url: apiEndPoint.CHANGE_PASSWORD,
    method: 'POST',
    data,
  });
}

export function UPDATE_PROFILE(data) {
  return axios({
    url: apiEndPoint.UPDATE_PROFILE,
    method: 'POST',
    data,
  });
}

export function GET_CITIES() {
  return axios({
    url: apiEndPoint.CITIES,
    method: 'GET',
  });
}

export function GET_APP_DETAILS() {
  return axios({
    url: apiEndPoint.MOBILE_APP_DETAILS,
    method: 'GET',
  });
}

export function GET_TIMEZONES() {
  return axios({
    url: apiEndPoint.TIMEZONES,
    method: 'GET',
  });
}

export function REFRESH_TOKEN(data) {
  return axios({
    url: apiEndPoint.REFRESH_TOKEN,
    method: 'POST',
    data: {
      refresh_token: data,
    },
  });
}

export function RESEND_VERIFICATION_LINK(data) {
  return axios({
    url: apiEndPoint.RESEND_VERIFICATION_LINK,
    method: 'POST',
    data,
  });
}
