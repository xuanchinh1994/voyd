export default {
  primary: '#000000',
  white: '#FFFFFF',
  almostWhite: '#F2F2F2',
  black: '#000000',
  darkGrey: '#e8e8e8',
  lightGrey: '#ededed',
  grey: '#C7C7C7',
  warning: '#f00',
  green: '#40D37B',
  orange: '#FDBF5A',
  red: '#FF0000',
};
