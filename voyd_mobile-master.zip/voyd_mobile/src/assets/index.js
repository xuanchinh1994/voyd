export {default as colors} from './colors.js';
export {default as locale} from './locale.json';
export {default as strings} from './strings.js';
