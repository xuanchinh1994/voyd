import React from 'react';
import {Text, TextInput, View} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {useDispatch} from 'react-redux';

import {screens} from '../../assets/strings';
import {Button} from '../../components';
import useInput from '../../tools/hooks/useInput';
import RegisterVM from './VM';
import styles from './styles';
import {UPDATE_PROFILE} from '../../tools/api';
import {updateProfile} from '../../redux/actions/auth';
import {showToast, hideToast} from '../../components/Toast';
import responsive from '../../tools/scale';
import locale from '../../assets/locale.json';

export default function ProfileForm({
  initialValue = {
    email: '',
    firstName: '',
    lastName: '',
    loginType: 'N',
  },
}) {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(
    ['email', 'firstName', 'lastName'],
    ['email', 'firstName', 'lastName'],
    initialValue,
  );

  const [isLoading, setIsLoading] = React.useState(false);
  const [canUpdate, setCanUpdate] = React.useState(false);

  const dispatch = useDispatch();
  const navigation = useNavigation();

  const {email, firstName, lastName} = values;
  const {
    email: invalidEmail,
    firstName: firstNameInvalid,
    lastName: lastNameInvalid,
  } = invalid;

  const emailInputRef = React.useRef();
  const firstNameInputRef = React.useRef();
  const lastNameInputRef = React.useRef();
  const emailRef = React.useRef();
  const firstNameRef = React.useRef();
  const lastNameRef = React.useRef();

  const registerVM = React.useMemo(
    () =>
      new RegisterVM({
        refKeyValuePair: {
          email: emailRef,
          firstName: firstNameRef,
          lastName: lastNameRef,
        },
        normalLogin: initialValue.loginType === 'N',
      }),
    [initialValue.loginType],
  );

  const register = React.useCallback(async () => {
    try {
      hideToast();
      setIsLoading(true);
      const {data} = await UPDATE_PROFILE({
        ...(initialValue.loginType === 'N' ? {email} : {}),
        first_name: firstName,
        last_name: lastName,
      });
      setIsLoading(false);
      if (data?.success) {
        setCanUpdate(false);
        dispatch(
          updateProfile({
            ...(initialValue.loginType === 'N' ? {email} : {}),
            firstName,
            lastName,
            updateType: initialValue.loginType,
          }),
        );
        showToast({
          type: 'success',
          message: locale.ProfileUpdatedSuccessfully,
        });
      } else {
        showToast({
          message: data?.message || locale.CouldNotUpdateYourProfileAtTheMoment,
        });
      }
    } catch (error) {
      console.log(JSON.stringify({error}, null, 2));
      setIsLoading(false);
      showToast({
        message:
          error?.response?.data?.message || locale.SomethingWentWrongTryAgain,
      });
    }
  }, [dispatch, email, firstName, lastName, initialValue]);

  const handleSubmit = React.useCallback(() => {
    registerVM.handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      email,
      setInvalid,
      submit: register,
    });
  }, [
    showInvalidOnEmpty,
    checkIsEmpty,
    setInvalid,
    email,
    register,
    registerVM,
  ]);

  const handleEmailInputChange = React.useCallback(
    value => {
      setCanUpdate(true);
      registerVM.handleInputChange({
        invalidValue: invalidEmail,
        setInvalid,
        showInvalidForSpecific,
        ref: emailRef,
        handleChange,
        value: value?.trim(),
        type: 'email',
      });
    },
    [
      registerVM,
      invalidEmail,
      showInvalidForSpecific,
      handleChange,
      setInvalid,
      emailRef,
    ],
  );

  const handleFirstNameInputChange = React.useCallback(
    value => {
      setCanUpdate(true);

      registerVM.handleInputChange({
        invalidValue: firstNameInvalid,
        setInvalid,
        showInvalidForSpecific,
        ref: firstNameRef,
        handleChange,
        value,
        type: 'firstName',
      });
    },
    [
      registerVM,
      firstNameInvalid,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
    ],
  );

  const handleLastNameInputChange = React.useCallback(
    value => {
      setCanUpdate(true);

      registerVM.handleInputChange({
        invalidValue: lastNameInvalid,
        setInvalid,
        showInvalidForSpecific,
        ref: lastNameRef,
        handleChange,
        value,
        type: 'lastName',
      });
    },
    [
      registerVM,
      lastNameInvalid,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
    ],
  );

  const isButtonDisabled = isLoading || !canUpdate;
  const isNormalLogin = initialValue.loginType === 'N';

  return (
    <>
      <View>
        <View>
          <Text style={styles.labelStyle}>{locale.Email}</Text>
        </View>
        <View
          ref={ref => (emailRef.current = ref)}
          style={styles.inputViewStyle}>
          <TextInput
            ref={emailInputRef}
            textContentType="emailAddress"
            autoCapitalize="none"
            value={email}
            onSubmitEditing={() => firstNameInputRef.current.focus()}
            onChangeText={handleEmailInputChange}
            style={{
              ...styles.textInputStyles,
              opacity: isNormalLogin ? 1 : 0.3,
            }}
            editable={isNormalLogin}
          />
        </View>
        {invalid.email ? (
          <Text style={{color: 'tomato'}}>{locale.InvalidEmailAddress}</Text>
        ) : null}
      </View>
      <View style={{marginTop: responsive.moderateScale(10)}}>
        <Text style={styles.labelStyle}>{locale.FirstName}</Text>
        <View
          ref={ref => (firstNameRef.current = ref)}
          style={styles.inputViewStyle}>
          <View>
            <TextInput
              ref={firstNameInputRef}
              autoCapitalize="none"
              value={firstName}
              onChangeText={handleFirstNameInputChange}
              onSubmitEditing={() => lastNameInputRef.current.focus()}
              style={styles.textInputStyles}
            />
          </View>
        </View>
      </View>
      <View style={{marginTop: responsive.moderateScale(10)}}>
        <Text style={styles.labelStyle}>{locale.LastName}</Text>
        <View
          ref={ref => (lastNameRef.current = ref)}
          style={styles.inputViewStyle}>
          <View>
            <TextInput
              ref={lastNameInputRef}
              autoCapitalize="none"
              value={lastName}
              onChangeText={handleLastNameInputChange}
              style={styles.textInputStyles}
            />
          </View>
        </View>
      </View>
      <View style={{marginTop: responsive.moderateScale(30)}}>
        <Button
          text="Update"
          onPress={handleSubmit}
          disabled={isButtonDisabled}
          loading={isLoading}
        />
      </View>
      {initialValue.loginType === 'N' ? (
        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Button
            text="Change your password"
            onPress={() => navigation.navigate(screens.CHANGE_PASSWORD)}
          />
        </View>
      ) : null}
    </>
  );
}
