import {validateEmail} from '../../tools/utils';
import colors from '../../assets/colors';

export default class RegisterViewModal {
  constructor({refKeyValuePair}) {
    this.refKeyValuePair = refKeyValuePair;
    this.normalLogin = false;
  }

  handleFormSubmit({
    checkIsEmpty,
    showInvalidOnEmpty,
    email,
    setInvalid,
    submit,
  }) {
    if (checkIsEmpty[1]) {
      showInvalidOnEmpty(this.refKeyValuePair);
      return;
    }
    if (!validateEmail(email)) {
      setInvalid(preState => ({...preState, email: true}));
      return;
    }

    submit();
  }

  handleInputChange({
    invalidValue,
    setInvalid,
    showInvalidForSpecific,
    ref,
    handleChange,
    value,
    type,
  }) {
    if (invalidValue) {
      setInvalid(preState => ({...preState, [type]: false}));
    }
    showInvalidForSpecific(ref, colors.grey);
    handleChange(type, value);
  }
}
