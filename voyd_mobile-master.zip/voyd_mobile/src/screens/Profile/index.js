import React from 'react';
import {View, Text} from 'react-native';

import {Header} from '../../components';
import BaseLayout from '../../layout';
import ProfileForm from './ProfileForm';
import useUser from '../../tools/hooks/useUser';
import responsive from '../../tools/scale';
import locale from '../../assets/locale.json';

export default function Profile() {
  const [user] = useUser();

  const loginType = user?.loginType || 'N';

  const details = {
    loginType,
    email: user?.email || '',
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
  };

  return (
    <BaseLayout
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom: responsive.moderateScale(50),
      }}>
      <BaseLayout.Header>
        <Header logoOnCenter noShadow left="back" logo />
      </BaseLayout.Header>
      <View style={{padding: responsive.moderateScale(20)}}>
        <Text style={{fontSize: responsive.moderateScale(30, 0.1)}}>
          {locale.Profile}
        </Text>
        <View style={{marginTop: responsive.moderateScale(30)}}>
          <ProfileForm initialValue={details} />
        </View>
      </View>
    </BaseLayout>
  );
}
