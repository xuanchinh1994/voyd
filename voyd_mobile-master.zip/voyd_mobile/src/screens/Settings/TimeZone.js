import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';

import styles from './styles';
import locale from '../../assets/locale.json';
import {setTimezone} from './store/action';
import {GET_TIMEZONES} from '../../tools/api';

function TimeZone({selectedId = 1, setSheetData = () => null}) {
  const [data, setData] = React.useState([]);

  const handleTimeZoneButtonPress = React.useCallback(() => {
    setSheetData(previousState => ({
      ...previousState,
      visible: true,
      component: <SheetList list={data} />,
      automaticallyAdjustHeight: false,
    }));
  }, [setSheetData, data]);

  React.useEffect(() => {
    (async function () {
      try {
        const {data: response} = await GET_TIMEZONES();
        if (response && Array.isArray(response)) {
          const reduced = response?.reduce((accumulator, currentValue) => {
            const abbreviation = currentValue?.Abbreviation;
            if (!accumulator[abbreviation]) {
              accumulator[abbreviation] = currentValue?.DisplayName;
            }
            return accumulator;
          }, {});
          setData(reduced);
        }
      } catch (error) {}
    })();
  }, []);

  return (
    <View style={styles.commonView}>
      <Text style={[styles.textStyle]}>{locale.TimeZone}</Text>
      <TouchableOpacity
        style={styles.selection}
        onPress={handleTimeZoneButtonPress}>
        <Text>{data[selectedId]}</Text>
      </TouchableOpacity>
    </View>
  );
}

export function SheetList({
  dispatch = () => null,
  closeSheet = () => null,
  dispatchAction = setTimezone,
  list = [],
  handlePress = null,
}) {
  const handleItemPress = React.useCallback(
    id => {
      dispatch(dispatchAction.call(this, id));
      closeSheet();
    },
    [dispatch, dispatchAction, closeSheet],
  );

  handlePress = handlePress ?? handleItemPress;

  return (
    <View style={{paddingVertical: 20}}>
      <FlatList
        horizontal={false}
        data={Object.entries(list)}
        keyExtractor={([id]) => id?.toString?.()}
        renderItem={({item: [id, name]}) => (
          <View
            key={id}
            style={{
              marginBottom: 20,
            }}>
            <TouchableOpacity
              style={{alignItems: 'center'}}
              onPress={handlePress.bind(null, id)}>
              <Text style={{fontSize: 18, fontWeight: '700', marginBottom: 10}}>
                {name}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

export default TimeZone;
