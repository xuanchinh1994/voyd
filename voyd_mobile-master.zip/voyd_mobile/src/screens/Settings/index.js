import React from 'react';
import {View, TouchableOpacity, ActivityIndicator} from 'react-native';
import {useMutation} from '@apollo/react-hooks';
import {useNavigation} from '@react-navigation/native';

import styles from './styles';
import Colors from './Colors';
import TimeZone from './TimeZone';
import SettingView from './SettingView';
import TimeFormat from './TimeFormat';
import ClockFormat from './ClockFormat';
import DateFormat from './DateFormat';
import Location from './Location';
import BaseLayout from '../../layout';
import SyncCode from './SyncCode';
import {Icon, BottomSheet, Header} from '../../components';
import reducer, {INITIAL_STATE, keys} from './store/reducer';
import {UPDATE_USER} from '../../apollo/mutations';
import {showToast, hideToast} from '../../components/Toast';
import locale from '../../assets/locale.json';
import {useUser} from '../../tools/hooks/useUser';
import {matchToInitialState} from './store/utils';

const SHEET_INITIAL_STATE = {
  visible: false,
  component: null,
  type: null,
  automaticallyAdjustHeight: true,
};

const Settings = ({userData = null}) => {
  const navigation = useNavigation();

  const [state, dispatch] = React.useReducer(
    reducer,
    matchToInitialState(userData, INITIAL_STATE),
  );
  const [sheetData, setSheetData] = React.useState(SHEET_INITIAL_STATE);

  const [updateUser, {loading}] = useMutation(UPDATE_USER);

  const timezone = state?.[keys.timezone];
  const timeFormat = +state?.[keys.timeFormat];
  const clockFormat = +state?.[keys.clockFormat];
  const dateFormat = +state?.[keys.dateFormat];
  const location = state?.[keys.location];
  const fontColor = state?.[keys.fontColor];
  const syncCode = state?.[keys.syncCode];

  const valuesRef = React.useRef(null);

  const isEdited = React.useMemo(() => {
    if (state?.toString() === '[object Object]') {
      const values = Object.keys(state)
        ?.sort()
        ?.map(key => state[key])
        ?.join('|');

      if (!valuesRef.current) {
        valuesRef.current = values;
      }
      return values !== valuesRef.current;
    }
    return false;
  }, [state]);

  const handleUpdate = React.useCallback(
    async state => {
      hideToast();

      if (state?.lat === null || state?.lng === null) {
        const {lat, lng, ...rest} = state;
        state = rest;
      }

      try {
        const {data} = await updateUser({
          variables: {
            ...state,
          },
        });
        const mapping = {
          SYNC_CODE_ALREADY_EXISTS: locale.SyncCodeAlreadyExistsTryNew,
        };
        const success = data?.updateUser?.success;
        const code = data?.updateUser?.code;

        console.log(code);

        if (success) {
          return navigation.goBack();
        }
        const mapped = mapping[code];
        if (mapped) {
          showToast({message: mapped});
          return;
        }
        throw new Error();
      } catch (error) {
        console.log(JSON.stringify({error}));
        showToast({message: locale.SomethingWentWrongTryAgain});
      }
    },
    [updateUser, navigation],
  );

  const handleSheetVisible = React.useCallback(
    type => setSheetData(previousState => ({...previousState, visible: type})),
    [],
  );

  return (
    <>
      <BaseLayout contentContainerStyle={{paddingBottom: 100}}>
        <BaseLayout.Header>
          <Header
            logo
            left="back"
            noShadow
            renderRight={
              isEdited ? (
                loading ? (
                  <ActivityIndicator />
                ) : (
                  <TouchableOpacity onPress={handleUpdate.bind(this, state)}>
                    <Icon name="tick" size={20} />
                  </TouchableOpacity>
                )
              ) : null
            }
          />
        </BaseLayout.Header>

        <View style={styles.container}>
          <SettingView />
          <SyncCode
            dispatch={dispatch}
            canEditInputField={!loading}
            syncCode={syncCode}
          />
          <Colors
            fontColor={fontColor}
            setSheetData={setSheetData}
            dispatch={dispatch}
            disablePicker={loading}
          />
          <TimeZone selectedId={timezone} setSheetData={setSheetData} />
          <TimeFormat selectedId={timeFormat} setSheetData={setSheetData} />
          <ClockFormat selectedId={clockFormat} setSheetData={setSheetData} />
          <DateFormat selectedId={dateFormat} setSheetData={setSheetData} />
          <Location
            selectedId={location}
            setSheetData={setSheetData}
            dispatch={dispatch}
          />
        </View>
      </BaseLayout>
      <BottomSheet
        visible={sheetData.visible && !loading}
        setVisible={handleSheetVisible}
        {...(sheetData.automaticallyAdjustHeight
          ? {automaticallyAdjustHeight: true}
          : {snapPoints: ['70%']})}
        index={0}>
        {sheetData.visible && sheetData.component
          ? React.cloneElement(sheetData.component, {
              dispatch,
              closeSheet: () => handleSheetVisible(false),
            })
          : null}
      </BottomSheet>
    </>
  );
};

function withUserSettings(WrappedComponent = null) {
  return (...props) => {
    const {data, loading, error} = useUser();

    return loading ? (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator />
      </View>
    ) : (
      <WrappedComponent userData={data} {...props} />
    );
  };
}

export default withUserSettings(Settings);
