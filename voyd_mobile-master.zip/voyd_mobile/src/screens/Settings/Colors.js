import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {ColorPicker} from 'react-native-color-picker';

import styles from './styles';
import locale from '../../assets/locale.json';
import Modal from '../../components/Modal';
import {setFontColor} from './store/action';

function Colors({
  disablePicker = false,
  fontColor = '',
  dispatch = () => null,
}) {
  const [visible, setVisible] = React.useState(false);

  const handlePress = React.useCallback(() => {
    setVisible(true);
  }, []);

  const handleColorSelection = React.useCallback(
    color => {
      dispatch(setFontColor(color));
      setVisible(false);
    },
    [dispatch],
  );

  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 10,
      }}>
      <Text style={[styles.textStyle]}>{locale.FontColor}</Text>
      <TouchableOpacity
        style={[styles.fontColorSelection, {backgroundColor: fontColor}]}
        onPress={handlePress}
      />
      <ColorPickerModal
        visible={visible && !disablePicker}
        setVisible={setVisible}
        defaultColor={fontColor}
        onColorSelected={handleColorSelection}
      />
    </View>
  );
}

function ColorPickerModal({
  visible = false,
  setVisible = () => null,
  defaultColor = '',
  onColorSelected = () => null,
}) {
  return (
    <Modal visible={visible} setVisible={setVisible}>
      <Text>{locale.TapTheCenterToSelectTheColor}</Text>
      <ColorPicker
        defaultColor={defaultColor}
        onColorSelected={onColorSelected.bind(this)}
        style={{flex: 1, width: '100%', height: '100%'}}
      />
    </Modal>
  );
}

export default Colors;
