import React from 'react';
import {View, Text, TextInput} from 'react-native';

import styles from './styles';
import locale from '../../assets/locale.json';
import colors from '../../assets/colors';
import {setSyncCode as setSyncCodeAction} from './store/action';

const DEBOUNCE_PERIOD = 500;

export default function SyncCode({
  canEditInputField = true,
  syncCode: code = '',
  dispatch = () => null,
}) {
  const [syncCode, setSyncCode] = React.useState(code);

  const timerId = React.useRef();

  React.useEffect(() => {
    if (timerId.current) {
      clearTimeout(timerId.current);
    }
    timerId.current = window.setTimeout(() => {
      dispatch(setSyncCodeAction(syncCode));
    }, DEBOUNCE_PERIOD);
  }, [syncCode, dispatch]);

  return (
    <View style={styles.MainTextView}>
      <Text style={styles.textStyle}>{locale.SyncCode}</Text>
      <TextInput
        style={styles.linkText}
        numberOfLines={1}
        placeholder={locale.EnterTheSyncCode}
        autoCapitalize={'none'}
        autoCorrect={false}
        onChangeText={text => setSyncCode(text)}
        placeholderTextColor={colors.grey}
        value={syncCode}
        editable={canEditInputField}
      />
    </View>
  );
}
