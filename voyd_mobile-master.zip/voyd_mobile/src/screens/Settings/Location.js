import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';

import {Icon} from '../../components';
import {withLocationPermission} from '../../components/HOC';
import styles from './styles';
import locale from '../../assets/locale.json';
import {setLocation, setLocationName} from './store/action';
import {SheetList} from './TimeZone';
import {GET_CITIES} from '../../tools/api';
import useGeolocation from '../../tools/hooks/useGeolocation';
import colors from '../../assets/colors';

function Location({
  selectedId = '',
  setSheetData = () => null,
  dispatch = () => null,
}) {
  const [data, setData] = React.useState(null);
  const [rawData, setRawData] = React.useState([]);

  const handleButtonPress = React.useCallback(() => {
    setSheetData(previousState => ({
      ...previousState,
      visible: true,
      component: React.createElement(SheetList, {
        list: data,
        handlePress: id => {
          const selected = rawData?.find(item => item?.capital == id);
          const latitude = selected?.lat;
          const longitude = selected?.long;
          dispatch(setLocation(id, latitude, longitude));
          setSheetData(previousState => ({...previousState, visible: false}));
        },
      }),
      automaticallyAdjustHeight: false,
    }));
  }, [setSheetData, data, dispatch, rawData]);

  React.useEffect(() => {
    GET_CITIES()
      .then(({data}) => {
        const states = data?.states;
        if (states && Array.isArray(states)) {
          setRawData(states);
          const reduced = states?.reduce((accumulator, currentValue) => {
            const city = currentValue?.capital;
            if (!accumulator[city]) {
              accumulator[city] = city;
            }
            return accumulator;
          }, {});
          setData(reduced);
        }
      })
      .catch(() => null);
  }, []);

  const handleOnCurrentLocationSuccess = React.useCallback(
    currentLocation => {
      dispatch(
        setLocation(
          currentLocation?.address,
          currentLocation?.latitude,
          currentLocation?.longitude,
        ),
      );
    },
    [dispatch],
  );

  const handleCustomName = React.useCallback(() => {
    Alert.prompt(locale.EnterYourLocation, '', [
      {
        text: locale.cancel,
        onPress: () => null,
        style: 'cancel',
      },
      {
        text: locale.OK,
        onPress: value => {
          dispatch(setLocationName(value));
        },
      },
    ]);
  }, [dispatch]);

  const isCustomLocation = selectedId?.length && !data?.[selectedId];

  return data ? (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
      <View style={[styles.commonView, {flex: 1}]}>
        <Text style={[styles.textStyle]}>{locale.Location}</Text>
        <TouchableOpacity style={styles.selection} onPress={handleButtonPress}>
          <Text>{data[selectedId] || selectedId}</Text>
          {isCustomLocation ? (
            <TouchableOpacity
              onPress={handleCustomName}
              style={{
                position: 'absolute',
                top: -3,
                right: 0,
                padding: 10,
                zIndex: 100,
              }}>
              <Icon name="edit" />
            </TouchableOpacity>
          ) : null}
        </TouchableOpacity>
      </View>
      <CurrentLocationWithPermissions
        onSuccess={handleOnCurrentLocationSuccess}>
        {({getCurrentLocation, loading = false, success}) =>
          loading ? (
            <ActivityIndicator style={{marginHorizontal: 30}} />
          ) : (
            <TouchableOpacity
              style={{marginHorizontal: 20}}
              onPress={getCurrentLocation}>
              <Icon
                name="location"
                size={40}
                tint={success || isCustomLocation ? colors.green : colors.black}
              />
            </TouchableOpacity>
          )
        }
      </CurrentLocationWithPermissions>
    </View>
  ) : null;
}

function CurrentLocation({
  children = null,
  requestLocationPermission = () => null,
  locationEnabled = false,
  onSuccess = () => null,
}) {
  const {currentLocation, loading} = useGeolocation(locationEnabled);

  const success = React.useMemo(
    () =>
      currentLocation?.latitude &&
      currentLocation?.longitude &&
      currentLocation?.address?.length,
    [currentLocation],
  );

  const getCurrentLocation = React.useCallback(() => {
    if (!locationEnabled) {
      requestLocationPermission();
    }
  }, [locationEnabled, requestLocationPermission]);

  React.useEffect(() => {
    if (success) {
      onSuccess(currentLocation);
    }
  }, [currentLocation, onSuccess, success]);

  return children({getCurrentLocation, success, loading});
}

const CurrentLocationWithPermissions = withLocationPermission(
  CurrentLocation,
  true,
  true,
  true,
);

export default Location;
