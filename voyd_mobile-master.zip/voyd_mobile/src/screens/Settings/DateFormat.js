import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';

import styles from './styles';
import locale from '../../assets/locale.json';
import {setDateFormat} from './store/action';
import {SheetList} from './TimeZone';

const DATA = {
  1: 'dd/mm/yyyy',
  2: 'Wed April 1 2021',
};

function DateFormat({selectedId = 1, setSheetData = () => null}) {
  const handleButtonPress = React.useCallback(() => {
    setSheetData(previousState => ({
      ...previousState,
      visible: true,
      component: React.createElement(SheetList, {
        dispatchAction: setDateFormat,
        list: DATA,
      }),
      automaticallyAdjustHeight: true,
    }));
  }, [setSheetData]);

  return (
    <View style={styles.commonView}>
      <Text style={[styles.textStyle]}>{locale.DateFormat}</Text>
      <TouchableOpacity style={styles.selection} onPress={handleButtonPress}>
        <Text>{DATA[selectedId]}</Text>
      </TouchableOpacity>
    </View>
  );
}

export default DateFormat;
