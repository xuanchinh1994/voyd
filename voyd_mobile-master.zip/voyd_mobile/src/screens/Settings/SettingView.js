import React from 'react';
import {View, Text} from 'react-native';
import Icon from '../../components/Icon';

import locale from '../../assets/locale.json';

const SettingView = () => {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignSelf: 'flex-start',
        marginBottom: 15,
      }}>
      <Icon
        style={{color: 'black', flex: 1, alignSelf: 'flex-start'}}
        name={'gear'}
        size={30}
        tint={'black'}
      />
      <Text
        style={{
          fontSize: 20,
          marginLeft: 10,
          fontWeight: '700',
          marginTop: 5,
        }}>
        {locale.Settings}
      </Text>
    </View>
  );
};

export default SettingView;
