import {StyleSheet} from 'react-native';

import colors from '../../assets/colors';

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  linkText: {
    borderWidth: 1,
    borderColor: 'grey',
    marginTop: 5,
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 10,
  },
  MainTextView: {
    marginVertical: 10,
  },
  commonView: {
    marginVertical: 5,
  },
  textStyle: {fontSize: 16, fontWeight: '600'},
  fontColorSelection: {
    width: 35,
    height: 35,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: colors.grey,
  },
  modalOpen: {
    height: 50,
    backgroundColor: 'red',
    borderRadius: 10,
    marginBottom: 10,
  },
  modalOpenText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
    marginTop: 10,
  },
  selection: {
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 10,
    marginVertical: 10,
    borderColor: colors.grey,
  },
  timeZoneModal: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    height: 150,
    borderRadius: 20,
    position: 'absolute',
    bottom: 0,
  },
  mainToolbar: {
    height: 50,
    backgroundColor: 'white',
    borderBottomColor: 'grey',
    borderBottomWidth: 0.5,
    flexDirection: 'row',
  },
  burgerIcon: {
    marginLeft: 20,
    marginTop: 15,
    transform: [{rotateY: '180deg'}],
  },
  titleText: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
  },
});

export default styles;
