import actionTypes from './actionTypes';

export const keys = {
  timezone: 'timezone',
  timeFormat: 'timeFormat',
  clockFormat: 'clockFormat',
  dateFormat: 'dateFormat',
  location: 'location',
  fontColor: 'fontColor',
  syncCode: 'syncCode',
  lat: 'lat',
  lng: 'lng',
};

export const INITIAL_STATE = {
  [keys.timezone]: '',
  [keys.timeFormat]: 1,
  [keys.clockFormat]: 1,
  [keys.dateFormat]: 1,
  [keys.location]: '',
  [keys.fontColor]: '',
  [keys.syncCode]: '',
  [keys.lat]: null,
  [keys.lng]: null,
};

function reducer(state = INITIAL_STATE, action) {
  const payload = action?.payload;
  switch (action?.type) {
    case actionTypes.SET_TIME_ZONE:
      return {
        ...state,
        [keys.timezone]: payload,
      };
    case actionTypes.SET_TIME_FORMAT:
      return {
        ...state,
        [keys.timeFormat]: setIfValidNumber(payload, keys.timeFormat),
      };
    case actionTypes.SET_CLOCK_FORMAT:
      return {
        ...state,
        [keys.clockFormat]: setIfValidNumber(payload, keys.clockFormat),
      };
    case actionTypes.SET_DATE_FORMAT:
      return {
        ...state,
        [keys.dateFormat]: setIfValidNumber(payload, keys.dateFormat),
      };
    case actionTypes.SET_FONT_COLOR:
      return {
        ...state,
        [keys.fontColor]: payload,
      };
    case actionTypes.SET_LOCATION:
      return {
        ...state,
        [keys.location]: payload?.id,
        [keys.lat]: +payload?.lat,
        [keys.lng]: +payload?.lng,
      };
    case actionTypes.SET_LOCATION_NAME:
      return {
        ...state,
        [keys.location]: payload,
      };
    case actionTypes.SET_SYNC_CODE:
      return {
        ...state,
        [keys.syncCode]: payload,
      };
    default:
      return state;
  }
}

function setIfValidNumber(value, type = '') {
  return !isNaN(+value) ? +value : INITIAL_STATE[type];
}

export default reducer;
