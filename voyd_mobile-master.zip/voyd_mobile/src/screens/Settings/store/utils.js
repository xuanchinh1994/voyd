import {keys} from './reducer';

export function matchToInitialState(data, originalState) {
  return {
    ...originalState,
    [keys.timezone]: data?.time_zone || originalState[keys.timezone],
    [keys.timeFormat]: +data?.time_format || originalState[keys.timeFormat],
    [keys.clockFormat]: +data?.clock_format || originalState[keys.clockFormat],
    [keys.dateFormat]: +data?.date_format || originalState[keys.dateFormat],
    [keys.location]: data?.location || originalState[keys.location],
    [keys.fontColor]: data?.font_color || originalState[keys.fontColor],
    [keys.syncCode]: data?.sync_code || originalState[keys.syncCode],
  };
}
