import actionTypes from './actionTypes';

export function setTimezone(payload) {
  return {
    type: actionTypes.SET_TIME_ZONE,
    payload,
  };
}

export function setTimeFormat(payload) {
  return {
    type: actionTypes.SET_TIME_FORMAT,
    payload,
  };
}

export function setClockFormat(payload) {
  return {
    type: actionTypes.SET_CLOCK_FORMAT,
    payload,
  };
}

export function setDateFormat(payload) {
  return {
    type: actionTypes.SET_DATE_FORMAT,
    payload,
  };
}

export function setLocation(payload, lat, lng) {
  if (isNaN(lat) || isNaN(lng)) {
    throw new Error('Invalid lat or lng value.');
  }
  return {
    type: actionTypes.SET_LOCATION,
    payload: {
      lat,
      lng,
      id: payload,
    },
  };
}

export function setFontColor(payload) {
  return {
    type: actionTypes.SET_FONT_COLOR,
    payload,
  };
}

export function setSyncCode(payload) {
  return {
    type: actionTypes.SET_SYNC_CODE,
    payload,
  };
}

export function setLocationName(payload) {
  return {
    type: actionTypes.SET_LOCATION_NAME,
    payload,
  };
}
