import React from 'react';
import RNCalendarEvents from 'react-native-calendar-events';
import {useMutation} from '@apollo/react-hooks';
import {useNavigation} from '@react-navigation/native';

import {SYNC_CALENDAR} from '../../apollo/mutations';
import checkPermission from '../../tools/permissions';
import {DateUtilities} from '../../tools/utils';

const CALENDAR_INITIAL_DATA_LOCAL = {
  success: false,
  loading: true,
  refreshing: false,
  data: null,
};

export default function useCalendarEvents(
  shouldHandlePermission = true,
  calendarPermissionGranted,
  setCalendarPermissionGranted,
) {
  const navigation = useNavigation();

  const [calendarData, setCalendarData] = React.useState(
    CALENDAR_INITIAL_DATA_LOCAL,
  );

  const [syncCalendarToServer] = useMutation(SYNC_CALENDAR);

  const startSyncToServer = React.useCallback(
    async (data, onSuccess = () => null, onError = () => null) => {
      try {
        const {data: syncResponse} = await syncCalendarToServer({
          variables: {input: data},
        });
        onSuccess(syncResponse);
      } catch (error) {
        onError(error);
      }
    },
    [syncCalendarToServer],
  );

  const syncCalendar = React.useCallback(
    async (refresh = false) => {
      try {
        if (calendarPermissionGranted) {
          if (refresh) {
            setCalendarData(previousState => ({
              ...previousState,
              refreshing: true,
            }));
          }

          const calendars = await RNCalendarEvents.findCalendars();
          const filterCalendars = calendars?.filter(
            calendar => calendar?.allowsModifications,
          );
          const calendarData = await RNCalendarEvents.fetchAllEvents(
            DateUtilities.getDateToday.local.start(),
            DateUtilities.getDateToday.local.end(),
            filterCalendars?.map(calendar => calendar?.id),
          );
          startSyncToServer(
            calendarData?.map(item => ({
              event_id: item?.id,
              title: item?.title,
              start_date: item?.startDate,
              end_date: item?.endDate,
            })),
            () => {
              setCalendarData(previousState => ({
                ...previousState,
                refreshing: false,
              }));
            },
            () =>
              setCalendarData(previousState => ({
                ...previousState,
                refreshing: false,
              })),
          );

          setCalendarData(previousState => ({
            ...previousState,
            success: true,
            loading: false,
            data: calendarData,
          }));
        } else {
          if (shouldHandlePermission) {
            await checkPermission(
              'calendar',
              setCalendarPermissionGranted,
              true,
              shouldHandlePermission,
              false,
              navigation,
            );
          }
        }
      } catch (error) {
        setCalendarData(previousState => ({
          ...previousState,
          success: false,
          loading: false,
          data: null,
          refreshing: false,
        }));
      }
    },
    [
      calendarPermissionGranted,
      startSyncToServer,
      shouldHandlePermission,
      setCalendarPermissionGranted,
      navigation,
    ],
  );
  return {syncCalendar, calendarData};
}
