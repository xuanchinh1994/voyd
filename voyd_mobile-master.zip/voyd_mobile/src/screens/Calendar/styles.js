import {StyleSheet, Dimensions} from 'react-native';
const {width} = Dimensions.get('window');

import colors from '../../assets/colors';

const styles = StyleSheet.create({
  container: {
    alignSelf: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  heading: {
    fontSize: 20,
    fontWeight: '700',
    marginTop: 5,
  },
  headingIcon: {
    color: colors.black,
    flex: 1,
    alignSelf: 'center',
  },
  headingView: {
    flexDirection: 'row',
    marginTop: 40,
    alignSelf: 'flex-start',
    marginLeft: 35,
  },
  startSync: {
    alignItems: 'center',
    marginTop: 50,
    height: 50,
    backgroundColor: colors.red,
    borderRadius: 10,
  },
  containerCalendarItems: {
    paddingHorizontal: 20,
    flex: 1,
  },
  startSyncText: {
    marginTop: 15,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  calendarItemHeader: {
    flexDirection: 'row',
    marginTop: 30,
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'center',
  },
  calendarItemIcon: {color: 'black', marginRight: 10},
  calendarItemText: {
    fontSize: 26,
    fontWeight: '700',
  },
  calendarRenderItem: {
    alignItems: 'center',
    marginTop: 10,
    flexDirection: 'row',
    borderColor: colors.black,
    borderWidth: 1.5,
    borderRadius: 10,
    minHeight: 80,
    padding: 20,
  },
  calendarRenderDate: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
  },
  calendarRenderItemData: {
    fontSize: 16,
  },
  monthText: {
    fontSize: 18,
    fontWeight: '600',
  },
  dayText: {
    fontSize: 26,
    fontWeight: '800',
    marginTop: 5,
  },
  calendarRenderData: {
    marginRight: 0,
  },
  calendarRenderItemTiming: {
    marginTop: 10,
    fontWeight: '700',
  },
  mainToolbar: {
    height: 50,
    backgroundColor: colors.white,
    borderBottomColor: colors.grey,
    borderBottomWidth: 0.5,
    flexDirection: 'row',
  },
  burgerIcon: {
    marginLeft: 20,
    marginTop: 15,
    transform: [{rotateY: '180deg'}],
  },
  titleText: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
  },
  activityIndicatorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default styles;
