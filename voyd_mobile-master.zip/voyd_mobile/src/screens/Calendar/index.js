import React from 'react';
import {View, Text, TouchableOpacity, ActivityIndicator} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';

import {Header, Icon} from '../../components';
import styles from './styles';
import BaseLayout from '../../layout';
import locale from '../../assets/locale.json';
import {withCalendarPermission} from '../../components/HOC';
import AllEvents from './AllEvents';
import useCalendarEvents from './useCalendarEvents';

const Calendar = ({
  calendarPermissionGranted,
  setCalendarPermissionGranted,
}) => {
  const {calendarData, syncCalendar} = useCalendarEvents(
    true,
    calendarPermissionGranted,
    setCalendarPermissionGranted,
  );

  useFocusEffect(
    React.useCallback(() => {
      if (calendarPermissionGranted) {
        syncCalendar();
      }
    }, [calendarPermissionGranted, syncCalendar]),
  );

  return (
    <BaseLayout scrollChildren={false}>
      <BaseLayout.Header>
        <Header logo left="back" noShadow />
      </BaseLayout.Header>
      {!calendarPermissionGranted ? (
        <View style={styles.container}>
          <Icon
            style={styles.headingIcon}
            name="calendar"
            size={60}
            tint={'black'}
          />
          <Text style={{marginTop: 20, fontSize: 16, fontWeight: '700'}}>
            {locale.SyncYourCalendarWithSmartMirror}
          </Text>
          <TouchableOpacity style={styles.startSync} onPress={syncCalendar}>
            <Text style={styles.startSyncText}>{locale.StartSyncing}</Text>
          </TouchableOpacity>
        </View>
      ) : calendarData?.data ? (
        <AllEvents
          data={calendarData?.data}
          syncCalendar={syncCalendar}
          refreshing={calendarData.refreshing}
        />
      ) : calendarData.loading ? (
        <View style={styles.activityIndicatorContainer}>
          <ActivityIndicator />
        </View>
      ) : null}
    </BaseLayout>
  );
};

export default withCalendarPermission(Calendar);
