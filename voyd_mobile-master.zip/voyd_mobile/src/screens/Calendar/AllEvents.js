import React from 'react';
import {View, Text, FlatList, RefreshControl} from 'react-native';

import Icon from '../../components/Icon';
import styles from './styles';
import {DateUtilities} from '../../tools/utils';
import locale from '../../assets/locale.json';

const AllEvents = ({
  data = [],
  syncCalendar = () => null,
  refreshing = false,
}) => {
  return (
    <View style={styles.containerCalendarItems}>
      <FlatList
        contentContainerStyle={[{flex: 1}]}
        ListHeaderComponent={
          <View style={styles.calendarItemHeader}>
            <Icon
              style={styles.calendarItemIcon}
              name={'calendar'}
              size={30}
              tint={'black'}
            />
            <Text style={styles.calendarItemText}>{locale.CalendarEvents}</Text>
          </View>
        }
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => syncCalendar(true)}
          />
        }
        style={{marginBottom: 20}}
        data={data}
        renderItem={({item}) => <CalendarItem item={item} />}
        showsVerticalScrollIndicator={false}
        keyExtractor={(_, index) => index.toString()}
        ListEmptyComponent={
          <View style={styles.activityIndicatorContainer}>
            <Text>{locale.AllCaughtUpForToday}</Text>
          </View>
        }
      />
    </View>
  );
};

function CalendarItem({item}) {
  return (
    <View style={styles.calendarRenderItem}>
      <View style={styles.calendarRenderDate}>
        <Text style={styles.monthText}>
          {DateUtilities.getMonth(item?.startDate)}
        </Text>
        <Text style={styles.dayText}>
          {new Date(item?.startDate).getDate()}
        </Text>
      </View>
      <View style={styles.calendarRenderData}>
        <Text style={styles.calendarRenderItemData}>{item?.title}</Text>
        <Text style={styles.calendarRenderItemTiming}>
          {DateUtilities.format_AM_PM(item?.startDate)}
        </Text>
      </View>
    </View>
  );
}

export default AllEvents;
