import {StyleSheet} from 'react-native';

import colors from '../../assets/colors';

export default StyleSheet.create({
  camera: {
    flex: 1,
  },
  galleryButton: {
    width: 28,
    height: 28,
    borderRadius: 5,
    backgroundColor: colors.white,
    marginLeft: 5,
  },
  readerFocus: {
    position: 'absolute',
  },
  dimmer: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.6,
  },
  loadingOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    justifyContent: 'center',
    backgroundColor: colors.black,
    opacity: 0.8,
    zIndex: 100,
  },
  controls: {
    width: '100%',
    flex: 1,
    alignItems: 'center',
  },
  helperText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  zoomContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  zoomText: {
    color: colors.white,
    fontSize: 30,
  },
  zoomSlider: {
    width: '80%',
    marginHorizontal: 10,
  },
});
