import React, {useState} from 'react';
import {View, Image, StatusBar, Platform} from 'react-native';

import Slider from '@react-native-community/slider';
import {QRreader, QRscanner} from 'react-native-qr-decode-image-camera';
import ImgPicker from 'react-native-image-crop-picker';
import {
  useNavigation,
  useFocusEffect,
  useRoute,
} from '@react-navigation/native';

import Layout from '../../layout';
import {Header, Icon} from '../../components';
import colors from '../../assets/colors';
import styles from './styles';
import locale from '../../assets/locale.json';
import withCameraPermission from '../../components/HOC/withCameraPermission';
import withStoragePermission from '../../components/HOC/withStoragePermission';
import checkPermission from '../../tools/permissions';
import {showToast, hideToast} from '../../components/Toast';

function Scan({setStorageGranted, storagePermission}) {
  const timer1Ref = React.useRef();
  const timer2Ref = React.useRef();
  const delayRef = React.useRef();

  const [cameraVisible, setCameraVisible] = React.useState(false);

  const navigation = useNavigation();
  const route = useRoute();
  const fromScreen = route?.params?.fromScreen;

  const [zoom, setZoom] = useState(0);

  const [barcodeRead, setBarcodeRead] = useState(false);

  const onBarCodeRead = async code => {
    if (barcodeRead) {
      return;
    }

    try {
      fetchScan(code?.data);
    } catch (err) {
      setBarcodeRead(false);
      showToast({message: locale.SomethingWentWrongTryAgain});
      if (timer1Ref.current) {
        clearTimeout(timer1Ref.current);
      }
      timer1Ref.current = setTimeout(() => setBarcodeRead(false), 1000);
    }
  };

  const fetchScan = async qrCode => {
    navigation.navigate(fromScreen, {
      qrCode,
    });
    if (timer2Ref) {
      clearTimeout(timer2Ref);
    }
    timer2Ref.current = setTimeout(() => setBarcodeRead(false), 1000);
  };

  const handleScanThroughImage = () => {
    hideToast();
    storagePermission
      ? ImgPicker.openPicker({
          width: 400,
          height: 400,
          cropping: true,
          mediaType: 'photo',
        })
          .then(res => {
            let a = res.path;
            if (res.path.startsWith('file://')) {
              a = res.path.replace('file://', '');
            }
            QRreader(a)
              .then(qr_code => {
                fetchScan(qr_code);
              })
              .catch(() => {
                setBarcodeRead(false);
                showToast({message: locale.invalidQRCodeDetected});
              });
          })
          .catch(null)
      : checkPermission('storage', setStorageGranted, {navigation}, true);
  };

  useFocusEffect(
    React.useCallback(() => {
      delayRef.current = setTimeout(() => setCameraVisible(true), 300);
    }, []),
  );

  React.useEffect(() => {
    return () => {
      clearTimeout(timer1Ref.current);
      clearTimeout(timer2Ref.current);
      clearTimeout(delayRef.current);
    };
  }, []);

  return cameraVisible ? (
    <Layout scrollChildren={false} safeAreaColor={colors.black}>
      {
        <StatusBar
          backgroundColor={colors.black}
          barStyle={
            Platform.OS === 'android' ? 'dark-content' : 'light-content'
          }
        />
      }

      <Header
        noShadow
        style={{zIndex: 1}}
        left={{
          render: () => (
            <Icon
              name="plus"
              tint={colors.white}
              style={{transform: [{rotate: '45deg'}]}}
              clickable
              onPress={() => navigation.goBack()}
            />
          ),
        }}
        right={{
          prefix: locale.gallery,
          prefixStyle: {
            color: colors.white,
          },
          render: () => (
            <Image
              source={require('../../assets/images/logo.jpg')}
              style={styles.galleryButton}
              resizeMode="contain"
            />
          ),
          action: handleScanThroughImage,
        }}
        backgroundColor={colors.black}
        borderColor="transparent"
        disableBorderForIOS
        statusbarBackgroundColor={colors.black}
        statusbarBarStyle="light-content"
      />
      <QRscanner
        zoom={zoom}
        captureAudio={false}
        maskColor="transparent"
        style={styles.camera}
        onRead={onBarCodeRead}
        scanBarColor={colors.white}
        cornerColor={colors.white}
        hintText={locale.alignCodeInFrameToScan}
        bottomViewStyle={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}
        renderBottomView={() => (
          <View style={styles.zoomContainer}>
            <Slider
              minimumValue={0}
              maximumValue={1}
              minimumTrackTintColor={colors.white}
              maximumTrackTintColor={colors.white}
              onValueChange={setZoom}
              style={styles.zoomSlider}
            />
          </View>
        )}
      />
    </Layout>
  ) : null;
}

export default withStoragePermission(withCameraPermission(Scan), true, false);
