import React from 'react';
import {Text, TextInput, View, TouchableOpacity, Image} from 'react-native';
import {useNavigation, useRoute} from '@react-navigation/native';

import {screens, errorCodes} from '../../assets/strings';
import locale from '../../assets/locale.json';
import {Button} from '../../components';
import BaseLayout from '../../layout';
import useInput from '../../tools/hooks/useInput';
import ResetVM from './VM';
import {RESET_PASSWORD} from '../../tools/api';
import {showToast, hideToast} from '../../components/Toast';
import styles from './styles';
import colors from '../../assets/colors';
import Logo from '../../assets/images/logo.jpg';
import responsive from '../../tools/scale';

export default function ResetPassword() {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(
    ['password', 'confirmPassword'],
    ['password', 'confirmPassword'],
  );

  const [toggle, setToggle] = React.useState(true);
  const [toggle2, setToggle2] = React.useState(true);

  const [isLoading, setIsLoading] = React.useState(false);
  const [
    {
      password: customPasswordError,
      confirmPassword: customConfirmPasswordError,
    },
    setCustomError,
  ] = React.useState({
    password: '',
    confirmPassword: '',
  });

  const navigation = useNavigation();
  const route = useRoute();

  const code = route?.params?.resetCode;
  const email = route?.params?.email;

  const passwordInputRef = React.useRef();
  const confirmPasswordInputRef = React.useRef();
  const passwordRef = React.useRef();
  const confirmPasswordRef = React.useRef();

  const {password, confirmPassword} = values;
  const {password: invalidPassword, confirmPassword: invalidConfirmPassword} =
    invalid;

  const resetVM = React.useMemo(
    () =>
      new ResetVM({
        refKeyValuePair: {
          password: passwordRef,
          confirmPassword: confirmPasswordRef,
        },
      }),
    [],
  );

  const reset = React.useCallback(async () => {
    try {
      if (!code) {
        navigation.navigate(screens.LOGIN, {
          navigate: {
            message: locale.InvalidCode,
            success: false,
          },
        });
      }
      hideToast();
      setIsLoading(true);

      const {data} = await RESET_PASSWORD({
        password,
        code,
        email,
      });
      setIsLoading(false);
      if (data?.success) {
        navigation.navigate(screens.LOGIN, {
          navigate: {
            message: locale.PasswordResetWasSuccessful,
            success: true,
          },
        });
      } else {
        showToast({
          message: data?.message || locale.CouldNotChangePasswordAtTheMoment,
        });
      }
    } catch (error) {
      setIsLoading(false);
      if (error?.response?.data?.code === errorCodes.INVALID_CODE) {
        navigation.navigate(screens.LOGIN, {
          navigate: {
            message: locale.InvalidCode,
            success: false,
          },
        });
      } else {
        showToast({
          message:
            error?.response?.data?.message || locale.SomethingWentWrongTryAgain,
        });
      }
    }
  }, [code, password, navigation, email]);

  const handleSubmit = React.useCallback(() => {
    resetVM.handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      password,
      confirmPassword,
      submit: reset,
      setCustomError,
    });
  }, [
    resetVM,
    checkIsEmpty,
    showInvalidOnEmpty,
    password,
    confirmPassword,
    reset,
  ]);

  const handlePasswordInputChange = React.useCallback(
    value => {
      if (customPasswordError?.length) {
        setCustomError(previousState => ({...previousState, password: false}));
      }
      resetVM.handleInputChange({
        invalidValue: invalidPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: passwordRef,
        handleChange,
        value,
        type: 'password',
      });
    },
    [
      resetVM,
      invalidPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customPasswordError,
    ],
  );
  const handlePassword2InputChange = React.useCallback(
    value => {
      if (customConfirmPasswordError?.length) {
        setCustomError(previousState => ({
          ...previousState,
          confirmPassword: false,
        }));
      }
      resetVM.handleInputChange({
        invalidValue: invalidConfirmPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: confirmPasswordRef,
        handleChange,
        value,
        type: 'confirmPassword',
      });
    },
    [
      resetVM,
      invalidConfirmPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customConfirmPasswordError,
    ],
  );

  const handlePasswordToggle = React.useCallback(() => {
    setToggle(preState => !preState);
  }, []);
  const handlePasswordToggle2 = React.useCallback(() => {
    setToggle2(preState => !preState);
  }, []);

  return (
    <BaseLayout
      style={{padding: responsive.moderateScale(20)}}
      contentContainerStyle={{
        justifyContent: 'center',
        flexGrow: 1,
      }}>
      <View>
        <View style={styles.logoContainer}>
          <Image source={Logo} style={styles.logo} />
        </View>
        <View style={{flex: 1, marginTop: responsive.moderateScale(50)}}>
          <Text
            style={{
              fontSize: responsive.moderateScale(30),
              color: colors.primary,
            }}>
            {locale.ResetPassword}
          </Text>
          <View style={{marginTop: responsive.moderateScale(30)}} />
          <View>
            <Text style={styles.labelStyle}>{locale.NewPassword}</Text>
            <View
              ref={ref => (passwordRef.current = ref)}
              style={styles.inputViewStyle}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <TextInput
                  ref={passwordInputRef}
                  textContentType="password"
                  autoCapitalize="none"
                  secureTextEntry={toggle}
                  value={values.password}
                  onChangeText={handlePasswordInputChange}
                  placeholder={locale.EnterYourNewPassword}
                  onSubmitEditing={() =>
                    confirmPasswordInputRef.current.focus()
                  }
                  style={{width: '80%', ...styles.textInputStyles}}
                />
                <TouchableOpacity onPress={handlePasswordToggle}>
                  <Text style={{fontSize: responsive.moderateScale(14)}}>
                    {toggle ? locale.Show : locale.Hide}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {customPasswordError?.length > 0 ? (
              <Text style={{color: 'tomato'}}>{customPasswordError}</Text>
            ) : null}
          </View>

          <View style={{marginTop: 10}}>
            <Text style={styles.labelStyle}>{locale.ConfirmPassword}</Text>
            <View
              ref={ref => (confirmPasswordRef.current = ref)}
              style={styles.inputViewStyle}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <TextInput
                  ref={confirmPasswordInputRef}
                  textContentType="password"
                  autoCapitalize="none"
                  secureTextEntry={toggle2}
                  value={values.confirmPassword}
                  onChangeText={handlePassword2InputChange}
                  onSubmitEditing={handleSubmit}
                  placeholder={locale.ConfirmYourNewPassword}
                  style={{width: '80%', ...styles.textInputStyles}}
                />
                <TouchableOpacity onPress={handlePasswordToggle2}>
                  <Text style={{fontSize: responsive.moderateScale(14)}}>
                    {toggle2 ? locale.Show : locale.Hide}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            {customConfirmPasswordError?.length > 0 ? (
              <Text style={{color: 'tomato'}}>
                {customConfirmPasswordError}
              </Text>
            ) : null}
          </View>

          <View style={{marginTop: 50}}>
            <Button
              text={locale.Reset}
              onPress={handleSubmit}
              disabled={isLoading}
              loading={isLoading}
            />
            <TouchableOpacity
              onPress={() => navigation.navigate(screens.LOGIN)}>
              <Text
                style={{
                  textAlign: 'center',
                  marginTop: 15,
                  ...styles.labelStyle,
                  color: colors.primary,
                }}>
                {locale.BackToLogin}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </BaseLayout>
  );
}
