import React from 'react';
import {View, Text, ActivityIndicator} from 'react-native';
import {useNavigation} from '@react-navigation/native';

import {Modal} from '../../components';
import BaseLayout from '../../layout';
import useLogout from '../../tools/hooks/useLogout';
import locale from '../../assets/locale.json';

export default function ForceLogout() {
  const navigation = useNavigation();
  const onError = () => {
    navigation.canGoBack() && navigation.goBack();
  };

  const {logout} = useLogout({onError});

  React.useEffect(() => {
    logout();
  }, [logout]);

  return (
    <BaseLayout scrollChildren={false}>
      <Modal visible height={100}>
        <View>
          <Text style={{fontSize: 20, fontWeight: '700', marginBottom: 20}}>
            {locale.SessionExpired}
          </Text>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <ActivityIndicator />
            <Text style={{marginLeft: 10}}>{locale.LoggingYouOut}</Text>
          </View>
        </View>
      </Modal>
    </BaseLayout>
  );
}
