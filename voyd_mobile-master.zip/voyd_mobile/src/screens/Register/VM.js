import {validateEmail} from '../../tools/utils';
import colors from '../../assets/colors';
import locale from '../../assets/locale.json';

export default class RegisterViewModal {
  constructor({refKeyValuePair}) {
    this.refKeyValuePair = refKeyValuePair;
  }

  handleFormSubmit({
    checkIsEmpty,
    showInvalidOnEmpty,
    email,
    setInvalid,
    submit,
    password,
    setCustomError,
  }) {
    if (checkIsEmpty[1]) {
      showInvalidOnEmpty(this.refKeyValuePair);
      return;
    }
    if (!validateEmail(email)) {
      setInvalid(preState => ({...preState, email: true}));
      return;
    }
    if (password.length < 6) {
      setCustomError(previousState => ({
        ...previousState,
        password: locale.PasswordShouldAtLeastBeSixCharactersLong,
      }));
      return;
    }
    submit();
  }

  handleInputChange({
    invalidValue,
    setInvalid,
    showInvalidForSpecific,
    ref,
    handleChange,
    value,
    type,
  }) {
    if (invalidValue) {
      setInvalid(preState => ({...preState, [type]: false}));
    }
    showInvalidForSpecific(ref, colors.grey);
    handleChange(type, value);
  }
}
