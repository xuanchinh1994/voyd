import React from 'react';
import {Text, TextInput, View, TouchableOpacity, Image} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {useDispatch} from 'react-redux';

import {Button, Icon, QRScan} from '../../components';
import {screens, errorCodes} from '../../assets/strings';
import BaseLayout from '../../layout';
import useInput from '../../tools/hooks/useInput';
import RegisterVM from './VM';
import styles from './styles';
import {SIGNUP} from '../../tools/api';
import {login as loginAction} from '../../redux/actions/auth';
import {showToast, hideToast} from '../../components/Toast';
import colors from '../../assets/colors';
import responsive from '../../tools/scale';
import Logo from '../../assets/images/logo.jpg';
import locale from '../../assets/locale.json';

function Register() {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(
    ['email', 'password', 'firstName', 'lastName', 'code'],
    ['email', 'password', 'firstName', 'lastName', 'code'],
  );

  const [toggle, setToggle] = React.useState(true);
  const [isLoading, setIsLoading] = React.useState(false);
  const [{password: customPasswordError}, setCustomError] = React.useState({
    password: '',
  });

  const dispatch = useDispatch();
  const navigation = useNavigation();

  const {email, password, firstName, lastName, code} = values;
  const {
    email: invalidEmail,
    password: invalidPassword,
    firstName: firstNameInvalid,
    lastName: lastNameInvalid,
    code: codeInvalid,
  } = invalid;

  const emailInputRef = React.useRef();
  const passwordInputRef = React.useRef();
  const firstNameInputRef = React.useRef();
  const lastNameInputRef = React.useRef();
  const codeInputRef = React.useRef();

  const emailRef = React.useRef();
  const passwordRef = React.useRef();
  const firstNameRef = React.useRef();
  const lastNameRef = React.useRef();
  const codeRef = React.useRef();

  const registerVM = React.useMemo(
    () =>
      new RegisterVM({
        refKeyValuePair: {
          email: emailRef,
          password: passwordRef,
          firstName: firstNameRef,
          lastName: lastNameRef,
          code: codeRef,
        },
      }),
    [],
  );

  const register = React.useCallback(async () => {
    try {
      setIsLoading(true);
      hideToast();
      const {data} = await SIGNUP({
        email,
        password,
        first_name: firstName,
        last_name: lastName,
        code,
      });
      setIsLoading(false);
      if (data?.success) {
        const access_token = data?.data?.access_token;
        const refresh_token = data?.data?.refresh_token;
        const userId = data?.data?.user_id || '';

        dispatch(
          loginAction({
            access_token,
            refresh_token,
            user: {email, firstName, lastName, userId},
          }),
        );
      } else {
        showToast({
          message: data?.message || locale.CouldNotRegisterAtTheMoment,
        });
      }
    } catch (error) {
      setIsLoading(false);
      const responseData = error.response.data;
      const code = responseData?.code;
      showToast({
        message:
          code === errorCodes.EMAIL_ADDRESS_ALREADY_EXIST
            ? locale.AccountAlreadyExists
            : code === errorCodes.CODE_DOES_NOT_EXIST
            ? locale.CodeInvalidOrDoesNotExists
            : locale.SomethingWentWrongTryAgain,
      });
    }
  }, [dispatch, email, firstName, lastName, password, code]);

  const handleSubmit = React.useCallback(() => {
    registerVM.handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      email,
      password,
      setCustomError,
      setInvalid,
      submit: register,
    });
  }, [
    showInvalidOnEmpty,
    checkIsEmpty,
    setInvalid,
    email,
    password,
    register,
    registerVM,
  ]);

  const handleEmailInputChange = React.useCallback(
    value => {
      registerVM.handleInputChange({
        invalidValue: invalidEmail,
        setInvalid,
        showInvalidForSpecific,
        ref: emailRef,
        handleChange,
        value: value?.trim(),
        type: 'email',
      });
    },
    [
      registerVM,
      invalidEmail,
      showInvalidForSpecific,
      handleChange,
      setInvalid,
      emailRef,
    ],
  );

  const handlePasswordInputChange = React.useCallback(
    value => {
      if (customPasswordError?.length) {
        setCustomError(previousState => ({...previousState, password: false}));
      }
      registerVM.handleInputChange({
        invalidValue: invalidPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: passwordRef,
        handleChange,
        value,
        type: 'password',
      });
    },
    [
      registerVM,
      invalidPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customPasswordError,
    ],
  );

  const handleFirstNameInputChange = React.useCallback(
    value =>
      registerVM.handleInputChange({
        invalidValue: firstNameInvalid,
        setInvalid,
        showInvalidForSpecific,
        ref: firstNameRef,
        handleChange,
        value,
        type: 'firstName',
      }),
    [
      registerVM,
      firstNameInvalid,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
    ],
  );

  const handleLastNameInputChange = React.useCallback(
    value =>
      registerVM.handleInputChange({
        invalidValue: lastNameInvalid,
        setInvalid,
        showInvalidForSpecific,
        ref: lastNameRef,
        handleChange,
        value,
        type: 'lastName',
      }),
    [
      registerVM,
      lastNameInvalid,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
    ],
  );
  const handleCodeInputChange = React.useCallback(
    value =>
      registerVM.handleInputChange({
        invalidValue: codeInvalid,
        setInvalid,
        showInvalidForSpecific,
        ref: codeRef,
        handleChange,
        value,
        type: 'code',
      }),
    [registerVM, codeInvalid, setInvalid, showInvalidForSpecific, handleChange],
  );

  const handlePasswordToggle = React.useCallback(() => {
    setToggle(preState => !preState);
  }, []);

  const isButtonDisabled = isLoading;

  const handleOnQRCodeScanSuccess = React.useCallback(
    qrCode => {
      handleCodeInputChange(qrCode);
    },
    [handleCodeInputChange],
  );

  return (
    <BaseLayout
      scrollChildren
      style={{
        padding: responsive.moderateScale(20),
      }}
      contentContainerStyle={{
        flexGrow: 1,
        justifyContent: 'center',
        paddingVertical: responsive.moderateScale(30),
      }}>
      <View>
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 50,
          }}>
          <Image source={Logo} style={styles.logo} resizeMode="contain" />
        </View>
        <Text
          style={{
            fontSize: 30,
            color: colors.primary,
          }}>
          {locale.Register}
        </Text>
        <View style={{marginTop: responsive.moderateScale(30)}} />
        <View>
          <Text style={styles.labelStyle}>{locale.Email}</Text>
          <View
            ref={ref => (emailRef.current = ref)}
            style={styles.inputViewStyle}>
            <TextInput
              ref={emailInputRef}
              textContentType="emailAddress"
              autoCapitalize="none"
              value={email}
              onSubmitEditing={() => passwordInputRef.current.focus()}
              onChangeText={handleEmailInputChange}
              style={styles.textInputStyles}
              editable={!isLoading}
            />
          </View>
          {invalid.email ? (
            <Text style={{color: colors.red, marginTop: 5}}>
              {locale.InvalidEmailAddress}
            </Text>
          ) : null}
        </View>
        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.Password}</Text>
          <View
            ref={ref => (passwordRef.current = ref)}
            style={{paddingRight: 10, ...styles.inputViewStyle}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <TextInput
                ref={passwordInputRef}
                textContentType="password"
                autoCapitalize="none"
                secureTextEntry={toggle}
                value={password}
                onChangeText={handlePasswordInputChange}
                onSubmitEditing={() => firstNameInputRef.current.focus()}
                style={{width: '90%', ...styles.textInputStyles}}
                editable={!isLoading}
              />
              <TouchableOpacity onPress={handlePasswordToggle}>
                <Text style={{fontSize: responsive.moderateScale(14)}}>
                  {toggle ? locale.Show : locale.Hide}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          {customPasswordError?.length > 0 ? (
            <Text style={{color: colors.red, marginTop: 5}}>
              {customPasswordError}
            </Text>
          ) : null}
        </View>
        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.FirstName}</Text>
          <View
            ref={ref => (firstNameRef.current = ref)}
            style={styles.inputViewStyle}>
            <View>
              <TextInput
                ref={firstNameInputRef}
                autoCapitalize="none"
                value={firstName}
                onChangeText={handleFirstNameInputChange}
                onSubmitEditing={() => lastNameInputRef.current.focus()}
                style={styles.textInputStyles}
                editable={!isLoading}
              />
            </View>
          </View>
        </View>

        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.LastName}</Text>
          <View
            ref={ref => (lastNameRef.current = ref)}
            style={styles.inputViewStyle}>
            <View>
              <TextInput
                ref={lastNameInputRef}
                autoCapitalize="none"
                value={lastName}
                onChangeText={handleLastNameInputChange}
                style={styles.textInputStyles}
                editable={!isLoading}
              />
            </View>
          </View>
        </View>
        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.Code}</Text>
          <View
            ref={ref => (codeRef.current = ref)}
            style={styles.inputViewStyle}>
            <View
              style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
              <TextInput
                ref={codeInputRef}
                autoCapitalize="none"
                value={code}
                onChangeText={handleCodeInputChange}
                style={[styles.textInputStyles, {flex: 1}]}
                editable={!isLoading}
              />
              <QRScan
                onSuccess={handleOnQRCodeScanSuccess}
                fromScreen={screens.REGISTER}>
                {({handleQRCodeScan}) => (
                  <TouchableOpacity
                    onPress={handleQRCodeScan}
                    style={{padding: 8}}>
                    <Icon name="qrCode" size={25} />
                  </TouchableOpacity>
                )}
              </QRScan>
            </View>
          </View>
        </View>

        <View style={{marginTop: responsive.moderateScale(30)}}>
          <Button
            text="Sign Up"
            onPress={handleSubmit}
            disabled={isButtonDisabled}
            loading={isButtonDisabled}
          />
          <TouchableOpacity
            onPress={() => navigation.navigate(screens.LOGIN)}
            style={{marginTop: responsive.moderateScale(20)}}>
            <Text
              style={{
                textAlign: 'center',
                ...styles.labelStyle,
                color: colors.primary,
              }}>
              {locale.AlreadyHaveAnAccount} {locale.Login}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </BaseLayout>
  );
}

export default Register;
