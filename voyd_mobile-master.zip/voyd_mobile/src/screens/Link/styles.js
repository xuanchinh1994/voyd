import {StyleSheet, Dimensions} from 'react-native';
const {width} = Dimensions.get('screen');

import colors from '../../assets/colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mainText: {
    fontSize: 26,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 20,
  },
  linkText: {
    borderWidth: 1,
    borderColor: colors.grey,
    marginTop: 5,
    minHeight: 45,
    borderRadius: 10,
    width: width - 50,
    paddingHorizontal: 15,
  },
  MainTextView: {
    paddingVertical: 20,
  },
  mainToolbar: {
    height: 40,
    backgroundColor: colors.white,
    width: width,
    borderBottomColor: colors.grey,
    borderBottomWidth: 0.5,
    flexDirection: 'row',
  },
  burgerIcon: {
    marginLeft: 20,
    marginTop: 10,
    transform: [{rotateY: '180deg'}],
  },
  notes: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: width - 50,
    borderRadius: 10,
    marginTop: 10,
    flexGrow: 1,
    flexDirection: 'row',
  },
  buttonDelete: {
    marginHorizontal: -100,
    marginTop: 20,
  },
  uploadIcon: {
    marginRight: 20,
  },
  buttonUpload: {
    marginLeft: 40,
    marginTop: 20,
  },
  noteText: {
    marginTop: 20,
    marginLeft: 15,
    width: width - 150,
    marginBottom: 30,
    fontSize: 14,
  },
  linkIcon: {
    marginRight: 10,
    marginTop: -2,
    transform: [{rotateY: '180deg'}],
  },
  createContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  createNotes: {
    marginTop: 30,
    backgroundColor: colors.red,
    width: width - 50,
    height: 50,
    alignItems: 'center',
    borderRadius: 10,
  },
  createNotesText: {
    marginTop: 15,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  titleText: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 15,
  },
  openLink: {
    alignItems: 'center',
    backgroundColor: colors.black,
    height: 50,
    justifyContent: 'center',
    borderRadius: 10,
    padding: 10,
    paddingHorizontal: 20,
    minWidth: 100,
  },
  openLinkText: {
    color: 'white',
    fontWeight: '500',
  },
  invalidText: {
    color: colors.red,
    fontSize: 14,
    marginVertical: 5,
  },
});

export default styles;
