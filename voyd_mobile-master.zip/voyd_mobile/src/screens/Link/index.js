import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import {useMutation, useQuery} from '@apollo/client';

import {Icon, Header, QRScan} from '../../components';
import BaseLayout from '../../layout/index';
import styles from './styles';
import {CREATE_LINK, DEACTIVATE_ALL_LINKS} from '../../apollo/mutations';
import {GET_LINK} from '../../apollo/queries';
import {showToast} from '../../components/Toast';
import locale from '../../assets/locale.json';
import colors from '../../assets/colors';
import {screens} from '../../assets/strings';
import {URLUtilities, openLink} from '../../tools/utils';
import InfoModal from '../../components/Modal/InfoModal';

const INITIAL_STATE = {
  state: false,
  data: {title: '', description: ''},
};

const Links = () => {
  const [url, setUrl] = useState('');
  const [invalidText, setInvalidText] = React.useState('');
  const [popup, setPopup] = React.useState(INITIAL_STATE);

  const {data, refetch} = useQuery(GET_LINK);

  const currentLink = data?.link?.data?.link;
  const hasLink = React.useMemo(
    () => data?.link?.success && data?.link?.data?.link?.length > 0,
    [data],
  );

  const [createLink, {loading}] = useMutation(CREATE_LINK);

  const handleSaveLink = React.useCallback(async () => {
    if (!url?.length) {
      setInvalidText(locale.ThisFieldIsRequired);
      return;
    }
    if (!URLUtilities.validateUrl(url)) {
      setInvalidText(locale.InvalidUrl);
      return;
    }
    try {
      const {data} = await createLink({
        variables: {
          link: url,
        },
      });
      const success = data?.createLink?.success;
      const code = data?.createLink?.code;
      if (success) {
        setUrl('');
        showToast({
          message: locale.LinkSent,
          type: 'success',
        });
      } else {
        const codeMapping = {
          IFRAME_BLOCKED: {
            title: locale.IframeBlocked,
            description: locale.IframeBlockedInfo,
          },
          INVALID_URL: {
            title: locale.InvalidUrl,
            description: locale.LinkInvalidOrNotAvailable,
          },
        };
        const mapped = codeMapping[code];
        if (mapped) {
          setPopup({
            state: true,
            data: {title: mapped.title, description: mapped.description},
          });
        } else {
          throw new Error();
        }
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
    } finally {
      refetch();
    }
  }, [createLink, url, refetch]);

  const handleTextChange = React.useCallback(text => {
    setInvalidText('');
    setUrl(text);
  }, []);

  const handleScanSuccess = React.useCallback(code => {
    setUrl(code);
  }, []);

  return (
    <BaseLayout contentContainerStyle={{flex: 0.7}}>
      <BaseLayout.Header>
        <Header logo left="back" noShadow />
      </BaseLayout.Header>
      <View style={styles.container}>
        <Icon name={'refresh'} size={40} />
        <Text style={styles.mainText}>{locale.linkMirror}</Text>
        <View style={styles.MainTextView}>
          <TextInput
            style={styles.linkText}
            numberOfLines={1}
            placeholder={locale.EnterYourLink}
            autoCapitalize={'none'}
            autoCorrect={false}
            onChangeText={handleTextChange}
            placeholderTextColor={colors.grey}
            value={url}
            editable={!loading}
          />
          {invalidText?.length ? (
            <Text style={styles.invalidText}>{invalidText}</Text>
          ) : null}
        </View>
        <TouchableOpacity style={styles.openLink} onPress={handleSaveLink}>
          {loading ? (
            <ActivityIndicator />
          ) : (
            <Text style={styles.openLinkText}>{locale.openLink}</Text>
          )}
        </TouchableOpacity>
        <QRScan fromScreen={screens.LINK_SCREEN} onSuccess={handleScanSuccess}>
          {({handleQRCodeScan}) => (
            <TouchableOpacity
              style={[styles.openLink, {marginTop: 20}]}
              onPress={handleQRCodeScan}>
              <Text style={styles.openLinkText}>{locale.ScanQRCode}</Text>
            </TouchableOpacity>
          )}
        </QRScan>
        {hasLink ? (
          <DeleteLink currentLink={currentLink} refetch={refetch} />
        ) : null}
      </View>
      <InfoModal
        height={200}
        popUp={popup}
        setVisible={() => {
          setPopup(INITIAL_STATE);
        }}
      />
    </BaseLayout>
  );
};

function DeleteLink({currentLink = '', refetch = () => null}) {
  const [deactivateAllLinks, {loading}] = useMutation(DEACTIVATE_ALL_LINKS);

  const handleDeleteLink = React.useCallback(async () => {
    try {
      const {data} = await deactivateAllLinks();
      const success = data?.deactivateAllLinks?.success;
      if (success) {
        showToast({
          message: locale.LinkDeleted,
          type: 'success',
        });
      } else {
        throw new Error();
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
    } finally {
      refetch();
    }
  }, [deactivateAllLinks, refetch]);

  return (
    <>
      <TouchableOpacity
        style={[styles.openLink, {marginTop: 20, backgroundColor: colors.red}]}
        onPress={handleDeleteLink}>
        {loading ? (
          <ActivityIndicator />
        ) : (
          <Text style={styles.openLinkText}>{locale.DeleteLink}</Text>
        )}
      </TouchableOpacity>
      <Text
        style={{
          marginVertical: 10,
          backgroundColor: colors.darkGrey,
          padding: 5,
        }}
        onPress={openLink.bind(this, currentLink)}>
        {currentLink}
      </Text>
    </>
  );
}

export default Links;
