import React from 'react';
import {Text, TextInput, View, TouchableOpacity} from 'react-native';
import {useDispatch} from 'react-redux';

import {Button, Header} from '../../components';
import BaseLayout from '../../layout';
import useInput from '../../tools/hooks/useInput';
import ChangePasswordViewModel from './VM';
import {CHANGE_PASSWORD} from '../../tools/api';
import {showToast, hideToast} from '../../components/Toast';
import styles from './styles';
import {logout} from '../../redux/actions/auth';
import responsive from '../../tools/scale';
import locale from '../../assets/locale.json';

export default function ResetPassword() {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(
    ['oldPassword', 'password', 'confirmPassword'],
    ['oldPassword', 'password', 'confirmPassword'],
  );

  const [toggle, setToggle] = React.useState(true);
  const [toggle2, setToggle2] = React.useState(true);
  const [toggle3, setToggle3] = React.useState(true);

  const [isLoading, setIsLoading] = React.useState(false);
  const [
    {
      password: customPasswordError,
      confirmPassword: customConfirmPasswordError,
      oldPassword: customOldPasswordError,
    },
    setCustomError,
  ] = React.useState({
    password: '',
    confirmPassword: '',
    oldPassword: '',
  });

  const dispatch = useDispatch();

  const passwordInputRef = React.useRef();
  const confirmPasswordInputRef = React.useRef();
  const oldPasswordInputRef = React.useRef();
  const passwordRef = React.useRef();
  const confirmPasswordRef = React.useRef();
  const oldPasswordRef = React.useRef();

  const {oldPassword, password, confirmPassword} = values;
  const {
    password: invalidPassword,
    confirmPassword: invalidConfirmPassword,
    oldPassword: invalidOldPassword,
  } = invalid;

  const resetVM = React.useMemo(
    () =>
      new ChangePasswordViewModel({
        refKeyValuePair: {
          password: passwordRef,
          confirmPassword: confirmPasswordRef,
          oldPassword: oldPasswordRef,
        },
      }),
    [],
  );

  const reset = React.useCallback(async () => {
    try {
      hideToast();
      setIsLoading(true);

      const {data} = await CHANGE_PASSWORD({
        old_password: oldPassword,
        new_password: password,
      });
      setIsLoading(false);
      if (data?.success) {
        dispatch(logout({doesUserChangedPassword: true}));
      } else {
        showToast({
          message: data?.message || "Couldn't change password at the moment.",
        });
      }
    } catch (error) {
      setIsLoading(false);
      // console.log({error});

      showToast({
        message:
          error?.response?.data?.message || 'Something went wrong. Try again',
      });
    }
  }, [password, oldPassword, dispatch]);

  const handleSubmit = React.useCallback(() => {
    resetVM.handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      password,
      confirmPassword,
      submit: reset,
      setCustomError,
    });
  }, [
    resetVM,
    checkIsEmpty,
    showInvalidOnEmpty,
    password,
    confirmPassword,
    reset,
  ]);

  const handlePasswordInputChange = React.useCallback(
    value => {
      if (customPasswordError?.length) {
        setCustomError(previousState => ({...previousState, password: false}));
      }
      resetVM.handleInputChange({
        invalidValue: invalidPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: passwordRef,
        handleChange,
        value,
        type: 'password',
      });
    },
    [
      resetVM,
      invalidPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customPasswordError,
    ],
  );
  const handleOldPasswordInputChange = React.useCallback(
    value => {
      if (customOldPasswordError?.length) {
        setCustomError(previousState => ({
          ...previousState,
          oldPassword: false,
        }));
      }
      resetVM.handleInputChange({
        invalidValue: invalidOldPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: oldPasswordRef,
        handleChange,
        value,
        type: 'oldPassword',
      });
    },
    [
      resetVM,
      invalidOldPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customOldPasswordError,
    ],
  );
  const handlePassword2InputChange = React.useCallback(
    value => {
      if (customConfirmPasswordError?.length) {
        setCustomError(previousState => ({
          ...previousState,
          confirmPassword: false,
        }));
      }
      resetVM.handleInputChange({
        invalidValue: invalidConfirmPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: confirmPasswordRef,
        handleChange,
        value,
        type: 'confirmPassword',
      });
    },
    [
      resetVM,
      invalidConfirmPassword,
      setInvalid,
      showInvalidForSpecific,
      handleChange,
      customConfirmPasswordError,
    ],
  );

  const handlePasswordToggle = React.useCallback(() => {
    setToggle(preState => !preState);
  }, []);
  const handlePasswordToggle2 = React.useCallback(() => {
    setToggle2(preState => !preState);
  }, []);
  const handleOldPasswordToggle = React.useCallback(() => {
    setToggle3(preState => !preState);
  }, []);

  return (
    <BaseLayout
      contentContainerStyle={{
        justifyContent: 'center',
        flexGrow: 1,
      }}
      headerContainerStyle={{zIndex: 1000}}>
      <BaseLayout.Header>
        <Header left="back" noShadow logo />
      </BaseLayout.Header>
      <View style={{flex: 1, padding: responsive.moderateScale(20)}}>
        <Text style={{fontSize: responsive.moderateScale(30, 0.1)}}>
          {locale.ChangePassword}
        </Text>
        <View style={{marginTop: responsive.moderateScale(30)}}>
          <Text style={styles.labelStyle}>{locale.OldPassword}</Text>
          <View
            ref={ref => (oldPasswordRef.current = ref)}
            style={styles.inputViewStyle}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <TextInput
                ref={oldPasswordInputRef}
                textContentType="password"
                autoCapitalize="none"
                secureTextEntry={toggle3}
                value={values.oldPassword}
                onChangeText={handleOldPasswordInputChange}
                onSubmitEditing={() => passwordInputRef.current.focus()}
                style={{width: '80%', ...styles.textInputStyles}}
              />
              <TouchableOpacity onPress={handleOldPasswordToggle}>
                <Text style={{fontSize: responsive.moderateScale(14)}}>
                  {toggle3 ? locale.Show : locale.Hide}
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {customOldPasswordError?.length > 0 ? (
            <Text style={{color: 'tomato'}}>{customOldPasswordError}</Text>
          ) : null}
        </View>

        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.NewPassword}</Text>
          <View
            ref={ref => (passwordRef.current = ref)}
            style={styles.inputViewStyle}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <TextInput
                ref={passwordInputRef}
                textContentType="password"
                autoCapitalize="none"
                secureTextEntry={toggle}
                value={values.password}
                onChangeText={handlePasswordInputChange}
                onSubmitEditing={() => confirmPasswordInputRef.current.focus()}
                style={{width: '80%', ...styles.textInputStyles}}
              />
              <TouchableOpacity onPress={handlePasswordToggle}>
                <Text style={{fontSize: responsive.moderateScale(14)}}>
                  {toggle ? locale.Show : locale.Hide}
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {customPasswordError?.length > 0 ? (
            <Text style={{color: 'tomato'}}>{customPasswordError}</Text>
          ) : null}
        </View>

        <View style={{marginTop: responsive.moderateScale(10)}}>
          <Text style={styles.labelStyle}>{locale.ConfirmNewPassword}</Text>
          <View
            ref={ref => (confirmPasswordRef.current = ref)}
            style={styles.inputViewStyle}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <TextInput
                ref={confirmPasswordInputRef}
                textContentType="password"
                autoCapitalize="none"
                secureTextEntry={toggle2}
                value={values.confirmPassword}
                onChangeText={handlePassword2InputChange}
                onSubmitEditing={handleSubmit}
                style={{width: '80%', ...styles.textInputStyles}}
              />
              <TouchableOpacity onPress={handlePasswordToggle2}>
                <Text style={{fontSize: responsive.moderateScale(14)}}>
                  {toggle2 ? locale.Show : locale.Hide}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          {customConfirmPasswordError?.length > 0 ? (
            <Text style={{color: 'tomato'}}>{customConfirmPasswordError}</Text>
          ) : null}
        </View>

        {invalid.password ? (
          <Text
            style={{color: 'tomato', fontSize: responsive.moderateScale(14)}}>
            {locale.PasswordsDoNotMatch}
          </Text>
        ) : null}

        <View style={{marginTop: responsive.moderateScale(50)}}>
          <Button
            text="Submit"
            onPress={handleSubmit}
            disabled={isLoading}
            loading={isLoading}
          />
        </View>
      </View>
    </BaseLayout>
  );
}
