import colors from '../../assets/colors';

export default class ChangePasswordViewModel {
  constructor({refKeyValuePair}) {
    this.refKeyValuePair = refKeyValuePair;
  }

  handleFormSubmit({
    checkIsEmpty,
    showInvalidOnEmpty,
    submit,
    password,
    confirmPassword,
    setCustomError,
  }) {
    if (checkIsEmpty[1]) {
      showInvalidOnEmpty(this.refKeyValuePair);
      return;
    }

    if (password.length < 6) {
      setCustomError(previousState => ({
        ...previousState,
        password: 'Password should be at least 6 characters long.',
      }));
      return;
    }
    if (password !== confirmPassword) {
      setCustomError(previousState => ({
        ...previousState,
        confirmPassword: 'New passwords do not match',
      }));
      return;
    }
    submit();
  }

  handleInputChange({
    invalidValue,
    setInvalid,
    showInvalidForSpecific,
    ref,
    handleChange,
    value,
    type,
  }) {
    if (invalidValue) {
      setInvalid(preState => ({...preState, [type]: false}));
    }
    showInvalidForSpecific(ref, colors.grey);
    handleChange(type, value);
  }
}
