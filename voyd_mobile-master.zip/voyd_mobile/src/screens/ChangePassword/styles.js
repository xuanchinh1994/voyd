import {StyleSheet} from 'react-native';

import colors from '../../assets/colors';

export default StyleSheet.create({
  textInputStyles: {
    color: colors.black,
    fontSize: 14,
  },
  footerStyle: {padding: 20},
  inputViewStyle: {
    borderWidth: 1,
    borderColor: colors.grey,
    borderRadius: 10,
    padding: 14,
  },
  labelStyle: {
    fontSize: 16,
    marginBottom: 10,
  },
});
