import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import {useQuery} from '@apollo/client';
import {useNavigation} from '@react-navigation/native';
import {useFocusEffect} from '@react-navigation/native';
import {useMutation} from '@apollo/client';

import {Icon, Header} from '../../components';
import styles from './styles';
import {GET_ALL_NOTES} from '../../apollo/queries';
import {screens} from '../../assets/strings';
import locale from '../../assets/locale.json';
import BaseLayout from '../../layout';
import {DELETE_NOTE} from '../../apollo/mutations';
import {showToast} from '../../components/Toast';

const Notes = () => {
  const navigation = useNavigation();

  const {loading, data, refetch} = useQuery(GET_ALL_NOTES);

  const allNotes = React.useMemo(() => data?.getAllNotes?.data, [data]);

  useFocusEffect(
    React.useCallback(() => {
      refetch?.();
    }, [refetch]),
  );

  return (
    <BaseLayout contentContainerStyle={{flex: 1}} scrollChildren={false}>
      <BaseLayout.Header>
        <Header
          logo
          left="back"
          noShadow
          right={{
            icon: {
              name: 'plus',
            },
            action: navigation.navigate.bind(this, screens.CREATE_NOTE, {
              id: null,
              message: '',
            }),
          }}
        />
      </BaseLayout.Header>
      <View style={styles.container}>
        <View
          style={{
            flexDirection: 'row',
            marginTop: 10,
            alignItems: 'center',
          }}>
          <Icon
            style={{color: 'black', flex: 1}}
            name="notes"
            size={30}
            tint={'black'}
          />
          <Text style={styles.notesTitle}>{locale.Notes}</Text>
        </View>
        {data ? (
          Array.isArray(allNotes) && allNotes?.length ? (
            <AllNotes data={allNotes} refetch={refetch} />
          ) : (
            <View style={styles.fullScreen}>
              <Text>{locale.LooksLikeItsEmpty}</Text>
            </View>
          )
        ) : loading ? (
          <View style={styles.fullScreen}>
            <ActivityIndicator />
          </View>
        ) : null}
      </View>
    </BaseLayout>
  );
};

function AllNotes({data = [], refetch = () => null}) {
  const [refreshing, setRefreshing] = React.useState(false);

  const handleRefresh = React.useCallback(async () => {
    try {
      setRefreshing(true);
      await refetch?.();
    } catch (_) {
    } finally {
      setRefreshing(false);
    }
  }, [refetch]);

  return (
    <FlatList
      contentContainerStyle={{marginTop: 20}}
      data={data}
      renderItem={({item}) => <Note item={item} refetch={refetch} />}
      showsVerticalScrollIndicator={false}
      keyExtractor={item => item?.id}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
      }
    />
  );
}

function Note({item: data, refetch = () => null}) {
  const navigation = useNavigation();
  const [loading, setLoading] = React.useState(false);

  const [deleteNote] = useMutation(DELETE_NOTE);

  const handleDelete = React.useCallback(async () => {
    try {
      setLoading(true);
      const {data: response} = await deleteNote({
        variables: {
          id: data?.id,
        },
      });
      const success = response?.deleteNote?.success;
      if (!success) {
        throw new Error();
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
      setLoading(false);
    } finally {
      await refetch?.();
    }
  }, [deleteNote, data?.id, refetch]);

  return (
    <View style={[styles.notes, {opacity: loading ? 0.5 : 1}]}>
      <Text style={styles.noteText}>{data?.message}</Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <TouchableOpacity onPress={handleDelete} disabled={loading}>
          <Icon name="delete" />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() =>
            navigation.navigate(screens.CREATE_NOTE, {
              id: data?.id,
              message: data?.message,
            })
          }
          disabled={loading}>
          <Icon name="edit" style={{marginLeft: 10}} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default Notes;
