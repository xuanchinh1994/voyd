import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {useMutation} from '@apollo/client';
import {useNavigation, useRoute} from '@react-navigation/native';

import {Icon, Header} from '../../components';
import styles from './styles';
import {CREATE_NOTE, UPDATE_NOTE} from '../../apollo/mutations';
import {showToast} from '../../components/Toast';
import BaseLayout from '../../layout';
import locale from '../../assets/locale.json';

const CreateNotes = () => {
  const route = useRoute();
  const navigation = useNavigation();

  const params = route?.params;
  const id = params?.id;
  const oldMessage = params?.message;

  const isUpdate = id ?? false;

  const [createNote, {loading: createLoading}] = useMutation(CREATE_NOTE);
  const [updateNote, {loading: updateLoading}] = useMutation(UPDATE_NOTE);

  const [message, setMessage] = useState(
    isUpdate && oldMessage?.length > 0 ? oldMessage : '',
  );
  const [invalidText, setInvalidText] = React.useState('');

  const handleSubmit = React.useCallback(async () => {
    if (!message?.length) {
      setInvalidText(locale.ThisFieldIsRequired);
      return;
    }
    try {
      const {data} = await (isUpdate
        ? updateNote({
            variables: {
              message,
              id,
            },
          })
        : createNote({
            variables: {
              message,
            },
          }));
      const success = data?.[isUpdate ? 'updateNote' : 'createNote']?.success;
      if (success) {
        navigation.goBack();
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
    }
  }, [message, isUpdate, updateNote, createNote, navigation, id]);

  return (
    <BaseLayout>
      <BaseLayout.Header>
        <Header logo left="back" noShadow />
      </BaseLayout.Header>

      <View style={styles.createContainer}>
        <View
          style={{
            flexDirection: 'row',
            marginTop: 30,
            alignSelf: 'flex-start',
          }}>
          <Icon
            style={{
              color: 'black',
              flex: 1,
            }}
            name="notes"
            size={30}
            tint={'black'}
          />
          <Text
            style={{
              fontSize: 20,
              marginLeft: 10,
              fontWeight: '700',
              marginTop: 5,
            }}>
            {isUpdate ? locale.UpdateNote : locale.CreateNote}
          </Text>
        </View>
        <TextInput
          style={styles.enterTextArea}
          multiline={true}
          textAlignVertical={'top'}
          placeholder={locale.TypeSomething}
          onChangeText={text => setMessage(text)}
          value={message}
        />
        {invalidText?.length ? (
          <Text style={styles.invalidText}>{invalidText}</Text>
        ) : null}
        <TouchableOpacity style={styles.createNotes} onPress={handleSubmit}>
          {createLoading || updateLoading ? (
            <ActivityIndicator />
          ) : (
            <Text style={styles.createNotesText}>
              {isUpdate ? locale.Update : locale.Add}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </BaseLayout>
  );
};

export default CreateNotes;
