import React from 'react';
import {StyleSheet, View, ActivityIndicator} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  useAnimatedScrollHandler,
  interpolate,
} from 'react-native-reanimated';
import {useQuery} from '@apollo/react-hooks';

import {GET_STEPS_IMAGES} from '../../apollo/queries/index';
import {Header} from '../../components';
import useWindowDimensions from '../../tools/hooks/useWindowDimensions';
import colors from '../../assets/colors';
import {URLUtilities} from '../../tools/utils';
import BaseLayout from '../../layout';
import locale from '../../assets/locale.json';

function AppIntro({slides = []}) {
  const [currentIndex, setCurrentIndex] = React.useState(0);

  const scrollRef = React.useRef();

  const translateX = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler(event => {
    const scrollX = event.contentOffset.x;
    translateX.value = scrollX;
  });

  return (
    <BaseLayout scrollChildren={false}>
      <BaseLayout.Header>
        <Header
          left="back"
          noShadow
          title={`${locale.Step} ${currentIndex + 1}`}
        />
      </BaseLayout.Header>
      <Animated.ScrollView
        ref={scrollRef}
        style={{flex: 1}}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        onScroll={scrollHandler}
        onMomentumScrollEnd={evt => {
          let xOffset = evt.nativeEvent.contentOffset.x;
          let contentWidth = evt.nativeEvent.layoutMeasurement.width;
          let value = xOffset / contentWidth;
          if (currentIndex !== value) {
            setCurrentIndex(parseInt(value));
          }
        }}>
        {slides?.map((item, index) => (
          <PageView
            item={item}
            index={index}
            translateX={translateX}
            key={item?.key}
          />
        ))}
      </Animated.ScrollView>
      <View style={styles.dotsContainer}>
        {new Array(slides.length)?.fill(100)?.map((_, index) => (
          <View
            key={index?.toString()}
            style={[styles.dot, {opacity: currentIndex === index ? 1 : 0.5}]}
          />
        ))}
      </View>
    </BaseLayout>
  );
}

function PageView({item, index = 0, translateX}) {
  const {
    window: {width, height},
  } = useWindowDimensions();

  const animatedScale = useAnimatedStyle(() => {
    const interpolatedScale = interpolate(
      translateX.value,
      [(index - 1) * width, index * width, (index + 1) * width],
      [0.8, 1, 0.8],
    );
    return {transform: [{scale: interpolatedScale}]};
  });

  return (
    <Animated.View
      style={[
        styles.slide,
        {
          width,
          zIndex: 100000,
          justifyContent: 'center',
          alignItems: 'center',
          flex: 1,
          height: 0.8 * height,
        },
        animatedScale,
      ]}
      key={item?.key}>
      {item?.background ? (
        <Animated.Image
          style={[{width, height: 0.7 * height}, styles.background]}
          source={{uri: item?.background}}
          resizeMode="contain"
        />
      ) : null}
    </Animated.View>
  );
}

function withStepsImages(WrappedComponent = null) {
  return function (...props) {
    const {data} = useQuery(GET_STEPS_IMAGES, {
      fetchPolicy: 'no-cache',
    });
    const images = data?.getStepsImages?.data;

    return Array.isArray(images) ? (
      <WrappedComponent
        {...props}
        slides={images?.map((item, index) => ({
          key: index,
          background: URLUtilities.mergeWithDomain(item),
        }))}
      />
    ) : (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator />
      </View>
    );
  };
}

export default withStepsImages(AppIntro);

const styles = StyleSheet.create({
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  skipText: {
    fontSize: 18,
    color: colors.black,
    opacity: 0.5,
  },
  background: {
    zIndex: -1,
    flex: 1,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8,
    backgroundColor: colors.grey,
    marginHorizontal: 3,
  },
  dotsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
