import {StyleSheet, Dimensions} from 'react-native';

const {width} = Dimensions.get('screen');

export const styles = StyleSheet.create({
  mainToolbar: {
    height: 50,
    backgroundColor: 'white',
    width: width,
    borderBottomColor: 'grey',
    borderBottomWidth: 0.5,
    flexDirection: 'row',
  },
  burgerIcon: {
    marginLeft: 20,
    marginTop: 15,
  },
  titleText: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
  },
  card: {
    borderColor: 'black',
    borderWidth: 2,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 150,
    minWidth: width / 2 - 30,
    margin: 10,
  },
});

export default styles;
