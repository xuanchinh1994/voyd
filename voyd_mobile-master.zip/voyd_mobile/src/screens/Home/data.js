import {screens} from '../../assets/strings';
import locale from '../../assets/locale.json';

module.exports = {
  data: [
    {
      id: 1,
      name: locale.Link,
      tabName: 'link',
      navigation: screens.LINK_SCREEN,
    },
    {
      id: 2,
      name: locale.Notes,
      tabName: 'notes',
      navigation: screens.NOTES,
    },

    {
      id: 5,
      name: locale.Image,
      tabName: 'image',
      navigation: screens.IMAGES,
    },
    {
      id: 6,
      name: locale.Calendar,
      tabName: 'calendar',
      navigation: screens.CALENDAR,
    },
    {
      id: 3,
      name: locale.Profile,
      tabName: 'user',
      navigation: screens.PROFILE,
    },
    {
      id: 4,
      name: locale.Settings,
      tabName: 'gear',
      navigation: screens.SETTINGS,
    },
    // {
    //   id: 4,
    //   name: locale.Setup,
    //   tabName: 'gear',
    //   navigation: screens.CONNECTIONS,
    // },
  ],
};
