import React from 'react';
import {Text, TouchableOpacity, FlatList} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {useFocusEffect} from '@react-navigation/native';

import BaseLayout from '../../layout';
import MainScreenItems from './data';
import {Header, Icon} from '../../components';
import styles from './styles';
import {withCalendarPermission} from '../../components/HOC';
import useCalendarEvents from '../Calendar/useCalendarEvents';

const Home = ({calendarPermissionGranted, setCalendarPermissionGranted}) => {
  const navigation = useNavigation();

  const {syncCalendar} = useCalendarEvents(
    true,
    calendarPermissionGranted,
    setCalendarPermissionGranted,
  );

  useFocusEffect(
    React.useCallback(() => {
      if (calendarPermissionGranted) {
        syncCalendar();
      }
    }, [calendarPermissionGranted, syncCalendar]),
  );

  return (
    <BaseLayout scrollChildren={false}>
      <BaseLayout.Header>
        <Header
          noShadow
          logo
          left={{
            action: navigation.toggleDrawer.bind(this),
            icon: {
              name: 'hamburger',
            },
          }}
        />
      </BaseLayout.Header>
      <FlatList
        contentContainerStyle={{
          flex: 1,
          marginTop: 30,
          alignItems: 'center',
        }}
        data={MainScreenItems.data}
        renderItem={({item}) => (
          <TouchableOpacity
            style={styles.card}
            key={item?.id?.toString?.()}
            onPress={() => {
              navigation.navigate(item.navigation);
            }}>
            <Icon name={item.tabName} size={36} />
            <Text style={{fontSize: 18, fontWeight: 'bold', marginTop: 20}}>
              {item.name}
            </Text>
          </TouchableOpacity>
        )}
        showsVerticalScrollIndicator={false}
        numColumns={2}
        keyExtractor={(_, index) => index.toString()}
      />
    </BaseLayout>
  );
};

export default withCalendarPermission(Home, true, false);
