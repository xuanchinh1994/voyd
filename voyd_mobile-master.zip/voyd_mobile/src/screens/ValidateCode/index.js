import React from 'react';
import {
  Text,
  View,
  ActivityIndicator,
  TouchableOpacity,
  Image,
} from 'react-native';
import {useNavigation, useRoute} from '@react-navigation/native';
import OTPInput from '@twotalltotems/react-native-otp-input';

import {CONFIRM_RESET_PIN} from '../../tools/api';
import {showToast, hideToast} from '../../components/Toast';
import {screens} from '../../assets/strings';
import locale from '../../assets/locale.json';
import styles from './styles';
import colors from '../../assets/colors';
import BaseLayout from '../../layout';
import Logo from '../../assets/images/logo.jpg';
import responsive from '../../tools/scale';

export default function ValidateCode() {
  const navigation = useNavigation();
  const [loading, setLoading] = React.useState(false);

  const route = useRoute();

  const navigate = route?.params?.navigate;
  const email = route?.params?.email;

  React.useEffect(() => {
    if (navigate?.message?.length > 0) {
      showToast({
        type: navigate?.success ? 'success' : 'error',
        message: navigate?.message,
      });
    }
  }, [navigate]);

  const submit = React.useCallback(
    async code => {
      try {
        hideToast();
        setLoading(true);

        const {data} = await CONFIRM_RESET_PIN({
          code,
          email,
        });
        if (data?.success) {
          navigation.navigate(screens.RESET_PASSWORD, {
            resetCode: code,
            email,
          });
        } else {
          showToast({
            message: data?.message || locale.InvalidCode,
          });
        }
        setLoading(false);
      } catch (error) {
        console.log(JSON.stringify({error}, null, 2));
        console.log(error?.response?.data);
        showToast({
          message:
            error?.response?.data?.message || locale.SomethingWentWrongTryAgain,
        });
        setLoading(false);
      }
    },
    [navigation, email],
  );

  return (
    <BaseLayout
      contentContainerStyle={{
        paddingHorizontal: responsive.moderateScale(20),
        height: '100%',
        alignItems: 'center',
      }}>
      <View style={{flex: 1}}>
        <View style={styles.logoContainer}>
          <Image source={Logo} style={styles.logo} />
        </View>
        <View style={{flex: 1}}>
          <Text style={styles.title}>{locale.ConfirmationCode}</Text>
          <OTPInput
            style={styles.otpField}
            pinCount={8}
            codeInputFieldStyle={styles.underlineStyleBase}
            codeInputHighlightStyle={styles.underlineStyleHighLighted}
            onCodeFilled={submit}
          />
          <View style={{flex: 0.1}} />
          {loading ? (
            <ActivityIndicator color={colors.primary} size="large" />
          ) : null}

          <View>
            <TouchableOpacity
              onPress={() => navigation.navigate(screens.LOGIN)}>
              <Text
                style={{
                  textAlign: 'center',
                  marginTop: 15,
                  ...styles.labelStyle,
                  color: colors.primary,
                }}>
                {locale.BackToLogin}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </BaseLayout>
  );
}
