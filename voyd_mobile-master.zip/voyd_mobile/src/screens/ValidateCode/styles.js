import {StyleSheet} from 'react-native';
import colors from '../../assets/colors';
import responsive from '../../tools/scale';

const styles = StyleSheet.create({
  otpField: {
    height: 20,
    marginTop: 25,
    marginBottom: 30,
  },
  underlineStyleBase: {
    width: 30,
    height: 45,
    color: colors.black,
    borderWidth: 0,
    borderBottomWidth: 1.5,
    fontSize: 18,
  },
  underlineStyleHighLighted: {
    borderColor: colors.black,
  },
  logoContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  logo: {
    width: 200,
    height: 67.4,
  },
  labelStyle: {
    fontSize: 16,
  },
  title: {fontSize: 25, color: colors.primary},
});
export default styles;
