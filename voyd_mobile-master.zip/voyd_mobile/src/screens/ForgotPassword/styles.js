import {StyleSheet} from 'react-native';

import colors from '../../assets/colors';

export default StyleSheet.create({
  textInputStyles: {
    color: colors.black,
    fontSize: 14,
  },
  footerStyle: {padding: 20},
  inputViewStyle: {
    borderWidth: 1,
    borderColor: colors.grey,
    borderRadius: 10,
    marginVertical: 5,
    padding: 14,
  },
  labelStyle: {
    fontSize: 16,
  },
  logoContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.5,
  },
  logo: {
    width: 200,
    height: 67.4,
  },
});
