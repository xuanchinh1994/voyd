import React from 'react';
import {Text, TextInput, View, TouchableOpacity, Image} from 'react-native';
import {useNavigation} from '@react-navigation/native';

import {screens, errorCodes} from '../../assets/strings';
import {Button} from '../../components';
import BaseLayout from '../../layout';
import useInput from '../../tools/hooks/useInput';
import ForgotVM from './VM';
import {FORGOT_PASSWORD} from '../../tools/api';
import {showToast, hideToast} from '../../components/Toast';
import styles from './styles';
import colors from '../../assets/colors';
import Logo from '../../assets/images/logo.jpg';
import locale from '../../assets/locale.json';
import {withAccountVerificationAlert} from '../../components/HOC';

function ForgotPassword({showAccountNotVerifiedAlert = () => null}) {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(['email'], ['email']);

  const navigation = useNavigation();

  const {email} = values;
  const {email: invalidEmail} = invalid;

  const emailInputRef = React.useRef();
  const emailRef = React.useRef();

  const [isLoading, setIsLoading] = React.useState(false);

  const forgotVM = React.useMemo(
    () =>
      new ForgotVM({
        refKeyValuePair: {
          email: emailRef,
        },
      }),
    [],
  );

  const handleForgotPassword = React.useCallback(async () => {
    setIsLoading(true);
    hideToast();
    try {
      const {data} = await FORGOT_PASSWORD({
        email,
      });
      setIsLoading(false);
      if (data?.success) {
        navigation.navigate(screens.VALIDATE_CODE, {
          navigate: {
            success: true,
            message: locale.AConfirmationCodeIsSentToYourInbox,
          },
          email,
        });
      } else {
        const code = data?.code;
        if (code === errorCodes.ACCOUNT_NOT_VERIFIED) {
          showAccountNotVerifiedAlert(email);
        } else {
          showToast({
            message: data?.message || locale.SomethingWentWrongTryAgain,
          });
        }
      }
    } catch (error) {
      setIsLoading(false);
      const responseData = error.response.data;
      const code = responseData?.code;
      showToast({
        message:
          code === errorCodes.ACCOUNT_DOES_NOT_EXISTS
            ? locale.AccountDoesNotExists
            : locale.SomethingWentWrongTryAgain,
      });
    }
  }, [email, navigation, showAccountNotVerifiedAlert]);

  const handleSubmit = React.useCallback(() => {
    forgotVM.handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      email,
      setInvalid,
      submit: handleForgotPassword,
    });
  }, [
    forgotVM,
    checkIsEmpty,
    showInvalidOnEmpty,
    email,
    setInvalid,
    handleForgotPassword,
  ]);

  const handleEmailInputChange = React.useCallback(
    value =>
      forgotVM.handleInputChange({
        invalidValue: invalidEmail,
        setInvalid,
        showInvalidForSpecific,
        ref: emailRef,
        handleChange,
        value,
        type: 'email',
      }),
    [forgotVM, invalidEmail, setInvalid, showInvalidForSpecific, handleChange],
  );

  return (
    <BaseLayout
      style={{padding: 20}}
      contentContainerStyle={{
        height: '100%',
        justifyContent: 'center',
      }}>
      <View style={{flex: 1}}>
        <View style={styles.logoContainer}>
          <Image source={Logo} style={styles.logo} resizeMode="contain" />
        </View>
        <View style={{flex: 1}}>
          <Text
            style={{
              fontSize: 30,
              color: colors.primary,
            }}>
            {locale.ForgotPassword}
          </Text>

          <View style={{marginTop: 30}}>
            <Text style={styles.labelStyle}>{locale.Email}</Text>
            <View
              ref={ref => (emailRef.current = ref)}
              style={styles.inputViewStyle}>
              <TextInput
                ref={emailInputRef}
                textContentType="emailAddress"
                autoCapitalize="none"
                value={values.email}
                onSubmitEditing={handleSubmit}
                onChangeText={handleEmailInputChange}
                style={styles.textInputStyles}
                placeholder={locale.EnterYourEmail}
              />
            </View>
            {invalid.email ? (
              <Text style={{color: 'tomato'}}>
                {locale.InvalidEmailAddress}
              </Text>
            ) : null}
          </View>

          <View style={{marginTop: 50}}>
            <Button
              text="Submit"
              onPress={handleSubmit}
              disabled={isLoading}
              loading={isLoading}
            />
            <TouchableOpacity
              onPress={() => navigation.navigate(screens.LOGIN)}>
              <Text
                style={{
                  textAlign: 'center',
                  marginTop: 15,
                  color: colors.primary,
                }}>
                {locale.BackToLogin}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </BaseLayout>
  );
}

export default withAccountVerificationAlert(ForgotPassword);
