import React from 'react';
import {Text, TextInput, View, TouchableOpacity, Image} from 'react-native';
import {useNavigation, useRoute} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';

import {screens, errorCodes} from '../../assets/strings';
import locale from '../../assets/locale.json';
import {Button} from '../../components';
import BaseLayout from '../../layout';
import useInput from '../../tools/hooks/useInput';
import LoginVM from './VM';
import styles from './styles';
import {colors} from '../../assets';
import Logo from '../../assets/images/logo.jpg';
import {hideToast, showToast} from '../../components/Toast';
import {LOGIN} from '../../tools/api';
import {login as loginAction, logout} from '../../redux/actions/auth';
import responsive from '../../tools/scale';

function Login() {
  const {
    values,
    handleChange,
    invalid,
    setInvalid,
    checkIsEmpty,
    showInvalidOnEmpty,
    showInvalidForSpecific,
  } = useInput(['email', 'password'], ['email', 'password']);

  const {email, password} = values;
  const {email: invalidEmail, password: invalidPassword} = invalid;

  const [toggle, setToggle] = React.useState(true);
  const [isLoading, setIsLoading] = React.useState(false);
  const dispatch = useDispatch();

  const navigation = useNavigation();
  const route = useRoute();

  const navigate = route?.params?.navigate;

  const emailInputRef = React.useRef();
  const passwordInputRef = React.useRef();
  const emailRef = React.useRef();
  const passwordRef = React.useRef();

  const loginVM = new LoginVM({
    refKeyValuePair: {email: emailRef, password: passwordRef},
    email: email,
    password: password,
  });
  const {handleFormSubmit, handleInputChange} = loginVM;
  const _handleFormSubmit = handleFormSubmit.bind(loginVM);
  const _handleInputChange = handleInputChange.bind(loginVM);

  React.useEffect(() => {
    if (navigate?.message?.length > 0) {
      showToast({
        type: navigate?.success ? 'success' : 'error',
        message: navigate?.message,
      });
    }
  }, [navigate]);

  const login = React.useCallback(async () => {
    hideToast();
    setIsLoading(true);
    try {
      const {data} = await LOGIN({email, password});
      setIsLoading(false);
      if (data?.success) {
        const access_token = data?.data?.access_token;
        const refresh_token = data?.data?.refresh_token;
        const firstName = data?.data?.first_name || '';
        const lastName = data?.data?.last_name || '';
        const userId = data?.data?.user_id || '';

        dispatch(
          loginAction({
            access_token,
            refresh_token,
            user: {email, firstName, lastName, userId},
          }),
        );
      } else {
        setIsLoading(false);
        showToast({
          message: data?.message || locale.CouldNotLoginAtTheMoment,
        });
      }
    } catch (error) {
      setIsLoading(false);
      const responseData = error?.response?.data;
      const code = responseData?.code;
      showToast({
        message:
          code === errorCodes.EMAIL_ADDRESS_NOT_FOUND ||
          code === errorCodes.INVALID_EMAIL_OR_PASSWORD
            ? locale.WrongEmailOrPassword
            : locale.SomethingWentWrongTryAgain,
      });
    }
  }, [dispatch, email, password]);

  const handleSubmit = React.useCallback(() => {
    _handleFormSubmit({
      checkIsEmpty,
      showInvalidOnEmpty,
      email,
      setInvalid,
      submit: login,
    });
  }, [
    showInvalidOnEmpty,
    checkIsEmpty,
    setInvalid,
    email,
    login,
    _handleFormSubmit,
  ]);

  const handleEmailInputChange = React.useCallback(
    value =>
      _handleInputChange({
        invalidValue: invalidEmail,
        setInvalid,
        showInvalidForSpecific,
        ref: emailRef,
        handleChange,
        value,
        type: 'email',
      }),
    [
      _handleInputChange,
      invalidEmail,
      showInvalidForSpecific,
      handleChange,
      setInvalid,
      emailRef,
    ],
  );
  const handlePasswordInputChange = React.useCallback(
    value => {
      _handleInputChange({
        invalidValue: invalidPassword,
        setInvalid,
        showInvalidForSpecific,
        ref: passwordRef,
        handleChange,
        value,
        type: 'password',
      });
    },
    [
      invalidPassword,
      showInvalidForSpecific,
      handleChange,
      setInvalid,
      passwordRef,
      _handleInputChange,
    ],
  );

  const handlePasswordToggle = React.useCallback(() => {
    setToggle(preState => !preState);
  }, []);

  return (
    <BaseLayout
      style={{padding: 20, marginBottom: 50}}
      contentContainerStyle={{
        justifyContent: 'center',
        height: '100%',
      }}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          marginBottom: 50,
        }}>
        <Image source={Logo} style={styles.logo} resizeMode="contain" />
      </View>
      <Text
        style={{
          fontSize: responsive.moderateScale(30),
          color: colors.primary,
        }}>
        {locale.Login}
      </Text>
      <View style={{marginTop: responsive.moderateScale(30)}} />
      <Text style={[styles.labelStyle]}>{locale.Email}</Text>
      <View ref={ref => (emailRef.current = ref)} style={styles.inputViewStyle}>
        <TextInput
          ref={emailInputRef}
          placeholder={locale.EnterYourEmail}
          textContentType="emailAddress"
          autoCapitalize="none"
          value={email}
          onSubmitEditing={() => passwordInputRef.current.focus()}
          onChangeText={handleEmailInputChange}
          style={styles.textInputStyles}
        />
      </View>
      {invalid.email ? (
        <Text style={{color: colors.red, marginTop: 5}}>
          {locale.InvalidEmailAddress}
        </Text>
      ) : null}

      <View style={{marginTop: 20}}>
        <Text style={[styles.labelStyle]}>{locale.Password}</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            ...styles.inputViewStyle,
          }}
          ref={ref => (passwordRef.current = ref)}>
          <TextInput
            ref={passwordInputRef}
            placeholder={locale.EnterYourPassword}
            textContentType="password"
            autoCapitalize="none"
            secureTextEntry={toggle}
            value={password}
            onChangeText={handlePasswordInputChange}
            onSubmitEditing={handleSubmit}
            style={{width: '80%', ...styles.textInputStyles}}
          />
          <TouchableOpacity onPress={handlePasswordToggle}>
            <Text>{toggle ? locale.Show : locale.Hide}</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View
        style={{
          marginTop: 15,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <TouchableOpacity
          onPress={() => navigation.navigate(screens.FORGOT_PASSWORD)}>
          <Text style={{color: colors.forgotPassword}}>
            {locale.ForgotPassword}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate(screens.REGISTER)}>
          <Text style={{color: colors.forgotPassword}}>{locale.Register}</Text>
        </TouchableOpacity>
      </View>
      <Button
        style={{marginTop: 30}}
        text="Login"
        onPress={handleSubmit}
        disabled={isLoading}
        loading={isLoading}
      />
      <DidUserChangedPasswordCheck />
    </BaseLayout>
  );
}

function DidUserChangedPasswordCheck({children = () => null}) {
  const dispatch = useDispatch();
  const doesUserChangedPassword = useSelector(
    state => state?.auth?.doesUserChangedPassword,
  );

  React.useEffect(() => {
    if (doesUserChangedPassword) {
      showToast({
        type: 'success',
        message: locale.LoginWithYourNewPassword,
      });
      dispatch(logout());
    }
  }, [doesUserChangedPassword, dispatch]);

  return children();
}

export default Login;
