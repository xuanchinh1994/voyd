import React from 'react';
import {View, Text, ActivityIndicator, Image} from 'react-native';
import {useQuery, useMutation} from '@apollo/react-hooks';
import {useFocusEffect} from '@react-navigation/native';

import {Header} from '../../components';
import styles from './styles';
import RenderRight from './RenderRight';
import BaseLayout from '../../layout';
import ImagePickerModal from '../../components/ImagePicker';
import useImageUpload from '../../tools/hooks/useImageUpload';
import locale from '../../assets/locale.json';
import {showToast, hideToast} from '../../components/Toast';
import {GET_CUSTOM_IMAGE} from '../../apollo/queries';
import {
  CREATE_CUSTOM_IMAGE,
  UPDATE_CUSTOM_IMAGE,
  DELETE_CUSTOM_IMAGE,
} from '../../apollo/mutations';
import {URLUtilities} from '../../tools/utils';

const Images = () => {
  const [pickDialogVisible, setPickDialogVisible] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [text, setText] = React.useState('');

  const {upload} = useImageUpload();

  const {data, loading: getImageLoading, refetch} = useQuery(GET_CUSTOM_IMAGE);

  const [createCustomImage] = useMutation(CREATE_CUSTOM_IMAGE);
  const [updateCustomImage] = useMutation(UPDATE_CUSTOM_IMAGE);
  const [deleteCustomImage] = useMutation(DELETE_CUSTOM_IMAGE);

  const customImageUrl = React.useMemo(
    () => ({
      url: data?.getCustomImage?.data?.url,
      id: data?.getCustomImage?.data?.id,
    }),
    [data?.getCustomImage?.data?.url, data?.getCustomImage?.data?.id],
  );

  const hasCustomImage = React.useMemo(
    () => Boolean(customImageUrl?.id && customImageUrl?.url),
    [customImageUrl?.id, customImageUrl?.url],
  );

  const handleImageUploadClick = React.useCallback(() => {
    if (!loading || getImageLoading) {
      setPickDialogVisible(true);
    }
  }, [getImageLoading, loading]);

  useFocusEffect(
    React.useCallback(() => {
      if (refetch) {
        refetch?.();
      }
    }, [refetch]),
  );

  const handleImageUpload = React.useCallback(
    async img => {
      hideToast();
      setPickDialogVisible(false);
      setLoading(true);
      setText('');
      const isImage = img?.mime?.startsWith('image');
      try {
        const {path} = await upload(img);
        const {data: createData} = await (hasCustomImage
          ? updateCustomImage({
              variables: {
                url: path,
                id: customImageUrl?.id,
              },
            })
          : createCustomImage({
              variables: {
                url: path,
              },
            }));
        const success =
          createData?.[
            hasCustomImage ? 'updateCustomImage' : 'createCustomImage'
          ]?.success;
        if (success) {
          showToast({
            type: 'success',
            message: isImage
              ? locale.ImageUploadedSuccessfully
              : locale.VideoUploadedSuccessfully,
          });
        } else {
          throw new Error();
        }
      } catch (error) {
        showToast({
          message: locale.SomethingWentWrongTryAgain,
        });
      } finally {
        await refetch?.();
        setLoading(false);
      }
    },
    [
      createCustomImage,
      refetch,
      upload,
      customImageUrl,
      updateCustomImage,
      hasCustomImage,
    ],
  );
  const handleDelete = React.useCallback(async () => {
    try {
      const {data: createData} = await deleteCustomImage({
        variables: {
          id: customImageUrl?.id,
        },
      });
      const success = createData?.deleteCustomImage?.success;
      if (success) {
        showToast({
          type: 'success',
          message: locale.ImageDeleted,
        });
      } else {
        throw new Error();
      }
    } catch (error) {
      showToast({
        message: locale.SomethingWentWrongTryAgain,
      });
    } finally {
      refetch?.();
    }
  }, [customImageUrl?.id, deleteCustomImage, refetch]);

  return (
    <BaseLayout contentContainerStyle={styles.container} scrollChildren={false}>
      <BaseLayout.Header>
        <Header
          logo
          left="back"
          noShadow
          renderRight={
            !getImageLoading ? (
              <RenderRight
                handleImageUpload={handleImageUploadClick}
                handleDelete={handleDelete}
                showDeleteIcon={hasCustomImage}
              />
            ) : null
          }
        />
      </BaseLayout.Header>
      <View style={styles.fullScreen}>
        {loading ? (
          <View>
            <ActivityIndicator />
            <Text style={{marginTop: 20}}>{locale['Uploading...']}</Text>
          </View>
        ) : data && hasCustomImage ? (
          text?.length ? (
            <Text>{text}</Text>
          ) : (
            <Image
              source={{uri: URLUtilities.mergeWithDomain(customImageUrl?.url)}}
              style={{width: '100%', height: '80%'}}
              resizeMode="contain"
              onError={() => {
                setText(locale.CannotPlayVideo);
              }}
            />
          )
        ) : getImageLoading ? (
          <ActivityIndicator />
        ) : (
          <Text>{locale.UploadAnImageOrVideo}</Text>
        )}
      </View>
      {pickDialogVisible ? (
        <ImagePickerModal
          visible={pickDialogVisible}
          setVisible={setPickDialogVisible}
          onImageSelected={handleImageUpload}
        />
      ) : null}
    </BaseLayout>
  );
};

export default Images;
