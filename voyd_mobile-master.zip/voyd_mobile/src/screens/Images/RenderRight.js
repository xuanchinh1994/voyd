import React from 'react';
import {View, TouchableOpacity} from 'react-native';

import Icon from '../../components/Icon';

const RenderRight = ({
  handleImageUpload = () => null,
  handleDelete = () => null,
  showDeleteIcon = false,
}) => {
  return (
    <View style={{flexDirection: 'row'}}>
      {showDeleteIcon ? (
        <TouchableOpacity onPress={handleDelete}>
          <Icon name="delete" />
        </TouchableOpacity>
      ) : null}
      <TouchableOpacity style={{marginLeft: 20}} onPress={handleImageUpload}>
        <Icon name="upload" />
      </TouchableOpacity>
    </View>
  );
};

export default RenderRight;
